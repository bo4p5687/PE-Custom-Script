#-----------#
# Set rules #
#-----------#
class Game_Temp
  alias battle_worm_rule add_battle_rule
  def add_battle_rule(rule, var = nil)
    rules = self.battle_rules
    case rule.to_s.downcase
    when "battle-worm" then rules["battle-worm"] = true
    else battle_worm_rule(rule, var)
    end
  end
end

module BattleWorm
	# Don't touch lines below
	@@faint   = []
	@@hp      = []
	@@status  = []
	@@percent = true
	@@random  = [false, false, false]

	module_function

	def error(str)
		p str
		Kernel.exit!
	end

	#--------#
	# Random #
	#--------#
	def random_faint  = @@random[0] = true
	def random_hp     = @@random[1] = true
	def random_status = @@random[2] = true
	def random_all    = @@random = [true, true, true]

	#-----#
	# Set #
	#-----#
	def set_faint(arr)
		self.error("Case 'Faint': It must be array!") unless arr.is_a?(Array)
		@@faint = arr
	end

	def set_hp(arr, percent=true)
		self.error("Case 'HP': It must be array!") unless arr.is_a?(Array)
		@@percent = percent
		@@hp = arr
	end

	def set_status(arr)
		self.error("Case 'Status': It must be array!") unless arr.is_a?(Array)
		@@status = arr
	end

	#-------#
	# Reset #
	#-------#
	def reset
		@@faint   = []
		@@hp      = []
		@@status  = []
		@@percent = true
		@@random  = [false, false, false]
	end

	#-----------------#
	# Set battle worm #
	#-----------------#
	def set_to_start_battle(party)
		# Create battle worm
		faint  = @@faint
		hp     = @@hp
		status = @@status
		rules  = @@random
		party2 = party.each_with_index { |pkmn, i|
			next if rules.size <= 0
			# Check faint
			if rules[0]
				if faint.size == 0
					pkmn.hp = 0 if rand == 0
				else
					pkmn.hp = 0 if faint[i]
				end
			end
			# Check hp loss
			if rules[1]
				if hp.size == 0
					pkmn.hp = rand(pkmn.totalhp) + 1
				else
					next unless hp[i]
					if @@percent
						pkmn.hp = (hp[i].is_a?(Range) ? rand(hp[i]) : hp[i]) * pkmn.totalhp / 100
					else
						pkmn.hp = hp[i].is_a?(Range) ? rand(hp[i]) : hp[i]
						pkmn.hp = pkmn.totalhp if pkmn.hp > pkmn.totalhp
						pkmn.hp = 1 if pkmn.hp < 0
					end
				end
			end
			# Check status
			if rules[2]
				if status.size == 0
					randsta = [:NONE, :SLEEP, :POISON, :BURN, :PARALYSIS, :FROZEN]
					pkmn.status = randsta.sample
				else
					pkmn.status = status[i] if status[i]
				end
			end
		}
		# Check if all pokemon fainted
		faintall = 0
		party2.each { |pkmn| faintall += 1 if pkmn.hp <= 0 }
		if faintall == party2.size && rules[0]
			party2[0].hp = 1
			party2[0].status = status[0] if rules[2] && status[0]
		end
		# Reset
		self.reset
		return party2
	end
end

#-------------#
# Wild battle #
#-------------#
class WildBattle
	class << self
		alias worm_battle_generate_foes generate_foes
	end

	def self.generate_foes(*args)
		# Battle worm
		ret = worm_battle_generate_foes(*args)
		ret = BattleWorm.set_to_start_battle(ret) if $game_temp.battle_rules["battle-worm"]
		return ret
	end
end

#----------------#
# Trainer battle #
#----------------#
class TrainerBattle
	class << self
		alias worm_battle_generate_foes generate_foes
	end

	def self.generate_foes(*args)
		ret = worm_battle_generate_foes(*args)
		# Battle worm
		ret[2] = BattleWorm.set_to_start_battle(ret[2]) if $game_temp.battle_rules["battle-worm"]
		return ret
	end
end