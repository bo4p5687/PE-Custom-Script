# Repeat animation (times)
module RepeatAnimate
	Trainer = 1
	Pokemon = 1
	# Wait each frame
	WaitT = 1 # Trainer
	WaitP = 1 # Pokemon
end

# Animated pokemon
module AnimatedBattlers
	# If true, pokemon has animated (need to set true if you want animated when pokemon faint or use move)
	Animated = true
	# After 4 frames, it will change graphic (move to next frame)
	Speed = 4

	# First frames. If you set it true, pokemon that will show first frame when pokemon faint (case: not animated)
	First = true
	# Set true, pokemon fainted has animated
	Faint = true

	# Set true, when pokemon use move, pokemon has animated
	Move = true
	# After 4 frames, it will change graphic (move to next frame) - In case 'pokemon use move'
	SpeedMove = 4

end