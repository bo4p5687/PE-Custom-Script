class PBAnimationPlayerX
	alias animated_init initialize
	def initialize(animation,user,target,scene=nil,oppMove=false,inEditor=false)
		animated_init(animation,user,target,scene,oppMove,inEditor)
		@speed_animated_frames = 0
	end

	def update
    return if @frame<0
    animFrame = @frame/@framesPerTick
    # Loop or end the animation if the animation has reached the end
    if animFrame >= @animation.length
      @frame = (@looping) ? 0 : -1
      if @frame<0
        @animbitmap.dispose if @animbitmap
        @animbitmap = nil
        return
      end
    end
    # Load the animation's spritesheet and assign it to all the sprites.
    if !@animbitmap || @animbitmap.disposed?
      @animbitmap = AnimatedBitmap.new("Graphics/Animations/"+@animation.graphic,
         @animation.hue).deanimate
      for i in 0...MAX_SPRITES
        @animsprites[i].bitmap = @animbitmap if @animsprites[i]
      end
    end
    # Update background and foreground graphics
    @bgGraphic.update
    @bgColor.update
    @foGraphic.update
    @foColor.update
    # Update all the sprites to depict the animation's next frame
    if @framesPerTick==1 || (@frame % @framesPerTick)==0
      thisframe = @animation[animFrame]
      # Make all cel sprites invisible
      for i in 0...MAX_SPRITES
        @animsprites[i].visible = false if @animsprites[i]
      end
      # Set each cel sprite acoordingly
      for i in 0...thisframe.length
        cel = thisframe[i]
        next if !cel
        sprite = @animsprites[i]
        next if !sprite
        # Set cel sprite's graphic
        case cel[AnimFrame::PATTERN]
        when -1
          sprite.bitmap = @userbitmap

					# Change
					sprite.src_rect.width = sprite.bitmap.height

        when -2
          sprite.bitmap = @targetbitmap

					# Change
					sprite.src_rect.width = sprite.bitmap.height

        else
          sprite.bitmap = @animbitmap
        end

        # Apply settings to the cel sprite -> new
        pbSpriteSetAnimFrame(sprite,cel,@usersprite,@targetsprite, false, @speed_animated_frames)
				@speed_animated_frames += 1

        case cel[AnimFrame::FOCUS]
        when 1   # Focused on target
          sprite.x = cel[AnimFrame::X]+@targetOrig[0]-PokeBattle_SceneConstants::FOCUSTARGET_X
          sprite.y = cel[AnimFrame::Y]+@targetOrig[1]-PokeBattle_SceneConstants::FOCUSTARGET_Y
        when 2   # Focused on user
          sprite.x = cel[AnimFrame::X]+@userOrig[0]-PokeBattle_SceneConstants::FOCUSUSER_X
          sprite.y = cel[AnimFrame::Y]+@userOrig[1]-PokeBattle_SceneConstants::FOCUSUSER_Y
        when 3   # Focused on user and target
          next if !@srcLine || !@dstLine
          point = transformPoint(
             @srcLine[0],@srcLine[1],@srcLine[2],@srcLine[3],
             @dstLine[0],@dstLine[1],@dstLine[2],@dstLine[3],
             sprite.x,sprite.y)
          sprite.x = point[0]
          sprite.y = point[1]
          if isReversed(@srcLine[0],@srcLine[2],@dstLine[0],@dstLine[2]) &&
             cel[AnimFrame::PATTERN]>=0
            # Reverse direction
            sprite.mirror = !sprite.mirror
          end
        end
        sprite.x += 64 if @inEditor
        sprite.y += 64 if @inEditor
      end
      # Play timings
      @animation.playTiming(animFrame,@bgGraphic,@bgColor,@foGraphic,@foColor,@oldbg,@oldfo,@user)
    end
    @frame += 1
  end
end

def pbSpriteSetAnimFrame(sprite,frame,user=nil,target=nil,inEditor=false, speed=0)
  return if !sprite
  if !frame
    sprite.visible  = false
    sprite.src_rect = Rect.new(0,0,1,1)
    return
  end
  sprite.blend_type = frame[AnimFrame::BLENDTYPE]
  sprite.angle      = frame[AnimFrame::ANGLE]
  sprite.mirror     = (frame[AnimFrame::MIRROR]>0)
  sprite.opacity    = frame[AnimFrame::OPACITY]
  sprite.visible    = true
  if !frame[AnimFrame::VISIBLE]==1 && inEditor
    sprite.opacity  /= 2
  else
    sprite.visible  = (frame[AnimFrame::VISIBLE]==1)
  end
  pattern = frame[AnimFrame::PATTERN]
  if pattern>=0
    animwidth = 192
    sprite.src_rect.set((pattern%5)*animwidth,(pattern/5)*animwidth,
       animwidth,animwidth)
  else

		# New
		if sprite.bitmap
			srcx = sprite.src_rect.x
			if speed % AnimatedBattlers::SpeedMove == 0
				srcx += sprite.src_rect.height
				srcx  = 0 if srcx >= sprite.bitmap.width
			end
			x = AnimatedBattlers::Animated && AnimatedBattlers::Move ? srcx : 0
		else
			x = 0
		end
		sprite.src_rect.set(x, 0,

				# Change
       (sprite.bitmap) ? sprite.src_rect.width : 128,
       (sprite.bitmap) ? sprite.src_rect.height : 128)

  end
  sprite.zoom_x = frame[AnimFrame::ZOOMX]/100.0
  sprite.zoom_y = frame[AnimFrame::ZOOMY]/100.0
  sprite.color.set(
     frame[AnimFrame::COLORRED],
     frame[AnimFrame::COLORGREEN],
     frame[AnimFrame::COLORBLUE],
     frame[AnimFrame::COLORALPHA]
  )
  sprite.tone.set(
     frame[AnimFrame::TONERED],
     frame[AnimFrame::TONEGREEN],
     frame[AnimFrame::TONEBLUE],
     frame[AnimFrame::TONEGRAY]
  )
  sprite.ox = sprite.src_rect.width / 2
  sprite.oy = sprite.src_rect.height / 2
  sprite.x  = frame[AnimFrame::X]
  sprite.y  = frame[AnimFrame::Y]
  if sprite!=user && sprite!=target
    case frame[AnimFrame::PRIORITY]
    when 0   # Behind everything
      sprite.z = 10
    when 1   # In front of everything
      sprite.z = 80
    when 2   # Just behind focus
      case frame[AnimFrame::FOCUS]
      when 1   # Focused on target
        sprite.z = (target) ? target.z-1 : 20
      when 2   # Focused on user
        sprite.z = (user) ? user.z-1 : 20
      else     # Focused on user and target, or screen
        sprite.z = 20
      end
    when 3   # Just in front of focus
      case frame[AnimFrame::FOCUS]
      when 1   # Focused on target
        sprite.z = (target) ? target.z+1 : 80
      when 2   # Focused on user
        sprite.z = (user) ? user.z+1 : 80
      else     # Focused on user and target, or screen
        sprite.z = 80
      end
    else
      sprite.z = 80
    end
  end
end

class PokeBattle_Scene
	def pbCreateTrainerFrontSprite(idxTrainer,trainerType,numTrainers=1)
    trainerFile = GameData::TrainerType.front_sprite_filename(trainerType)
    spriteX, spriteY = PokeBattle_SceneConstants.pbTrainerPosition(1,idxTrainer,numTrainers)
    trainer = pbAddSprite("trainer_#{idxTrainer+1}",spriteX,spriteY,trainerFile,@viewport)
    return if !trainer.bitmap
    # Alter position of sprite
    trainer.z  = 7+idxTrainer
		div = trainer.bitmap.width / trainer.bitmap.height
		trainer.src_rect.width = trainer.bitmap.height if div > 1
    trainer.ox = trainer.src_rect.width / 2
    trainer.oy = trainer.bitmap.height
  end
end