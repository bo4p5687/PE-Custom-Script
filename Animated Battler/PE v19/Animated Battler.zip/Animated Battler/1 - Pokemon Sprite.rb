#===============================================================================
# Pokémon sprite (used out of battle)
#===============================================================================
class PokemonSprite

	# Return first frame
	def firstFrame
		return if !self.bitmap
		self.src_rect.width = self.src_rect.height = self.bitmap.height
	end

  def setOffset(offset=PictureOrigin::Center)
    @offset = offset
		firstFrame # Set again
    changeOrigin
  end

	alias animate_change_origin changeOrigin
  def changeOrigin
    return if !self.bitmap
		animate_change_origin
		firstFrame # Set again
		# Set coordinate
		div = self.bitmap.width / self.bitmap.height
    case @offset
    when PictureOrigin::Top, PictureOrigin::Center, PictureOrigin::Bottom
      self.ox = self.bitmap.width / (2 * div)
    when PictureOrigin::TopRight, PictureOrigin::Right, PictureOrigin::BottomRight
      self.ox = self.bitmap.width / div
    end
  end

	alias animate_set_pkmn_bitmap setPokemonBitmap
	def setPokemonBitmap(pokemon,back=false)
		animate_set_pkmn_bitmap(pokemon,back)
		firstFrame # Set again
		changeOrigin
  end

	alias animate_set_pkmn_bitmap_species setPokemonBitmapSpecies
  def setPokemonBitmapSpecies(pokemon,species,back=false)
		animate_set_pkmn_bitmap_species(pokemon,species,back)
		firstFrame # Set again
    changeOrigin
  end

	alias animate_set_species_bitmap setSpeciesBitmap
  def setSpeciesBitmap(species, gender = 0, form = 0, shiny = false, shadow = false, back = false, egg = false)
		animate_set_species_bitmap(species, gender, form, shiny, shadow, back, egg)
		firstFrame # Set again
    changeOrigin
  end

	def update
    super
    if @_iconbitmap
      @_iconbitmap.update
      self.bitmap = @_iconbitmap.bitmap
			firstFrame # Set again, update
    end
  end

end

class MosaicPokemonSprite
	alias animate_mosaic_refresh mosaicRefresh
  def mosaicRefresh(bitmap)
		firstFrame # Set again, begin
		animate_mosaic_refresh(bitmap)
  end
end