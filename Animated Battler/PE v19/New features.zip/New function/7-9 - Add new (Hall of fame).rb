# It overrides Hall of Fame Scene. So, if you want to use some codes that use this def, rewrite it.

class HallOfFame_Scene

	# Need to rewrite it to use
	def createBattlers(hide=true)
    # Movement in animation
    for i in 0...6
      # Clear all 6 pokémon sprites and dispose the ones that exists every time
      # that this method is call
      restartSpritePosition(@sprites,"pokemon#{i}")
      next if i>=@hallEntry.size
      xpoint=xpointformula(i)
      ypoint=ypointformula(i)
      pok=@hallEntry[i]
      @sprites["pokemon#{i}"]=PokemonSprite.new(@viewport)
      @sprites["pokemon#{i}"].setOffset(PictureOrigin::TopLeft)
      @sprites["pokemon#{i}"].setPokemonBitmap(pok)
      # This method doesn't put the exact coordinates
      @sprites["pokemon#{i}"].x = xpoint
      @sprites["pokemon#{i}"].y = ypoint
      if @sprites["pokemon#{i}"].bitmap && !@sprites["pokemon#{i}"].disposed?
        @sprites["pokemon#{i}"].x += (128-@sprites["pokemon#{i}"].src_rect.width)/2
        @sprites["pokemon#{i}"].y += (128-@sprites["pokemon#{i}"].bitmap.height)/2
      end
      @sprites["pokemon#{i}"].z=7-i if SINGLEROW
      next if !hide
      # Animation distance calculation
      horizontal=1-xpositionformula(i)
      vertical=1-ypositionformula(i)
      xdistance=(horizontal==-1) ? -@sprites["pokemon#{i}"].src_rect.width : Graphics.width
      ydistance=(vertical==-1) ? -@sprites["pokemon#{i}"].bitmap.height : Graphics.height
      xdistance=((xdistance-@sprites["pokemon#{i}"].x)/ANIMATIONSPEED).abs+1
      ydistance=((ydistance-@sprites["pokemon#{i}"].y)/ANIMATIONSPEED).abs+1
      biggerdistance=(xdistance>ydistance) ? xdistance : ydistance
      @xmovement[i]=biggerdistance
      @xmovement[i]*=-1 if horizontal==-1
      @xmovement[i]=0   if horizontal== 0
      @ymovement[i]=biggerdistance
      @ymovement[i]*=-1 if vertical==-1
      @ymovement[i]=0   if vertical== 0
      # Hide the battlers
      @sprites["pokemon#{i}"].x+=@xmovement[i]*ANIMATIONSPEED
      @sprites["pokemon#{i}"].y+=@ymovement[i]*ANIMATIONSPEED
			# Animate
			@sprites["animated frames #{i}".to_sym] = false
    end
  end

	def pbUpdate
    pbUpdateSpriteHash(@sprites)
		return if @battlerIndex >= @hallEntry.size
		return if !@sprites["pokemon#{@battlerIndex-1}"]
		return if @sprites["animated frames #{@battlerIndex-1}".to_sym]
		pkmn   = @sprites["pokemon#{@battlerIndex-1}"]
		bitmap = pkmn.bitmap
		return if bitmap.width == bitmap.height
		div = bitmap.width / bitmap.height
		time = RepeatAnimate::FRAME_PKMN * div + 1
		time.times {
			Graphics.update
      Input.update
			pkmn.frames += 1
			pkmn.animate_bitmap
		}
		@sprites["animated frames #{@battlerIndex-1}".to_sym] = true
  end
	
end