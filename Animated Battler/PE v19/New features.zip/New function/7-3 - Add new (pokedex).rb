class PokemonPokedex_Scene

	def pbUpdate
    pbUpdateSpriteHash(@sprites)
		return if !@sprites["icon"]
		@sprites["icon"].frames += 1
		@sprites["icon"].animate_bitmap
  end

end

class PokemonPokedexInfo_Scene

	alias animate_update pbUpdate
	def pbUpdate
		animate_update
		return if !@sprites["infosprite"]
		@sprites["infosprite"].frames += 1
		@sprites["infosprite"].animate_bitmap
		return if !@sprites["formfront"]
		@sprites["formfront"].frames += 1
		@sprites["formfront"].animate_bitmap
		return if !@sprites["formback"]
		@sprites["formback"].frames += 1
		@sprites["formback"].animate_bitmap
	end

	alias animate_draw_page drawPage
	def drawPage(page)
		animate_draw_page(page)
		return if !@sprites["infosprite"]
		@sprites["infosprite"].again = false
		return if !@sprites["formfront"]
		@sprites["formfront"].again = false
		return if !@sprites["formback"]
		@sprites["formback"].again = false
	end
end