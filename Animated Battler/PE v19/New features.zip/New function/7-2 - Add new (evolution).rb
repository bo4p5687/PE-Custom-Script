class PokemonEvolutionScene
	alias evolution_animate pbEvolution
	def pbEvolution(cancancel=true)
		if @sprites["rsprite1"].bitmap.width != @sprites["rsprite1"].bitmap.height
			div = @sprites["rsprite1"].bitmap.width / @sprites["rsprite1"].bitmap.height
			time = RepeatAnimate::FRAME_PKMN * div + 1
			time.times {
				Graphics.update
				pbUpdateSpriteHash(@sprites)
				@sprites["rsprite1"].frames += 1
				@sprites["rsprite1"].animate_bitmap
			}
		end
		evolution_animate(cancancel)
	end

	alias flash_animate pbFlashInOut
	def pbFlashInOut(canceled,oldstate,oldstate2)
		flash_animate(canceled,oldstate,oldstate2)
		name = canceled ? "rsprite1" : "rsprite2"
		return if @sprites[name].bitmap.width == @sprites[name].bitmap.height
		div = @sprites[name].bitmap.width / @sprites[name].bitmap.height
		@sprites[name].frames = 0
		@sprites[name].again  = false # If you don't want to have animated when pressing cancel, delete this line
		time = RepeatAnimate::FRAME_PKMN * div + 1
		time.times {
			Graphics.update
			pbUpdateSpriteHash(@sprites)
			@sprites["rsprite1"].frames += 1
			@sprites["rsprite1"].animate_bitmap
		}
	end
end
