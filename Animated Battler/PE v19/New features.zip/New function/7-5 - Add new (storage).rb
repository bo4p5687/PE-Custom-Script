class PokemonStorageScene
	
	def update
		pbUpdateSpriteHash(@sprites)
		return if !@sprites["pokemon"].visible
		return if @sprites["pokemon"].mosaic > 0
		@sprites["pokemon"].frames += 1
		@sprites["pokemon"].animate_bitmap
	end

end