
module RepeatAnimate
	# After this frames (screen), animated move 1 frame
	FRAME_PKMN = 4

	# Check one time
	# If true, when bitmap shows, this action (animated) just do one time
	# If false, when bitmap shows, this action is a loop
	CHECK_ONE_TIME = true
end

class PokemonSprite
	attr_accessor :frames
	attr_accessor :again

	alias init_animate initialize
	def initialize(vp=nil)
		init_animate(vp)
		@frames = 0
		@again = false
	end

	def animate_bitmap
		return if self.bitmap.width == self.bitmap.height
		return if RepeatAnimate::CHECK_ONE_TIME && @again
		return if !@frames || @frames % RepeatAnimate::FRAME_PKMN != 0
		self.src_rect.x += self.bitmap.height
		if self.src_rect.x >= self.bitmap.width
			self.src_rect.x  = 0
			@again = true if RepeatAnimate::CHECK_ONE_TIME
		end
	end

	def setPokemonBitmap(pokemon,back=false)
		animate_set_pkmn_bitmap(pokemon,back)
		firstFrame
		changeOrigin
		@again = false
  end

  def setPokemonBitmapSpecies(pokemon,species,back=false)
		animate_set_pkmn_bitmap_species(pokemon,species,back)
		firstFrame
    changeOrigin
		@again = false
  end

  def setSpeciesBitmap(species, gender = 0, form = 0, shiny = false, shadow = false, back = false, egg = false)
		animate_set_species_bitmap(species, gender, form, shiny, shadow, back, egg)
		firstFrame
    changeOrigin
		@again = false
  end

end