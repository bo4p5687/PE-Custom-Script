class PokemonSummary_Scene
	def pbUpdate
    pbUpdateSpriteHash(@sprites)
		return if !@sprites["pokemon"]
		@sprites["pokemon"].frames += 1
		@sprites["pokemon"].animate_bitmap
  end
end