module AnimatedBattlers
	# Repeat animation (times)
	TRAINER = 1
	POKEMON = 1
	# Wait each frame
	WAIT_TRAINER = 1 # Trainer
	WAIT_POKEMON = 1 # Pokemon

	# If true, pokemon has animated (need to set true if you want animated when pokemon faint or use move)
	ANIMATED = true
	# After 4 frames, it will change graphic (move to next frame)
	SPEED = 4

	# First frames. If you set it true, pokemon that will show first frame when pokemon faint (case: not animated)
	FAINTED_FIRST = true
	# Set true, pokemon fainted has animated
	FAINTED = true

	# Set true, when pokemon use move, pokemon has animated
	MOVES = true
	# After 4 frames, it will change graphic (move to next frame) - In case 'pokemon use move'
	SPEED_MOVE = 4
	
	# After these frames (screen), animated moves 1 frame
	FRAME_PKMN = 4

	# Check one time
	# If true, when bitmap shows, this action (animated) just do one time
	# If false, when bitmap shows, this action is a loop
	CHECK_ONE_TIME = true
end