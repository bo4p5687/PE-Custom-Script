class Battle::Scene::Animation::TrainerIntro < Battle::Scene::Animation
  def initialize(sprites, viewport, battle)
    @battle = battle
    super(sprites, viewport)
  end
 
  def createProcesses
    @battle.opponent.each_with_index { |p,i|
			trainer = addSprite(@sprites["trainer_#{i + 1}"], PictureOrigin::BOTTOM)
			sprite = @sprites["trainer_#{i + 1}"]
			div = sprite.bitmap.width / sprite.bitmap.height
			return unless div > 1
			delay = 0
			trainer.setSrcSize(delay, sprite.bitmap.width / div, sprite.bitmap.height)
			trainer.setSrc(delay, 0, 0)
			# Animate
			curframe = AnimatedBattlers::WAIT_TRAINER
			sum = div * AnimatedBattlers::TRAINER
			while sum > 0
				trainer.setSrc(delay + curframe - AnimatedBattlers::WAIT_TRAINER, ((curframe / AnimatedBattlers::WAIT_TRAINER) % div) * sprite.bitmap.height, 0)
				curframe += AnimatedBattlers::WAIT_TRAINER
				sum -= 1
			end
			# Add # before line below when you don't want graphic which returns first frame
			trainer.setSrc(delay + div * AnimatedBattlers::TRAINER, 0, 0)
    }
  end
end

# Wild battle
class Battle::Scene::Animation::WildIntro < Battle::Scene::Animation
  def initialize(sprites, viewport, sideSize)
    @sideSize = sideSize
    super(sprites, viewport)
  end

  def createProcesses
		@sideSize.size.times { |i|
      idxBattler = 2 * i + 1
      next if !@sprites["pokemon_#{idxBattler}"]
      battler = addSprite(@sprites["pokemon_#{idxBattler}"], PictureOrigin::BOTTOM)
			sprite  = @sprites["pokemon_#{idxBattler}"]
			div = sprite.bitmap.width / sprite.bitmap.height
			return unless div > 1
			delay = 0
			battler.setSrcSize(delay, sprite.bitmap.width / div, sprite.bitmap.height)
			battler.setSrc(delay, 0, 0)
			# Animate
			curframe = AnimatedBattlers::WAIT_POKEMON
			sum = div * AnimatedBattlers::POKEMON
			while sum > 0
				battler.setSrc(delay + curframe - AnimatedBattlers::WAIT_POKEMON, ((curframe / AnimatedBattlers::WAIT_POKEMON) % div) * sprite.bitmap.height, 0)
				curframe += AnimatedBattlers::WAIT_POKEMON
				sum -= 1
			end
			battler.setSrc(delay + div * AnimatedBattlers::POKEMON, 0, 0)
    }
  end

end

module Battle::Scene::Animation::BallAnimationMixin
	alias animate_battler_appear battlerAppear
	def battlerAppear(battler, delay, battlerX, battlerY, batSprite, color)
		animate_battler_appear(battler, delay, battlerX, battlerY, batSprite, color)
		# New
		div = batSprite.bitmap.width / batSprite.bitmap.height
		return if div <= 1
		curframe = AnimatedBattlers::WAIT_POKEMON
		sum = div * AnimatedBattlers::POKEMON
		while sum > 0
			battler.setSrc(delay + 5 + 1 + curframe - AnimatedBattlers::WAIT_POKEMON, ((curframe / AnimatedBattlers::WAIT_POKEMON) % div) * batSprite.bitmap.height, 0)
			curframe += AnimatedBattlers::WAIT_POKEMON
			sum -= 1
		end
		battler.setSrc(delay + 5 + 1 + div * AnimatedBattlers::POKEMON, 0, 0)
  end
end

class Battle::Scene
	def pbFrameUpdate(cw = nil)
		cw&.update
    # New
		@battle.battlers.each_with_index { |b, i|
			next if !b
			@sprites["dataBox_#{i}"]&.update(@frameCounter)
			@sprites["pokemon_#{i}"]&.update(@frameCounter, b.fainted?)
			@sprites["shadow_#{i}"]&.update(@frameCounter)
		}
  end
end