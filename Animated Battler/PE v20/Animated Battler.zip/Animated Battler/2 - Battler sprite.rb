
class Battle::Scene::BattlerSprite

	alias animated_battler_init initialize
	def initialize(viewport, sideSize, index, battleAnimations)
		animated_battler_init(viewport, sideSize, index, battleAnimations)
		@speed_animated = 0
		@frame_animated = 0
	end

	# Return first frame
	def firstFrame
		return if !self.bitmap
		self.src_rect.width = self.src_rect.height = self.bitmap.height
	end

	def multi_frames
		return if !self.bitmap
		self.src_rect.x = self.src_rect.x + self.src_rect.height >= self.bitmap.width ? 0 : (self.src_rect.x + self.src_rect.height)
	end

  def setPokemonBitmap(pkmn, back = false)
    @pkmn = pkmn
    @_iconBitmap&.dispose
    @_iconBitmap = GameData::Species.sprite_bitmap_from_pokemon(@pkmn, back)
    self.bitmap = (@_iconBitmap) ? @_iconBitmap.bitmap : nil
		firstFrame # Set again
    pbSetPosition
  end

  # Set sprite's origin to bottom middle
  def pbSetOrigin
    return if !@_iconBitmap
		self.src_rect.width = self.bitmap.height
		div = self.bitmap.width / self.bitmap.height
    self.ox = @_iconBitmap.width / (2 * div)
    self.oy = @_iconBitmap.height
  end

	def update(frameCounter = 0, faint = false)
    return if !@_iconBitmap
    @updating = true
    # Update bitmap
    @_iconBitmap.update
    self.bitmap = @_iconBitmap.bitmap

		# Set src_rect
		if AnimatedBattlers::ANIMATED
			if faint && !AnimatedBattlers::FAINTED
				@speed_animated = 0
				firstFrame
				self.src_rect.x = 0 if AnimatedBattlers::FAINTED_FIRST
			else
				@speed_animated += 1
				if @speed_animated % AnimatedBattlers::SPEED == 0
					firstFrame if faint
					multi_frames
				end
			end
		else
			firstFrame
		end

    # Pokémon sprite bobbing while Pokémon is selected
    @spriteYExtra = 0
    if @selected == 1    # When choosing commands for this Pokémon
      case (frameCounter / QUARTER_ANIM_PERIOD).floor
      when 1 then @spriteYExtra = 2
      when 3 then @spriteYExtra = -2
      end
    end
    self.x       = self.x
    self.y       = self.y
    self.visible = @spriteVisible
    # Pokémon sprite blinking when targeted
    if @selected == 2 && @spriteVisible
      case (frameCounter / SIXTH_ANIM_PERIOD).floor
      when 2, 5 then self.visible = false
      else           self.visible = true
      end
    end
    @updating = false
  end

end
