class Battle::Scene
  def pbBattleIntroAnimation
    # Make everything appear
    introAnim = Animation::Intro.new(@sprites, @viewport, @battle)
    loop do
      introAnim.update
      pbUpdate
      break if introAnim.animDone?
    end
    introAnim.dispose
    # Post-appearance activities
    # Trainer battle: get ready to show the party lineups (they are brought
    # on-screen by a separate animation)
    if @battle.trainerBattle?

			# Add trainer animation
			@animations.push(Animation::TrainerIntro.new(@sprites, @viewport, @battle))

      # NOTE: Here is where you'd make trainer sprites animate if they had an
      #       entrance animation. Be sure to set it up like a Pokémon entrance
      #       animation, i.e. add them to @animations so that they can play out
      #       while party lineups appear and messages show.
      pbShowPartyLineup(0, true)
      pbShowPartyLineup(1, true)
      return
    end

		# Add pokemon animation
		@animations.push(Animation::WildIntro.new(@sprites, @viewport, @battle.sideSizes[1]))

    # Wild battle: play wild Pokémon's intro animations (including cry), show
    # data box(es), return the wild Pokémon's sprite(s) to normal colour, show
    # shiny animation(s)
    # Set up data box animation
    @battle.sideSizes[1].times { |i|
      idxBattler = (2 * i) + 1
      next if !@battle.battlers[idxBattler]
      dataBoxAnim = Animation::DataBoxAppear.new(@sprites, @viewport, idxBattler)
      @animations.push(dataBoxAnim)
    }
    # Set up wild Pokémon returning to normal colour and playing intro
    # animations (including cry)
    @animations.push(Animation::Intro2.new(@sprites, @viewport, @battle.sideSizes[1]))
    # Play all the animations
    while inPartyAnimation?
			pbUpdate
		end
		# Show shiny animation for wild Pokémon
		if @battle.showAnims
			@battle.sideSizes[1].times do |i|
				idxBattler = (2 * i) + 1
				next if !@battle.battlers[idxBattler] || !@battle.battlers[idxBattler].shiny?
				if Settings::SUPER_SHINY && @battle.battlers[idxBattler].super_shiny?
					pbCommonAnimation("SuperShiny", @battle.battlers[idxBattler])
				else
					pbCommonAnimation("Shiny", @battle.battlers[idxBattler])
				end
			end
		end
  end
end