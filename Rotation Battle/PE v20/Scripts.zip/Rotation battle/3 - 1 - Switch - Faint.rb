class Battle

	#=============================================================================
  # Switching Pokémon
  #=============================================================================
  # General switching method that checks if any Pokémon need to be sent out and,
  # if so, does. Called at the end of each round.
  def pbEORSwitch(favorDraws=false)
		return if @decision > 0 && !favorDraws
		return if @decision == 5 && favorDraws
		pbJudge
		return if @decision > 0
		# Check through each fainted battler to see if that spot can be filled.
		switched = []

		# Rotate
		# Check if pokemon change rotation (wild battle)
		rotatewild = false
		
		loop do
			switched.clear
			@battlers.each do |b|
				next if !b || !b.fainted?
				idxBattler = b.index
				next if !pbCanChooseNonActive?(idxBattler)
				if !pbOwnedByPlayer?(idxBattler)   # Opponent/ally is switching in
					
					# Wild Pokémon can't switch
					if wildBattle? && opposes?(idxBattler)

						# Rotate
						if $rotation
							next if !@battlers[@rotate_opponent].fainted? || @rotate_opponent == idxBattler
							next if rotatewild
							arr = []
							@battlers.each { |b2| arr << b2.index if b2 && opposes?(b2.index) && !b2.fainted? }
							@rotate_opponent = arr.sample
							rotatewild = true
						end

          	next
					end

          idxPartyNew = pbSwitchInBetween(idxBattler)
          opponent = pbGetOwnerFromBattlerIndex(idxBattler)
          # NOTE: The player is only offered the chance to switch their own
          #       Pokémon when an opponent replaces a fainted Pokémon in single
          #       battles. In double battles, etc. there is no such offer.
          if @internalBattle && @switchStyle && trainerBattle? && pbSideSize(0) == 1 && opposes?(idxBattler) && !@battlers[0].fainted? && !switched.include?(0) && pbCanChooseNonActive?(0) && @battlers[0].effects[PBEffects::Outrage] == 0
            idxPartyForName = idxPartyNew
            enemyParty = pbParty(idxBattler)
            if enemyParty[idxPartyNew].ability == :ILLUSION && !pbCheckGlobalAbility(:NEUTRALIZINGGAS)
              new_index = pbLastInTeam(idxBattler)
              idxPartyForName = new_index if new_index >= 0 && new_index != idxPartyNew
            end
            if pbDisplayConfirm(_INTL("{1} is about to send out {2}. Will you switch your Pokémon?", opponent.full_name, enemyParty[idxPartyForName].name))
              idxPlayerPartyNew = pbSwitchInBetween(0, false, true)
							if idxPlayerPartyNew >= 0
								pbMessageOnRecall(@battlers[0])
								pbRecallAndReplace(0, idxPlayerPartyNew)
                switched.push(0)
              end
            end
          end
          pbRecallAndReplace(idxBattler, idxPartyNew)
          switched.push(idxBattler)

					# Rotate
					@rotate_opponent = idxBattler if $rotation

        elsif trainerBattle?   # Player switches in a trainer battle
          idxPlayerPartyNew = pbGetReplacementPokemonIndex(idxBattler)   # Owner chooses
          pbRecallAndReplace(idxBattler, idxPlayerPartyNew)
          switched.push(idxBattler)

					# Rotate
					@rotate_player = idxBattler if $rotation

        else   # Player's Pokémon has fainted in a wild battle
          switch = pbDisplayConfirm(_INTL("Use next Pokémon?")) ? true : pbRun(idxBattler, true) <= 0
          if switch
            idxPlayerPartyNew = pbGetReplacementPokemonIndex(idxBattler)   # Owner chooses
            pbRecallAndReplace(idxBattler, idxPlayerPartyNew)
            switched.push(idxBattler)

						# Rotate
						@rotate_player = idxBattler if $rotation
	
          end
        end
      end
      break if switched.length == 0
      pbOnBattlerEnteringBattle(switched)
    end

		# Rotate
		# If player/opponent doesn't have any pokemons in party (not in field), change position of pokemon
		if $rotation
			p1 = []
			p2 = []
			@battlers.each_with_index { |b, i|
				next if !b
				next if b.fainted?
				pbOwnedByPlayer?(i) ? (p1 << i) : (p2 << i)
			}
			@rotate_player = p1.sample if p1.size < pbSideSize(0)
			@rotate_opponent = p2.sample if p2.size < pbSideSize(1)
		end

  end

end