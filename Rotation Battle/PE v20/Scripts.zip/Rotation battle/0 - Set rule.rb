module RotationBattle
	# When `BLACK = true`, pokemon who has color black is inactive 
	BLACK = true

	def self.skip_battle(outcome_variable)
    $game_temp.clear_battle_rules
    if $game_temp.memorized_bgm && $game_system.is_a?(Game_System)
      $game_system.bgm_pause
      $game_system.bgm_position = $game_temp.memorized_bgm_position
      $game_system.bgm_resume($game_temp.memorized_bgm)
    end
    $game_temp.memorized_bgm            = nil
    $game_temp.memorized_bgm_position   = 0
    $PokemonGlobal.nextBattleBGM        = nil
    $PokemonGlobal.nextBattleVictoryBGM = nil
    $PokemonGlobal.nextBattleCaptureME  = nil
    $PokemonGlobal.nextBattleBack       = nil
    $PokemonEncounters.reset_step_count
    outcome = 0 # Undecided
    pbSet(outcome_variable, outcome)
    return outcome
	end
end

#-------------------------------------------------------------------------------
# Set rules
#-------------------------------------------------------------------------------
class Game_Temp
  alias rotation_battle_add_battle_rule add_battle_rule
  def add_battle_rule(rule, var = nil)
    rules = self.battle_rules
    case rule.to_s.downcase
    when "rotationbattle" then rules["rotationBattle"] = true
    else
			rotation_battle_add_battle_rule(rule, var)
    end
  end
end

EventHandlers.add(:on_start_battle, :rotation_battle,
  proc {
		if $game_temp.battle_rules["rotationBattle"]
    	$rotation = true
			setBattleRule("triple")
		end
  }
)

EventHandlers.add(:on_end_battle, :evolve_and_black_out,
  proc { |_, _|
    $rotation = false
  }
)