class Battle::Scene
  #=============================================================================
  # Animates a trainer's sprite and party lineup hiding (if they are visible).
  # Animates a Pokémon being sent out into battle, then plays the shiny
  # animation for it if relevant.
  # sendOuts is an array; each element is itself an array: [idxBattler, pkmn]
  #=============================================================================
  def pbSendOutBattlers(sendOuts, startBattle = false)
		return if sendOuts.length == 0
		# If party balls are still appearing, wait for them to finish showing up, as
		# the FadeAnimation will make them disappear.
		while inPartyAnimation?
			pbUpdate
		end
		@briefMessage = false
		# Make all trainers and party lineups disappear (player-side trainers may
		# animate throwing a Poké Ball)
		if @battle.opposes?(sendOuts[0][0])
			fadeAnim = Animation::TrainerFade.new(@sprites, @viewport, startBattle)
		else
			fadeAnim = Animation::PlayerFade.new(@sprites, @viewport, startBattle)
		end
		# For each battler being sent out, set the battler's sprite and create two
		# animations (the Poké Ball moving and battler appearing from it, and its
		# data box appearing)
		sendOutAnims = []

		# Rotate: New
		opponent = false
    sendOuts.each_with_index do |b, i|
      pkmn = @battle.battlers[b[0]].effects[PBEffects::Illusion] || b[1]
      pbChangePokemon(b[0], pkmn)
			opponent = b[0].odd?
			pbRefresh
		end
		if $rotation
			num = opponent ? 1 : -1
			set_position_of_pokemon_rotate(num)
		end

		sendOuts.each_with_index do |b, i|
      if @battle.opposes?(b[0])
        sendOutAnim = Animation::PokeballTrainerSendOut.new(
					@sprites, @viewport, @battle.pbGetOwnerIndexFromBattlerIndex(b[0]) + 1,
					@battle.battlers[b[0]], startBattle, i
				)
      else
				sendOutAnim = Animation::PokeballPlayerSendOut.new(
					@sprites, @viewport, @battle.pbGetOwnerIndexFromBattlerIndex(b[0]) + 1,
					@battle.battlers[b[0]], startBattle, i
				)
      end
      dataBoxAnim = Animation::DataBoxAppear.new(@sprites, @viewport, b[0])
			sendOutAnims.push([sendOutAnim, dataBoxAnim, false])
    end

    # Play all animations
    loop do
      fadeAnim.update
      sendOutAnims.each do |a|
        next if a[2]
        a[0].update
        a[1].update if a[0].animDone?
        a[2] = true if a[1].animDone?
      end
      pbUpdate
      if !inPartyAnimation? && sendOutAnims.none? { |a| !a[2] }
				break
			end
    end
    fadeAnim.dispose
    sendOutAnims.each do |a|
			a[0].dispose
			a[1].dispose
		end
    # Play shininess animations for shiny Pokémon
    sendOuts.each do |b|
			next if !@battle.showAnims || !@battle.battlers[b[0]].shiny?
			if Settings::SUPER_SHINY && @battle.battlers[b[0]].super_shiny?
				pbCommonAnimation("SuperShiny", @battle.battlers[b[0]])
			else
				pbCommonAnimation("Shiny", @battle.battlers[b[0]])
			end
		end
  end

end