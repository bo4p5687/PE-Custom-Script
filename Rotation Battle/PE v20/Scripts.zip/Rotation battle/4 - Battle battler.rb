class Battle::Battler

	#=============================================================================
  # Register target
  #=============================================================================
  def pbAddTarget(targets, user, target, move, nearOnly = true, allowUser = false)
    return false if !target

		# Rotate
		if $rotation
			battlers = @battle.battlers
			rop  = @battle.rotate_player
			roop = @battle.rotate_opponent
			arr = [battlers[rop], @battle.battlers[roop]]
			return false unless arr.include?(target)
		end

		return false if target.fainted? && !move.targetsPosition?
    return false if !allowUser && target == user
		return false if nearOnly && !user.near?(target) && target != user
    targets.each { |b| return true if b.index == target.index }   # Already added
    targets.push(target)
    return true
  end

	#=============================================================================
  # Methods relating to this battler's position on the battlefield
  #=============================================================================
	# Returns an array containing all unfainted ally Pokémon.
	def allAllies
		if $rotation
			pos = @index.even? ? @battle.rotate_player : @battle.rotate_opponent
			return @battle.allSameSideBattlers(@index).reject.with_index { |b, i| b.index == @index && i == pos }
		end
    return @battle.allSameSideBattlers(@index).reject { |b| b.index == @index }
  end

	# Returns an array containing all unfainted opposing Pokémon.
  def allOpposing(notpos = false)
		if $rotation
			return @battle.allOtherSideBattlers(@index) if notpos
			pos = @index.odd? ? @battle.rotate_player : @battle.rotate_opponent
			return @battle.allOtherSideBattlers(pos)
		end
    return @battle.allOtherSideBattlers(@index)
  end

	# Update which Pokémon will gain Exp if this battler is defeated.
	def pbUpdateParticipants
		return if fainted? || !@battle.opposes?(@index)
		allOpposing($rotation).each { |b|
			@participants.push(b.pokemonIndex) if !@participants.include?(b.pokemonIndex)
		}
	end

end