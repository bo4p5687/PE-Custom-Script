class Battle::Scene

	#=============================================================================
  # The player chooses a move for a Pokémon to use
  #=============================================================================
	def rotate_fight_menu(idxBattler, megaEvoPossible = false)
    battler = @battle.battlers[idxBattler]
    cw = @sprites["fightWindow"]
    cw.battler = battler
    moveIndex = 0
    moveIndex = @lastMove[idxBattler] if battler.moves[@lastMove[idxBattler]]&.id

		# Not use this mode when rotation (not swap)
		cw.shiftMode = 0

    cw.setIndexAndMode(moveIndex, megaEvoPossible ? 1 : 0)
    needFullRefresh = true
    needRefresh = false

		# Rotate: New
		ret = nil
		cantchoosemove = !@battle.pbCanShowFightMenu?(idxBattler)

    loop do

      # Refresh view if necessary
      if needFullRefresh
        pbShowWindow(FIGHT_BOX)
        pbSelectBattler(idxBattler)
        needFullRefresh = false
      end
      if needRefresh
        if megaEvoPossible
          newMode = @battle.pbRegisteredMegaEvolution?(idxBattler) ? 2 : 1
          cw.mode = newMode if newMode != cw.mode
        end
        needRefresh = false
      end
      oldIndex = cw.index
      # General update
      pbUpdate(cw)
      # Update selected command
      if Input.trigger?(Input::LEFT)
				cw.index -= 1 if (cw.index & 1) == 1
			elsif Input.trigger?(Input::RIGHT)
				if battler.moves[cw.index + 1]&.id && (cw.index & 1) == 0
					cw.index += 1
				end
			elsif Input.trigger?(Input::UP)
				cw.index -= 2 if (cw.index & 2) == 2
			elsif Input.trigger?(Input::DOWN)
				cw.index += 2 if battler.moves[cw.index + 2]&.id && (cw.index & 2) == 0
			end
      pbPlayCursorSE if cw.index != oldIndex
      # Actions
      if Input.trigger?(Input::USE)      # Confirm choice
        pbPlayDecisionSE

				ret = :cant_choose if cantchoosemove
        break if yield cw.index, cantchoosemove, idxBattler
				
        needFullRefresh = true
        needRefresh = true
      elsif Input.trigger?(Input::BACK)   # Cancel fight menu
        pbPlayCancelSE

        break if yield -1, cantchoosemove, idxBattler

        needRefresh = true
      elsif Input.trigger?(Input::ACTION)   # Toggle Mega Evolution
        next if !megaEvoPossible
				pbPlayDecisionSE

				break if yield -2, cantchoosemove, idxBattler

				needRefresh = true
      end

			# Rotate
			if Input.triggerex?(:O) # Keyboard: O
				ret_kb = change_battler_rotation(idxBattler)
				next unless ret_kb
				# Refresh
				needFullRefresh = true
				idxBattler, cantchoosemove = ret_kb
				ret = idxBattler
				cw.index = 0
				cw.battler = @battle.battlers[idxBattler]
				cw.shiftMode = 0
				cw.setIndexAndMode(0, megaEvoPossible ? 1 : 0)
			elsif Input.triggerex?(:P) # Keyboard: P
				ret_kb = change_battler_rotation(idxBattler, true)
				next unless ret_kb
				# Refresh
				needFullRefresh = true
				idxBattler, cantchoosemove = ret_kb
				ret = idxBattler
				cw.index = 0
				cw.battler = @battle.battlers[idxBattler]
				cw.shiftMode = 0
				cw.setIndexAndMode(0, megaEvoPossible ? 1 : 0)
			end
			
    end
    @lastMove[idxBattler] = cw.index if !cantchoosemove

		# Rotate: New
		return ret
  end

	def change_battler_rotation(idxBattler, right = false)
		arr = []
		@battle.battlers.each_with_index { |b, i|
			next if !b
			next if b.fainted?
			next if i.odd? || i == idxBattler
			arr << i
		}
		# Change position
		return false if arr.size <= 0
		if right
			num = idxBattler - 2
			num = 4 if num < 0
			num -= 2 unless arr.include?(num)
			num = 4 if num < 0
		else
			num = idxBattler + 2
			num = 0 if num > 4
			num += 2 unless arr.include?(num)
			num = 0 if num > 4
		end
		# Set position
		@battle.rotate_player = num
		# SE
		pbPlayDecisionSE

		# Check if pokemon can choose move
		cant = !@battle.pbCanShowFightMenu?(num)
	
		# Set `num` using in main menu
		return num, cant
	end
end