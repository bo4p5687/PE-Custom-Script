class Battle::Scene

	# Set position when pokemon appears
	alias rotate_change_pokemon pbChangePokemon
	def pbChangePokemon(idxBattler, pkmn)
		rotate_change_pokemon(idxBattler, pkmn)

		return unless $rotation
		@store = {} if !@store
		sprite = @sprites["pokemon_#{idxBattler}"]
		@store["pkmn #{idxBattler}"] = [sprite.x, sprite.y, sprite.z]
		sprite = @sprites["shadow_#{idxBattler}"]
		@store["shadow #{idxBattler}"] = [sprite.x, sprite.y, sprite.z]
  end

	# Update in battle
	alias rotate_select_battler pbSelectBattler
	def pbSelectBattler(idxBattler, selectMode = 1)
		rotate_select_battler(idxBattler, selectMode)
		set_position_of_pokemon_rotate
  end

	# Method: change position, here
	def set_position_of_pokemon_rotate(onlyone = -1, showarr = false)
		return unless $rotation
		position1 = 0
		position2 = 0

		arrpkm = []
		arrsha = []

		zpkm = []
		zsha = []
		@battle.battlers.each_with_index { |b, i|
			if !b || b.fainted? || !@store["pkmn #{i}"]
				zpkm << nil
				zsha << nil
				next
			end
			zpkm << @store["pkmn #{i}"][2]
			zsha << @store["shadow #{i}"][2]
		}
		case onlyone
		when -1
			zeven = zpkm.select.with_index { |_, i| i.even? }.compact.sort.reverse
			zodd  = zpkm.select.with_index { |_, i| i.odd? }.compact.sort.reverse
			zeven2 = zsha.select.with_index { |_, i| i.even? }.compact.sort.reverse
			zodd2  = zsha.select.with_index { |_, i| i.odd? }.compact.sort.reverse
		# Starts battle
		when 0
			zeven = zpkm.compact.sort.reverse
			zeven2 = zsha.compact.sort.reverse
		when 1
			zodd = zpkm.compact.sort.reverse
			zodd2 = zsha.compact.sort.reverse
		end

		@battle.battlers.each_with_index { |b, i|
			next if !b
			next if b.fainted?
			if i.even?

				# Check in introduction
				next if onlyone == 1

				# Player
				if i == @battle.rotate_player
					if @sprites["pokemon_#{i}"]
						@sprites["pokemon_#{i}"].x = @store["pkmn 2"][0]
						@sprites["pokemon_#{i}"].y = @store["pkmn 2"][1]
						@sprites["pokemon_#{i}"].z = zeven[2]
					end
					if @sprites["shadow_#{i}"]
						@sprites["shadow_#{i}"].x = @store["shadow 2"][0]
						@sprites["shadow_#{i}"].y = @store["shadow 2"][1]
						@sprites["shadow_#{i}"].z = zeven2[2]
					end
					# Set color
					# Set tone
					@sprites["pokemon_#{i}"].tone = Tone.new(0, 0, 0, 0) if RotationBattle::BLACK
				else
					if @sprites["pokemon_#{i}"]
						@sprites["pokemon_#{i}"].x = @store["pkmn #{position1 * 4}"][0] - 15
						@sprites["pokemon_#{i}"].y = @store["pkmn #{position1 * 4}"][1] + 20
						@sprites["pokemon_#{i}"].z = zeven[position1]
					end
					if @sprites["shadow_#{i}"]
						@sprites["shadow_#{i}"].x = @store["shadow #{position1 * 4}"][0] - 5
						@sprites["shadow_#{i}"].y = @store["shadow #{position1 * 4}"][1] + 20
						@sprites["shadow_#{i}"].z = zeven2[position1]
					end
					position1 += 1
					# Set tone
					@sprites["pokemon_#{i}"].tone = Tone.new(0, 0, 0, 150) if RotationBattle::BLACK
				end

			else
				
				# Check in introduction
				next if onlyone == 0

				# Opponent
				if i == @battle.rotate_opponent
					if @sprites["pokemon_#{i}"]
						@sprites["pokemon_#{i}"].x = @store["pkmn 3"][0] + 5
						@sprites["pokemon_#{i}"].y = @store["pkmn 3"][1] + 2
						@sprites["pokemon_#{i}"].z = zodd[0]
					end
					if @sprites["shadow_#{i}"]
						@sprites["shadow_#{i}"].x = @store["shadow 3"][0] + 5
						@sprites["shadow_#{i}"].y = @store["shadow 3"][1] + 2
						@sprites["shadow_#{i}"].z = zodd2[0]
					end
					# Set tone
					@sprites["pokemon_#{i}"].tone = Tone.new(0, 0, 0, 0) if RotationBattle::BLACK
				else
					if @sprites["pokemon_#{i}"]
						@sprites["pokemon_#{i}"].x = @store["pkmn #{1 + position2 * 4}"][0] - 2
						@sprites["pokemon_#{i}"].y = @store["pkmn #{1 + position2 * 4}"][1] - 5
						@sprites["pokemon_#{i}"].z = zodd[position2 + 1]
					end
					if @sprites["shadow_#{i}"]
						@sprites["shadow_#{i}"].x = @store["shadow #{1 + position2 * 4}"][0] - 2
						@sprites["shadow_#{i}"].y = @store["shadow #{1 + position2 * 4}"][1] - 5
						@sprites["shadow_#{i}"].z = zodd2[position2+1]
					end
					position2 += 1
					# Set tone
					@sprites["pokemon_#{i}"].tone = Tone.new(0, 0, 0, 150) if RotationBattle::BLACK
				end
			end

			arrpkm << [@sprites["pokemon_#{i}"].x, @sprites["pokemon_#{i}"].y]
			arrsha << [@sprites["shadow_#{i}"].x, @sprites["shadow_#{i}"].y]
		}

		return arrpkm, arrsha if showarr
	end

end