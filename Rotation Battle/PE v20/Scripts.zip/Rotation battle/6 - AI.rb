class Battle::AI
	def should_rotate_position_of_pokemon(old, player = false)
		arr = rotate_array(old)
		if @battle.wildBattle?
			random = rand(100) < 5
			@battle.rotate_opponent = arr.sample if random
		else
			skill = @battle.pbGetOwnerFromBattlerIndex(old).skill_level || 0
			num =
				case skill
				when 0...PBTrainerAI.minimumSkill then 100
				when PBTrainerAI.minimumSkill...PBTrainerAI.mediumSkill then 70
				when PBTrainerAI.mediumSkill...PBTrainerAI.highSkill then 30
				when PBTrainerAI.highSkill...PBTrainerAI.bestSkill then 10
				when PBTrainerAI.bestSkill then 1
				else
					100
				end
			random = rand(num) <= num / 2
			if player
				@battle.rotate_player = arr.sample if random
			else
				@battle.rotate_opponent = arr.sample if random
			end
		end
	end

	def rotate_array(old)
		arr = []
		even = old.even?
		@battle.battlers.each_with_index { |b, i|
			next if !b
			next if b.fainted?
			even ? (next if i.odd?) : (next if i.even?)
			arr << i
		}
		return arr
	end
end