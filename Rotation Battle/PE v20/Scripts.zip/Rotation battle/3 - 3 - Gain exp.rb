class Battle
	def pbRecordBattlerAsParticipated(battler)
    # Record money-doubling effect of Amulet Coin/Luck Incense
    if !battler.opposes? && [:AMULETCOIN, :LUCKINCENSE].include?(battler.item_id)
      @field.effects[PBEffects::AmuletCoin] = true
    end

    # Update battlers' participants (who will gain Exp/EVs when a battler faints)
    allBattlers(true).each { |b| b.pbUpdateParticipants } # Check Rotation
		
  end
end