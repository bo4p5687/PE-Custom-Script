#===============================================================================
# Shows a Pokémon being sent out on the player's side (including by a partner).
# Includes the Poké Ball being thrown.
#===============================================================================
class Battle::Scene::Animation::PokeballPlayerSendOut
  def createProcesses
    batSprite = @sprites["pokemon_#{@battler.index}"]
    shaSprite = @sprites["shadow_#{@battler.index}"]
    traSprite = @sprites["player_#{@idxTrainer}"]
    # Calculate the Poké Ball graphic to use
    poke_ball = (batSprite.pkmn) ? batSprite.pkmn.poke_ball : nil
    # Calculate the color to turn the battler sprite
    col = getBattlerColorFromPokeBall(poke_ball)
    col.alpha = 255
    # Calculate start and end coordinates for battler sprite movement

		# Rotate
		num = 
			if $rotation
				if @showingTrainer
					case @battler.index
					when 0 then 2
					when 2 then 0
					else
						@battler.index
					end
				else
					2
				end
			else
				@battler.index
			end
		ballPos = Battle::Scene.pbBattlerPosition(num, batSprite.sideSize)

		battlerStartX = ballPos[0]   # Is also where the Ball needs to end
		battlerStartY = ballPos[1]   # Is also where the Ball needs to end + 18
		battlerEndX = batSprite.x
		battlerEndY = batSprite.y
		# Calculate start and end coordinates for Poké Ball sprite movement
		ballStartX = -6
		ballStartY = 202
		ballMidX = 0   # Unused in trajectory calculation
		ballMidY = battlerStartY - 144
		# Set up Poké Ball sprite
		ball = addBallSprite(ballStartX, ballStartY, poke_ball)
		ball.setZ(0, 25)
		ball.setVisible(0, false)
		# Poké Ball tracking the player's hand animation (if trainer is visible)
		if @showingTrainer && traSprite && traSprite.x > 0
			ball.setZ(0, traSprite.z - 1)
			ballStartX, ballStartY = ballTracksHand(ball, traSprite)
		end
		delay = ball.totalDuration   # 0 or 7
		# Poké Ball trajectory animation
		createBallTrajectory(ball, delay, 12,
												ballStartX, ballStartY, ballMidX, ballMidY, battlerStartX, battlerStartY - 18)
		ball.setZ(9, batSprite.z - 1)
		delay = ball.totalDuration + 4
		delay += 10 * @idxOrder   # Stagger appearances if multiple Pokémon are sent out at once
		ballOpenUp(ball, delay - 2, poke_ball)
		ballBurst(delay, ball, battlerStartX, battlerStartY - 18, poke_ball)
		ball.moveOpacity(delay + 2, 2, 0)
		# Set up battler sprite
		battler = addSprite(batSprite, PictureOrigin::BOTTOM)
		battler.setXY(0, battlerStartX, battlerStartY)
		battler.setZoom(0, 0)
		battler.setColor(0, col)
		# Battler animation
		battlerAppear(battler, delay, battlerEndX, battlerEndY, batSprite, col)

		# Rotation: New
		if $rotation
			if RotationBattle::BLACK && @showingTrainer && @battler.index != 0
				tone = Tone.new(0, 0, 0, 150)
				battler.moveTone(delay + 15, 10, tone)
			end
		end

		if @shadowVisible
			# Set up shadow sprite
			shadow = addSprite(shaSprite, PictureOrigin::CENTER)
			shadow.setOpacity(0, 0)
			# Shadow animation
			shadow.setVisible(delay, @shadowVisible)
			shadow.moveOpacity(delay + 5, 10, 255)
    end
  end
end



#===============================================================================
# Shows a Pokémon being sent out on the opposing side.
# Includes the Poké Ball being "thrown" (although here the Poké Ball just
# appears in the spot where it opens up rather than being thrown to there).
#===============================================================================
class Battle::Scene::Animation::PokeballTrainerSendOut
  def createProcesses
    batSprite = @sprites["pokemon_#{@battler.index}"]
    shaSprite = @sprites["shadow_#{@battler.index}"]
    # Calculate the Poké Ball graphic to use
    poke_ball = (batSprite.pkmn) ? batSprite.pkmn.poke_ball : nil
    # Calculate the color to turn the battler sprite
    col = getBattlerColorFromPokeBall(poke_ball)
    col.alpha = 255
    # Calculate start and end coordinates for battler sprite movement

		# Rotate
		num = 
			if $rotation
				if @showingTrainer
					case @battler.index
					when 1 then 3
					when 3 then 1
					else
						@battler.index
					end
				else
					3
				end
			else
				@battler.index
			end
		ballPos = Battle::Scene.pbBattlerPosition(num, batSprite.sideSize)

		battlerStartX = ballPos[0]
		battlerStartY = ballPos[1]
		battlerEndX = batSprite.x
		battlerEndY = batSprite.y
		# Set up Poké Ball sprite
		ball = addBallSprite(0, 0, poke_ball)
		ball.setZ(0, batSprite.z - 1)
		# Poké Ball animation
		createBallTrajectory(ball, battlerStartX, battlerStartY)
		delay = ball.totalDuration + 6
		delay += 10 if @showingTrainer   # Give time for trainer to slide off screen
		delay += 10 * @idxOrder   # Stagger appearances if multiple Pokémon are sent out at once
		ballOpenUp(ball, delay - 2, poke_ball)
		ballBurst(delay, ball, battlerStartX, battlerStartY - 18, poke_ball)
		ball.moveOpacity(delay + 2, 2, 0)
		# Set up battler sprite
		battler = addSprite(batSprite, PictureOrigin::BOTTOM)
		battler.setXY(0, battlerStartX, battlerStartY)
		battler.setZoom(0, 0)
		battler.setColor(0, col)
		# Battler animation
		battlerAppear(battler, delay, battlerEndX, battlerEndY, batSprite, col)

		# Rotation: New
		if $rotation
			if RotationBattle::BLACK && @showingTrainer && @battler.index != 1
				tone = Tone.new(0, 0, 0, 150)
				battler.moveTone(delay + 15, 10, tone)
			end
		end

		if @shadowVisible
			# Set up shadow sprite
			shadow = addSprite(shaSprite, PictureOrigin::CENTER)
			shadow.setOpacity(0, 0)
			# Shadow animation
			shadow.setVisible(delay, @shadowVisible)
			shadow.moveOpacity(delay + 5, 10, 255)
		end
  end
end

#===============================================================================
# Shows a Pokémon being recalled into its Poké Ball
#===============================================================================
class Battle::Scene::Animation::BattlerRecall
  def createProcesses
    batSprite = @sprites["pokemon_#{@idxBattler}"]
    shaSprite = @sprites["shadow_#{@idxBattler}"]
    # Calculate the Poké Ball graphic to use
    poke_ball = (batSprite.pkmn) ? batSprite.pkmn.poke_ball : nil
    # Calculate the color to turn the battler sprite
    col = getBattlerColorFromPokeBall(poke_ball)
    col.alpha = 0
    # Calculate end coordinates for battler sprite movement

		# Rotate
		num = 
			if $rotation
				case @idxBattler
				when 0, 2, 4 then 2
				when 1, 3, 5 then 3
				else
					@idxBattler
				end
			else
				@idxBattler
			end
    ballPos = Battle::Scene.pbBattlerPosition(num, batSprite.sideSize)

    battlerEndX = ballPos[0]
    battlerEndY = ballPos[1]
    # Set up battler sprite
    battler = addSprite(batSprite, PictureOrigin::BOTTOM)
    battler.setVisible(0, true)
    battler.setColor(0, col)
    # Set up Poké Ball sprite
    ball = addBallSprite(battlerEndX, battlerEndY, poke_ball)
    ball.setZ(0, batSprite.z + 1)
    # Poké Ball animation
    ballOpenUp(ball, 0, poke_ball)
    delay = ball.totalDuration
    ballBurstRecall(delay, ball, battlerEndX, battlerEndY, poke_ball)
    ball.moveOpacity(10, 2, 0)
    # Battler animation
    battlerAbsorb(battler, delay, battlerEndX, battlerEndY, col)
    if shaSprite.visible
      # Set up shadow sprite
      shadow = addSprite(shaSprite, PictureOrigin::CENTER)
      # Shadow animation
      shadow.moveOpacity(0, 10, 0)
      shadow.setVisible(delay, false)
    end
  end
end