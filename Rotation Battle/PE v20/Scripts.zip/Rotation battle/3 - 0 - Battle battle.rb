class Battle
  attr_accessor :rotate_player, :rotate_opponent

  def pbSetUpSides
    ret = [[],[]]

		# Rotate
		set = [false, false]

    2.times { |side|
      # Set up wild Pokémon
      if side == 1 && wildBattle?
        pbParty(1).each_with_index do |pkmn, idxPkmn|
					pbCreateBattler((2 * idxPkmn) + side, pkmn, idxPkmn)

					# Rotate
					@rotate_opponent = 2 * idxPkmn + side unless set[1]
					set[1] = true

          # Changes the Pokémon's form upon entering battle (if it should)
          @peer.pbOnEnteringBattle(self, @battlers[(2 * idxPkmn) + side], pkmn, true)
					pbSetSeen(@battlers[(2 * idxPkmn) + side])
					@usedInBattle[side][idxPkmn] = true
        end
        next
      end
      # Set up player's Pokémon and trainers' Pokémon
      trainer = side == 0 ? @player : @opponent
      requireds = []
      # Find out how many Pokémon each trainer on side needs to have
      @sideSizes[side].times do |i|
				idxTrainer = pbGetOwnerIndexFromBattlerIndex((i * 2) + side)
				requireds[idxTrainer] = 0 if requireds[idxTrainer].nil?
				requireds[idxTrainer] += 1
			end
			# For each trainer in turn, find the needed number of Pokémon for them to
			# send out, and initialize them
			battlerNumber = 0
			partyOrder = pbPartyOrder(side)
			starts = pbPartyStarts(side)
			trainer.each_with_index do |_t, idxTrainer|
				ret[side][idxTrainer] = []
				eachInTeam(side, idxTrainer) do |pkmn, idxPkmn|
					next if !pkmn.able?
					idxBattler = (2 * battlerNumber) + side
					pbCreateBattler(idxBattler, pkmn, idxPkmn)

					# Rotate
					if !set[side]
						side == 0 ? (@rotate_player = idxBattler) : (@rotate_opponent = idxBattler)
						set[side] = true
					end

          ret[side][idxTrainer] << idxBattler
					if idxPkmn != starts[idxTrainer] + battlerNumber
						idxOther = starts[idxTrainer] + battlerNumber
						partyOrder[idxPkmn], partyOrder[idxOther] = partyOrder[idxOther], partyOrder[idxPkmn]
					end
					battlerNumber += 1
					break if ret[side][idxTrainer].length >= requireds[idxTrainer]
        end
      end
    }
    return ret
  end

	#=============================================================================
  # Iterate through battlers
  #=============================================================================
  def allBattlers(all = false)
		if $rotation && !all
			return @battlers.select.with_index { |b, i| b && !b.fainted? && (i == @rotate_player || i == @rotate_opponent) }
		end
		return @battlers.select { |b| b && !b.fainted? }
  end

	def allSameSideBattlers(idxBattler = 0, notall = true)
		idxBattler = idxBattler.index if idxBattler.respond_to?("index")
		ret = @battlers.select { |b| b && !b.fainted? && !b.opposes?(idxBattler) }
		return ret unless $rotation
		return ret unless notall
		if idxBattler.even?
			ret.select! { |b| b.index == @rotate_player }
		else
			ret.select! { |b| b.index == @rotate_opponent }
		end
		return ret
	end

	def allOtherSideBattlers(idxBattler = 0, notall = true)
		idxBattler = idxBattler.index if idxBattler.respond_to?("index")
	 	ret = @battlers.select { |b| b && !b.fainted? && b.opposes?(idxBattler) }
		return ret unless $rotation
		return ret unless notall
		if idxBattler.even?
			ret.select! { |b| b.index == @rotate_opponent }
		else
			ret.select! { |b| b.index == @rotate_player }
		end
		return ret
	end

	def pbOpposingBattlerCount(idxBattler = 0) = allOtherSideBattlers(idxBattler, false).size

	# This method only counts the player's Pokémon, not a partner trainer's.
	def pbPlayerBattlerCount = allSameSideBattlers(0, false).select { |b| b.pbOwnedByPlayer? }.size

	#--------------------------------------------------------------------------------#
	#                                                                                #
	#--------------------------------------------------------------------------------#
	# Returns the battler representing the Pokémon at index idxParty in its party,
  # on the same side as a battler with battler index of idxBattlerOther.
  def pbFindBattler(idxParty, idxBattlerOther = 0)
		allSameSideBattlers(idxBattlerOther, false).each { |b| return b if b.pokemonIndex == idxParty }
		return nil
	end

  #=============================================================================
  # Command phase
  #=============================================================================
	alias rotate_command_phase_loop pbCommandPhaseLoop
  def pbCommandPhaseLoop(isPlayer)
		# Rotate
		# Old
		if !$rotation
			rotate_command_phase_loop(isPlayer)
			return
		end

    # NOTE: Doing some things (e.g. running, throwing a Poké Ball) takes up all
    #       your actions in a round.
    idxBattler = -1

		oldidxBattler = -1

		# Rotate
		# Check if pokemon chose action
		doneplayer = false
		doneoppose = false
		fight = false
		move = -1
		arr = [@rotate_player, @rotate_opponent]

    loop do
      break if @decision != 0   # Battle ended, stop choosing actions
      idxBattler += 1
      break if idxBattler >= @battlers.length

			# Rotate
			next unless arr.include?(idxBattler)
			break if doneoppose && doneplayer

      next if !@battlers[idxBattler] || pbOwnedByPlayer?(idxBattler) != isPlayer
			next if @choices[idxBattler][0] != :None    # Action is forced, can't choose one
			next if !pbCanShowCommands?(idxBattler)   # Action is forced, can't choose one
			# AI controls this battler
      if @controlPlayer # Auto-player
				
				if !doneplayer && idxBattler == @rotate_player
					@battleAI.should_rotate_position_of_pokemon(idxBattler, true)
					@battleAI.pbDefaultChooseEnemyCommand(@rotate_player)
					# Set true
					doneplayer = true
				end

				next
			elsif !pbOwnedByPlayer?(idxBattler) # AI

				if !doneoppose && idxBattler == @rotate_opponent
					@battleAI.should_rotate_position_of_pokemon(idxBattler)
					@battleAI.pbDefaultChooseEnemyCommand(@rotate_opponent)
					# Set true
					doneoppose = true
				end

        next
      end

			# Player chooses an action
      commandsEnd = false   # Whether to cancel choosing all other actions this round

			# Rotate
			next if !doneplayer && idxBattler != @rotate_player

      loop do

				# Rotate
				break if doneplayer

        cmd = pbCommandMenu(idxBattler, true)
        # If being Sky Dropped, can't do anything except use a move
        if cmd > 0 && @battlers[idxBattler].effects[PBEffects::SkyDrop] >= 0
					pbDisplay(_INTL("Sky Drop won't let {1} go!", @battlers[idxBattler].pbThis(true)))
					next
				end
        case cmd
        when 0    # Fight
					
					# Rotate: New
					value = rotate_fight_menu(idxBattler)
					if value.is_a?(Array)
						if value[1].is_a?(Numeric)
							# Reset battlers
							oldidxBattler = idxBattler.clone
							idxBattler = value[1].clone
						end
						break if value[0]
					else
						break if value
					end
					
        when 1    # Bag
          if pbItemMenu(idxBattler, true)
            commandsEnd = true if pbItemUsesAllActions?(@choices[idxBattler][1])
            break
          end
        when 2    # Pokémon
          break if pbPartyMenu(idxBattler)
        when 3    # Run
          # NOTE: "Run" is only an available option for the first battler the
          #       player chooses an action for in a round. Attempting to run
          #       from battle prevents you from choosing any other actions in
          #       that round.
          if pbRunMenu(idxBattler)
            commandsEnd = true
            break
          end
        when 4    # Call
          break if pbCallMenu(idxBattler)
        when -2   # Debug
          pbDebugMenu
          next
        end
        pbCancelChoice(idxBattler)
      end

			# Rotate: set value
			idxBattler = oldidxBattler if oldidxBattler != -1 && !doneplayer
			doneplayer = true
			
      break if commandsEnd
    end

		# New
		choose_target_rotate
  end
  
	#------------#
	# Fight menu #
	#------------#
	def rotate_fight_menu(idxBattler)
		# Regular move selection
    ret = false

		# Rotate: New
		change = @scene.rotate_fight_menu(idxBattler, pbCanMegaEvolve?(idxBattler)) { |cmd, cantchoose, index|
			
      case cmd
      when -1   # Cancel
      when -2   # Toggle Mega Evolution

				# Return when pokemon can't use this method (reason: can't choose)
				next false if cantchoose

        pbToggleRegisteredMegaEvolution(index)
        next false
      else      # Chose a move to use

				# It can't choose and if player chooses move, auto-choose triggers on
				if cantchoose
					ret = true
					next true
				end

        next false if cmd < 0 || !@battlers[index].moves[cmd] || !@battlers[index].moves[cmd].id
				next false if !pbRegisterMove(index, cmd)

				# Set move
				pbChooseTarget(@battlers[index], @battlers[index].moves[cmd])

        ret = true
      end
      next true
    }
		# Auto-use Encored move or no moves choosable, so can choose other pokemon/ or use struggle
		return pbAutoChooseMove(idxBattler) if change == :cant_choose
		return ret, change
	end
  
	#---------------#
	# Choose target #
	#---------------#
  def pbChooseTarget(battler, move)

		# Rotate
		if $rotation
			idxTarget = @rotate_opponent
		else
			target_data = move.pbTarget(battler)
			idxTarget = @scene.pbChooseTarget(battler.index, target_data)
			return false if idxTarget<0
		end

    pbRegisterTarget(battler.index, idxTarget)
    return true
  end

	def choose_target_rotate
		return unless $rotation
		battler = @battlers[@rotate_player]
		pbRegisterTarget(battler.index, @rotate_opponent)
	end

	#--------------#
	# Near battler #
	#--------------#
	def nearBattlers?(idxBattler1, idxBattler2)
		return false if idxBattler1 == idxBattler2

		# Rotate
		return true if $rotation

		return true if pbSideSize(0) <= 2 && pbSideSize(1) <= 2
		# Get all pairs of battler positions that are not close to each other
		pairsArray = [[0, 4], [1, 5]]   # Covers 3v1 and 1v3
		case pbSideSize(0)
		when 3
			case pbSideSize(1)
			when 3   # 3v3 (triple)
				pairsArray.push([0, 1])
				pairsArray.push([4, 5])
			when 2   # 3v2
				pairsArray.push([0, 1])
				pairsArray.push([3, 4])
			end
		when 2       # 2v3
			pairsArray.push([0, 1])
			pairsArray.push([2, 5])
		end
		# See if any pair matches the two battlers being assessed
		pairsArray.each { |pair| return false if pair.include?(idxBattler1) && pair.include?(idxBattler2) }
    return true
  end

end