class WildBattle
	class << self
		alias rotation_battle_start_core start_core
	end

	def self.start_core(*args)
		outcome_variable = $game_temp.battle_rules["outcomeVar"] || 1
    can_lose         = $game_temp.battle_rules["canLose"] || false
    if BattleCreationHelperMethods.skip_battle?
      return BattleCreationHelperMethods.skip_battle(outcome_variable)
    end
    EventHandlers.trigger(:on_start_battle)
		# Check
		if $rotation
			# Foe
			foe_party = WildBattle.generate_foes(*args)
			if foe_party.size < 3
				pbMessage(_INTL("Foe party doesn't have enough pokemon..."))
				return RotationBattle.skip_battle(outcome_variable)
			end
			# Player
			_, _, player_party, _ = BattleCreationHelperMethods.set_up_player_trainers(foe_party)
			if player_party.size < 3
				pbMessage(_INTL("Your party doesn't have enough pokemon..."))
				return RotationBattle.skip_battle(outcome_variable)
			end
		end
		# PE
		return rotation_battle_start_core(*args)
	end
end