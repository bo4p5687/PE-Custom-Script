module FameChecker
	class Show

		# Maximum number of persons can show
		def maxShowPerson = 6

		# Position of arrow
		def posArrow
			max = @person.size
			maxshow = maxShowPerson
			return @posperson if max > 0 && max < maxshow
			return @posperson if @posperson < maxshow / 2
			return maxshow / 2 - 1 if @posperson < max - maxshow / 2
			return (maxshow - 1) - ((max - 1) - @posperson)
		end

		# Moved 'casette'
		def movedBigImage(right=false)
			if right
				return true if @sprites["casette"].x >= Graphics.width
			else
				return true if @sprites["casette"].x <= (Graphics.width-@sprites["casette"].bitmap.width)
			end
			return false
		end

		# Check input when choosing person
		def inputPerson
			return if @choseperson || @introduce
			max = @person.size
			maxshow = maxShowPerson
			# Break and exit
			@exit = true if checkInput(Input::BACK)
			# Next, see information
			if checkInput(Input::USE)
				@choseperson = true
				# Move 'Hide'
				moveHide
			end
			# See 'introduction'
			if checkInput(Input::ACTION)
				# Character
				setCharacter
				# Set again bitmap
				setCharacter
				# Move image
				moveBigImage if !movedBigImage
				@introduce = true
			# Up / Down
			elsif checkInput(Input::UP)
				@posperson -= 1
				@posperson  = @person.size - 1 if @posperson < 0
				# Show information
				showInfor
			elsif checkInput(Input::DOWN)
				@posperson += 1
				@posperson  = 0 if @posperson >= @person.size
				# Show information
				showInfor
			end
		end

		# Check input when choosing information
		def inputInfor
			return if !@choseperson || @introduce
			# Return first scene
			if checkInput(Input::BACK)
				# Reset position
				@posinfor = 0
				@choseperson = false
			end
			# Show information
			readInfor if checkInput(Input::USE)
			# Up / Down / Left / Right
			if checkInput(Input::UP)
				@posinfor -= 3
				@posinfor += 6 if @posinfor<0
				# Move 'hide'
				moveHide
			elsif checkInput(Input::DOWN)
				@posinfor += 3
				@posinfor -= 6 if @posinfor>=6
				# Move 'hide'
				moveHide
			elsif checkInput(Input::LEFT)
				@posinfor -= 1
				@posinfor  = 5 if @posinfor<0
				# Move 'hide'
				moveHide
			elsif checkInput(Input::RIGHT)
				@posinfor += 1
				@posinfor  = 0 if @posinfor>=6
				# Move 'hide'
				moveHide
			end
		end

		# Check input when introducing
		def inputIntroduce
			return if !@introduce
			# Cancel
			if checkInput(Input::BACK)
				# Move image
				moveBigImage(true) if !movedBigImage(true)
				@sprites["casette circle"].angle = 0
				@introduce = false
			end
			# Play introduction
			introduce if checkInput(Input::USE)
		end

	end
end