module FameChecker
	class Show

		def show
			loop do
				# Update
				update_ingame
				# Show
				progress
				break if @exit
			end
		end

		def progress
			# Draw background
			drawScene
			# Show information
			showInfor
			# Draw 'casette'
			drawBigImage
			# Check quantity of person
			if @person.size<=0
				@exit = true if checkInput(Input::BACK)
				return
			end
			# Progress - chose person
			choosePeson
		end
		
		def choosePeson
			loop do
				# Update
				update_ingame
				# Check scene and change it
				@scene = @choseperson ? 2 : @introduce ? 3 : 1
				changeScene
				# Show list to choose
				showList
				# Show arrow list (change graphics)
				arrowList
				# Show signal
				signal
				# Rectangle 'choose'
				chooseRect
				# Set animate
				@animation += 1
				setAnimate
				# Input
				inputPerson
				inputInfor
				inputIntroduce
				# Break
				break if @exit
			end
		end

	end
end