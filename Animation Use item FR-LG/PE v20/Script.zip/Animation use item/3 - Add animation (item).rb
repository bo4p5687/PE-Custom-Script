#--------------------------------------------------------------------------------------------------
# Read file 'readme' to learn how to edit this file
#--------------------------------------------------------------------------------------------------
# Item
#--------------------------------------------------------------------------------------------------
# 0. TM/HM
# Need to add in script section. Change the script in script Section into this script below.
# Don't delete =begin and =end. It's just example if you dont know how to edit.
=begin
ItemHandlers::UseFromBag.addIf(proc { |item| GameData::Item.get(item).is_machine? },
  proc { |item|
    if $player.pokemon_count == 0
      pbMessage(_INTL("There is no Pokémon."))
      next 0
    end
    item_data = GameData::Item.get(item)
    move = item_data.move
    next 0 if !move
		pbMessage(_INTL("\\se[PC access]You booted up {1}.\1", item_data.name))
    next 0 if !pbConfirmMessage(_INTL("Do you want to teach {1} to a Pokémon?", GameData::Move.get(move).name))

		# Add animation
    next 1 if pbMoveTutorChoose(move, nil, true, item_data.is_TR?, item_data)

    next 0
  }
)
=end

# 1. Evolution stone
# Need to add in script section. Change the script in script Section into this script below.
# Don't delete =begin and =end. It's just example if you dont know how to edit.
=begin
ItemHandlers::UseOnPokemon.addIf(proc { |item| GameData::Item.get(item).is_evolution_stone? },
  proc { |item, qty, pkmn, scene|
    if pkmn.shadowPokemon?
      scene.pbDisplay(_INTL("It won't have any effect."))
      next false
    end
    newspecies = pkmn.check_evolution_on_use_item(item)
    if newspecies

			# Add animation
			scene.pbUseAnimations(item, pkmn)
			scene.endUseAnimations

      pbFadeOutInWithMusic {
        evo = PokemonEvolutionScene.new
        evo.pbStartScreen(pkmn, newspecies)
        evo.pbEvolution(false)
        evo.pbEndScreen
        if scene.is_a?(PokemonPartyScreen)
          scene.pbRefreshAnnotations(proc { |p| !p.check_evolution_on_use_item(item).nil? })
          scene.pbRefresh
        end
      }
      next true
    end
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  }
)
=end

# 2. Item recover HP (Potion, Max potion, etc)
def pbHPItem(item, pkmn, restoreHP, scene)
  if !pkmn.able? || pkmn.hp == pkmn.totalhp
    scene.pbDisplay(_INTL("It won't have any effect."))
    return false
  end
  hpGain = pbItemRestoreHP(pkmn, restoreHP)

	# Start animation
	scene.pbUseAnimations(item, pkmn)

  scene.pbRefresh
  scene.pbDisplay(_INTL("{1}'s HP was restored by {2} points.", pkmn.name, hpGain))

	# Finish animation
	scene.endUseAnimations

  return true
end

ItemHandlers::UseOnPokemon.add(:POTION, proc { |item, qty, pkmn, scene|
	next pbHPItem(item, pkmn, 20, scene)
})
# add more below this line if you have other

# 3. Item heals status (Awakening, Antidote, etc)
ItemHandlers::UseOnPokemon.add(:AWAKENING, proc { |item, qty, pkmn, scene|
  if pkmn.fainted? || pkmn.status != :SLEEP
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  end
	scene.pbUseAnimations(item, pkmn) # Start animation
  pkmn.heal_status
  scene.pbRefresh
  scene.pbDisplay(_INTL("{1} woke up.", pkmn.name))
	scene.endUseAnimations # Finish animation
  next true
})

ItemHandlers::UseOnPokemon.add(:MAXREVIVE, proc { |item, qty, pkmn, scene|
  if !pkmn.fainted?
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  end
	scene.pbUseAnimations(item, pkmn) # Start animation
  pkmn.heal_HP
  pkmn.heal_status
  scene.pbRefresh
  scene.pbDisplay(_INTL("{1}'s HP was restored.", pkmn.name))
	scene.endUseAnimations # Finish animation
  next true
})
# add more below this line if you have other

# 4. Item recover PP (Ether, Max ether, etc)
ItemHandlers::UseOnPokemon.add(:ETHER, proc { |item, qty, pkmn, scene|
  move = scene.pbChooseMove(pkmn, _INTL("Restore which move?"))
  next false if move < 0
  if pbRestorePP(pkmn, move, 10) == 0
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  end
	scene.pbUseAnimations(item, pkmn) # Start animation
  scene.pbDisplay(_INTL("PP was restored."))
	scene.endUseAnimations # Finish animation
  next true
})


ItemHandlers::UseOnPokemon.add(:PPUP, proc { |item, qty, pkmn, scene|
  move = scene.pbChooseMove(pkmn, _INTL("Boost PP of which move?"))
  if move >= 0
    if pkmn.moves[move].total_pp <= 1 || pkmn.moves[move].ppup >= 3
      scene.pbDisplay(_INTL("It won't have any effect."))
      next false
    end
		scene.pbUseAnimations(item, pkmn) # Start animation
    pkmn.moves[move].ppup += 1
    movename = pkmn.moves[move].name
    scene.pbDisplay(_INTL("{1}'s PP increased.", movename))
		scene.endUseAnimations # Finish animation
    next true
  end
  next false
})

# add more below this line if you have other

# 5. The other
# add more below this line if you have other