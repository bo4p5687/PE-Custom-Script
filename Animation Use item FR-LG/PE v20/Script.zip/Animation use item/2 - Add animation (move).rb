#-------------------------------------------------#
# If you use script: Animation "change form".
# Read this line: Add for using "Animation Change form".
# Do like guide.
#                Thanks!
#-------------------------------------------------#
#--------------------------------------------------------------------------------------------------
# TM/HM
#--------------------------------------------------------------------------------------------------
def pbLearnMove(pkmn, move, ignore_if_known = false, by_machine = false, item = nil, &block)
  return false if !pkmn
  move = GameData::Move.get(move).id
  if pkmn.egg? && !$DEBUG
    pbMessage(_INTL("Eggs can't be taught any moves."), &block)
    return false
  elsif pkmn.shadowPokemon?
    pbMessage(_INTL("Shadow Pokémon can't be taught any moves."), &block)
    return false
  end
  pkmn_name = pkmn.name
  move_name = GameData::Move.get(move).name
  if pkmn.hasMove?(move)
    pbMessage(_INTL("{1} already knows {2}.", pkmn_name, move_name), &block) if !ignore_if_known
    return false
  elsif pkmn.numMoves < Pokemon::MAX_MOVES
    pkmn.learn_move(move)

		# Animation
		if by_machine && !item.nil?
			UseAnimations.new.animationTMHM(item, pkmn, pkmn_name, nil, move_name, false, &block)
		else
			pbMessage(_INTL("\\se[]{1} learned {2}!\\se[Pkmn move learnt]", pkmn_name, move_name), &block)
    end

		return true
  end
  pbMessage(_INTL("{1} wants to learn {2}, but it already knows {3} moves.\1",
                  pkmn_name, move_name, pkmn.numMoves.to_word), &block)
  if pbConfirmMessage(_INTL("Should {1} forget a move to learn {2}?", pkmn_name, move_name), &block)
    loop do
      move_index = pbForgetMove(pkmn, move)
      if move_index >= 0
        old_move_name = pkmn.moves[move_index].name
        old_move_pp = pkmn.moves[move_index].pp
        pkmn.moves[move_index] = Pokemon::Move.new(move)   # Replaces current/total PP
        if by_machine && Settings::TAUGHT_MACHINES_KEEP_OLD_PP
          pkmn.moves[move_index].pp = [old_move_pp, pkmn.moves[move_index].total_pp].min
        end

				# Animation
				if by_machine && !item.nil?
					UseAnimations.new.animationTMHM(item, pkmn, pkmn_name, old_move_name, move_name, true, &block)
				else
					pbMessage(_INTL("1, 2, and...\\wt[16] ...\\wt[16] ...\\wt[16] Ta-da!\\se[Battle ball drop]\1"), &block)
					pbMessage(_INTL("{1} forgot how to use {2}.\\nAnd...\1", pkmn_name, old_move_name), &block)
					pbMessage(_INTL("\\se[]{1} learned {2}!\\se[Pkmn move learnt]", pkmn_name, move_name), &block)
        end

				pkmn.changeHappiness("machine") if by_machine
        return true
      elsif pbConfirmMessage(_INTL("Give up on learning {1}?", move_name), &block)
        pbMessage(_INTL("{1} did not learn {2}.", pkmn_name, move_name), &block)
        return false
      end
    end
  else
    pbMessage(_INTL("{1} did not learn {2}.", pkmn_name, move_name), &block)
  end
  return false
end

#-------------------------------------------------------------------------------------
# Modify use item in the screen 'party'
#-------------------------------------------------------------------------------------
def pbUseItemOnPokemon(item, pkmn, scene)
  itm = GameData::Item.get(item)
  # TM or HM
  if itm.is_machine?
    machine = itm.move
    return false if !machine
    movename = GameData::Move.get(machine).name
    if pkmn.shadowPokemon?
      pbMessage(_INTL("Shadow Pokémon can't be taught any moves.")) { scene.pbUpdate }
    elsif !pkmn.compatible_with_move?(machine)
      pbMessage(_INTL("{1} can't learn {2}.", pkmn.name, movename)) { scene.pbUpdate }
    else
      pbMessage(_INTL("\\se[PC access]You booted up {1}.\1", itm.name)) { scene.pbUpdate }
      if pbConfirmMessage(_INTL("Do you want to teach {1} to {2}?", movename, pkmn.name)) { scene.pbUpdate }
        
				# Animation item #
				if pbLearnMove(pkmn, machine, false, true, item) { scene.pbUpdate }

          $bag.remove(item) if itm.consumed_after_use?
          return true
        end
      end
    end
    return false
  end
  # Other item
  qty = 1
  max_at_once = ItemHandlers.triggerUseOnPokemonMaximum(item, pkmn)
  max_at_once = [max_at_once, $bag.quantity(item)].min
  if max_at_once > 1
    qty = scene.scene.pbChooseNumber(
      _INTL("How many {1} do you want to use?", itm.name), max_at_once
    )
    scene.scene.pbSetHelpText("") if scene.is_a?(PokemonPartyScreen)
  end
  return false if qty <= 0

	# Add for using "Animation Change form" #

	# If you use "Animation Change form", delete # before these line (below) (if it exists) #
	chosen = $player.party.find_index { |i| i == pkmn }
	ret = ItemHandlers.triggerAnimationForm(item, pkmn, scene, chosen)
	ret = ItemHandlers.triggerUseOnPokemon(item, qty, pkmn, scene) if !ret

	# If you use "Animation Change form", add # before this line (below) (if it doesn't exists) #
	# ret = ItemHandlers.triggerUseOnPokemon(item, qty, pkmn, scene)

  scene.pbClearAnnotations
  scene.pbHardRefresh
  if ret && itm.consumed_after_use?
    $bag.remove(item, qty)
    if !$bag.has?(item)
      pbMessage(_INTL("You used your last {1}.", itm.name)) { scene.pbUpdate }
    end
  end
  return ret
end

#-------------------------------------------------------------------------------------
# Use item from bag
#-------------------------------------------------------------------------------------
def pbMoveTutorChoose(move, movelist = nil, bymachine = false, oneusemachine = false, item = nil)
  ret = false
  move = GameData::Move.get(move).id
  if movelist.is_a?(Array)
    movelist.map! { |m| GameData::Move.get(m).id }
  end
  pbFadeOutIn {
    movename = GameData::Move.get(move).name
    annot = pbMoveTutorAnnotations(move, movelist)
    scene = PokemonParty_Scene.new
    screen = PokemonPartyScreen.new(scene, $player.party)
    screen.pbStartScene(_INTL("Teach which Pokémon?"), false, annot)
    loop do
      chosen = screen.pbChoosePokemon
      break if chosen < 0
      pokemon = $player.party[chosen]
      if pokemon.egg?
        pbMessage(_INTL("Eggs can't be taught any moves.")) { screen.pbUpdate }
      elsif pokemon.shadowPokemon?
        pbMessage(_INTL("Shadow Pokémon can't be taught any moves.")) { screen.pbUpdate }
      elsif movelist && movelist.none? { |j| j == pokemon.species }
        pbMessage(_INTL("{1} can't learn {2}.", pokemon.name, movename)) { screen.pbUpdate }
      elsif !pokemon.compatible_with_move?(move)
        pbMessage(_INTL("{1} can't learn {2}.", pokemon.name, movename)) { screen.pbUpdate }
      
			# Animation
			elsif pbLearnMove(pokemon, move, false, bymachine, item) { screen.pbUpdate }

				$stats.moves_taught_by_item += 1 if bymachine
        $stats.moves_taught_by_tutor += 1 if !bymachine
        pokemon.add_first_move(move) if oneusemachine
        ret = true
        break
      end
    end
    screen.pbEndScene
  }
  return ret   # Returns whether the move was learned by a Pokemon
end