#-------------------------------------------------------------------------------
# Check Seasons like B2W2 by bo4p5687
#-------------------------------------------------------------------------------
# Don't change
$season_number = 4
# Picture
module ShowSeasonBW2
  def self.check(name = nil)
    return name if name.nil?
    return Bitmap.new("Graphics/Pictures/Seasons/#{name}")
  end

  def self.show
		val = GameData::MapMetadata.get($game_map.map_id).outdoor_map if GameData::MapMetadata.exists?($game_map.map_id)
    if val && !pbMapInterpreterRunning?
      checked = 0
      loop do
        Graphics.update
        case checked
        when 0
          $season_number = pbGetSeason
          @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
          @viewport.z = 99999
          @season = Sprite.new(@viewport)
          @season.bitmap = if pbIsSpring
            								self.check("Spring")
													elsif pbIsSummer
														self.check("Summer")
													elsif pbIsAutumn
														self.check("Autumn")
													elsif pbIsWinter
														self.check("Winter")
													else
														self.check
													end
          @season.opacity = 150
          checked = 1
        when 1
          @season.opacity += 15
          checked = 2 if @season.opacity >= 255
        when 2
          Graphics.wait(30)
          checked = 3
        when 3
          @season.opacity -= 5
          checked = 4 if @season.opacity <= 0
        when 4
          @season.dispose 
          @viewport.dispose
          break
        end
      end
    else
      @checked = nil if $season_number != pbGetSeason
    end
  end
end

EventHandlers.add(:on_new_spriteset_map, :show_seasons,
  proc { |_, _|
    ShowSeasonBW2.show if $season_number != pbGetSeason
  }
)