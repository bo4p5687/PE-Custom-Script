=begin

Use AdventureGuide.list(hash)
	hash stores information of big title (Hash)
	Value in this hash:
		name -> it's title of this guide, big title (String)
		description -> it's description of big title (String)
		sub -> it's array to store all of sub-title, small title (Array)
			Each value in array is Hash, they are these values:
			name -> it's name of sub-title
			description -> it's description of small title

In description, when you want to create new line right away, just use \n.
Look at examples to write.

=end

# This is examples
# You can delete or edit it or add =begin below this line and add =end above line 'Add new list here'

AdventureGuide.list({
	:name => "A",
	:description => "It's A\nB\nC\nD\nE",
	:sub => [
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "When you come across another person, go up to them and press the C Button. That will get them to talk and interact with your character. You may also examine various items and objects in the same way. Talk to people and check things often to obtain information."},
		{:name => "Sub 2", :description => "Hello, this is descript of Sub 2 of A"},
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
	]
})

AdventureGuide.list({
	:name => "A",
	:description => "It's test: When you come across another person, go up to them and press the C Button. That will get them to talk and interact with your character. You may also examine various items and objects in the same way. Talk to people and check things often to obtain information.",
	:sub => [
		{:name => "Sub 5", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unb", :description => "Hello, this is\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 4", :description => "Hello, this is descript of Sub 2 of A"},
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Ueve", :description => "Hello, thi \nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 12", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Uve", :description => "Hello, thi \nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub as", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Ufeve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sd 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Usaieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "S 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Une", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "S1231", :description => "Hello, this is descript of Sub 1 of A"},
	]
})

AdventureGuide.list({
	:name => "J",
	:description => "It's as",
	:sub => [
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 2", :description => "Hello, this is descript of Sub 2 of A"}
	]
})

AdventureGuide.list({
	:name => "G",
	:description => "It's RT",
	:sub => [
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 2", :description => "Hello, this is descript of Sub 2 of A"}
	]
})

AdventureGuide.list({
	:name => "H",
	:description => "It's TY",
	:sub => [
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 2", :description => "Hello, this is descript of Sub 2 of A"}
	]
})

AdventureGuide.list({
	:name => "C",
	:description => "It's Qd",
	:sub => [
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 2", :description => "Hello, this is descript of Sub 2 of A"}
	]
})

AdventureGuide.list({
	:name => "S",
	:description => "It's JAs",
	:sub => [
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 2", :description => "Hello, this is descript of Sub 2 of A"}
	]
})

AdventureGuide.list({
	:name => "F",
	:description => "It's Sqbas",
	:sub => [
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 2", :description => "Hello, this is descript of Sub 2 of A"}
	]
})

AdventureGuide.list({
	:name => "E",
	:description => "It's Jecs",
	:sub => [
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 2", :description => "Hello, this is descript of Sub 2 of A"}
	]
})

AdventureGuide.list({
	:name => "D",
	:description => "It's Posd",
	:sub => [
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 2", :description => "Hello, this is descript of Sub 2 of A"}
	]
})

AdventureGuide.list({
	:name => "C",
	:description => "It's Lsk",
	:sub => [
		{:name => "Sub 1", :description => "Hello, this is descript of Sub 1 of A"},
		{:name => "Unbelieve", :description => "Hello, this is descript of \nUnbelieve of A\nU1\nU2\nU3\nU4\nU5\nU6\nU7\nU8\nU9\nU10\nU11\nU12"},
		{:name => "Sub 2", :description => "Hello, this is descript of Sub 2 of A"}
	]
})

# Add new list here