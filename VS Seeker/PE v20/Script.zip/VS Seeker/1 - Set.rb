# -----------------------------------------------------#
# 
# VS Seeker script: by mej71, encounter modifier by JV
# Signal by Kiedisticelixer
# 
# Update: bo4p5687
# 
# -----------------------------------------------------#
#-------------------------------#
# Don't touch these lines below #
#-------------------------------#
module VSSeeker
	@@maps = []
	def self.set_maps(maps) = @@maps = maps
	def self.get_maps = @@maps

	@@not_using = true
	def self.set_not_using(set) = @@not_using = set
	def self.get_not_using = @@not_using

	@@store_facing = nil
	def self.set_store_facing(set) = @@store_facing = set
	def self.get_store_facing = @@store_facing

	@@cur_map = nil
	def self.set_cur_map(set) = @@cur_map = set
	def self.get_cur_map = @@cur_map

	def self.calculation
		width = Settings::SCREEN_WIDTH
		height = Settings::SCREEN_HEIGHT
		x1 = $game_player.x
		y1 = $game_player.y
		# Limit (from player)
		x2 = width / 64
		y2 = height / 64
		if $game_map.metadata&.snap_edges
			# Horizontal axis
			if x1 < width / 64 + 1 || x1 + width / 64 >= $game_map.width
				x1 = x1 < width / 64 + 1 ? -1 : $game_map.width
				x2 = width / 32 + 1
			end
			# Vertical axis
			if y1 < height / 64 + 1 || y1 + height / 64 >= $game_map.height
				y1 = y1 < height / 64 + 1 ? -1 : $game_map.height
				y2 = height / 32 + 1
			end
		end
		return x1, x2, y1, y2
	end

	def self.range_battle(event)
		base_x, range_x, base_y, range_y = self.calculation
		return (base_x - event.x).abs <= range_x && (base_y - event.y).abs <= range_y
	end

	def self.range_battle_other_map(event, dims, dims2)
		base_x, range_x, base_y, range_y = self.calculation
		width = Settings::SCREEN_WIDTH
		height = Settings::SCREEN_HEIGHT
		x1 = $game_player.x
		y1 = $game_player.y
		x3 = 0
		y3 = 0
		x3 = -1 if base_x == -1 || base_x < width / 64 + 1
		x3 = dims[0] if base_x == $game_map.width || base_x + width / 64 >= dims[0]
		y3 = -1 if base_y == -1 || base_y < height / 64 + 1
		y3 = dims[1] if base_y == $game_map.height || base_y + height / 64 >= dims[1]
		return false if x3 == 0 && y3 == 0
		x2 = range_x - (x3 == -1 ? x1 : dims[0] - x1)
		y2 = range_y - (y3 == -1 ? y1 : dims[1] - y1)
		return (dims2[0] - event.x).abs <= x2 if x3 == -1
		return event.x <= x2 if x3 == $game_map.width
		return (dims2[1] - event.y).abs <= y2 if y3 == -1
		return event.y <= y2 if y3 == $game_map.height
		return false
	end

	# Check: are there script battle in `Script` or `Conditional branch`?
	def self.check_battle(event)
		list = event.list
		return false if list.nil?
		return false unless list.is_a?(Array)
		ret = false
		list.each_with_index { |item, i|
			next unless item
			if item.code == 111 # Condition branch
				next unless list[i].parameters[0] == 12 # Use: Script
				s = list[i].parameters[1].to_s
				if s.include? "TrainerBattle.start"
					ret = true
					break
				end
			elsif [355, 655].include? item.code # Script, Continue script
				s = list[i].parameters[0].to_s
				if s.include? "TrainerBattle.start"
					ret = true
					break
				end
			end
		}
		return ret
	end

	# Check: are there script battle in old page?
	def self.check_old_page(event, old)
		ret = false
		event.pages.each_with_index { |page, index|
			next if index + 1 != old
			ret = self.check_battle(page)
			break
		}
		return ret
	end

	# Method: use vs seeker
	def self.using
		self.animation
		pbSEPlay("VS_Seeker")
		$game_player.turn_down
		single = [] # !
		double = [] # !!
		reject = [] # X
		# Store map id and event
		$PokemonGlobal.vs_seeker_map[$game_map.map_id] = [] if !$PokemonGlobal.vs_seeker_map[$game_map.map_id]
		#---------------------------------------------------#
		# Check current page which has comments 'VS Seeker'
		# First line is VS Seeker
		# Second line is page number to battle
		# 
		# Animation jump and show !! -> Rebattle
		# Not jump and show ! -> Battle
		# Show X -> Not want to battle
		#___________________________________________________#
		$game_map.events.each { |id, event|
			next if !event.name[/trainer\((\d+)\)VS/i] && !event.name[/trainer\((\d+)\)/i]
			next unless self.range_battle(event)
			arr = pbEventCommentInput(event, 1, "VS Seeker")
			if arr.nil?
				# Check event which has battle code
				has = self.check_battle(event.page)
				single << event if has
				next
			end
			number = arr[0].to_i
			has = self.check_old_page(event, number)
			accept = false
			if has
				random = rand(100)
				if random < 50
					double << event
					accept = true
				else
					reject << event
				end
			else
				next
			end
			next unless accept
			# Store old event, check id event for replacing
			$PokemonGlobal.vs_seeker_map[$game_map.map_id] << event if !$PokemonGlobal.vs_seeker_map[$game_map.map_id].include? event
			event.vs_seeker = [true, number]
		}
		#________________________________________________#
		# 
		# Check map is in range and event is near player
		#________________________________________________#
		arr_map = $map_factory.get_map_in_range
		dims = MapFactoryHelper.getMapDims($game_map.map_id)
		if arr_map
			arr_map.each { |map_id|
				dims2 = MapFactoryHelper.getMapDims(map_id)
				events = {}
				$map_factory.maps.each { |map|
					next if map.map_id != map_id
					events = map.events
				}
				$PokemonGlobal.vs_seeker_map[map_id] = [] if !$PokemonGlobal.vs_seeker_map[map_id]
				events.each { |id, event|
					next if !event.name[/trainer\((\d+)\)VS/i] && !event.name[/trainer\((\d+)\)/i]
					next unless self.range_battle_other_map(event, dims, dims2)
					arr = pbEventCommentInput(event, 1, "VS Seeker")
					if arr.nil?
						# Check event which has battle code
						has = self.check_battle(event.page)
						single << event if has
						next
					end
					number = arr[0].to_i
					has = self.check_old_page(event, number)
					accept = false
					if has
						random = rand(100)
						if random < 50
							double << event
							accept = true
						else
							reject << event
						end
					else
						next
					end
					next unless accept
					# Store old event, check id event for replacing
					$PokemonGlobal.vs_seeker_map[map_id] << event if !$PokemonGlobal.vs_seeker_map[map_id].include? event
					event.vs_seeker = [true, number]
				}
			}
		end
		# Accept (!)
		if single.size > 0
			single.each { |event|
				event.turn_down
				pbExclaim(event)
			}
			self.announcement(single) if ANNOUNCEMENT
		end
		# Accept (!!)
		if double.size > 0
			double.each { |event|
				event.need_refresh = true
				event.turn_down
				pbExclaim(event, ACCEPT_ID)
			}
			self.announcement(nil, double) if ANNOUNCEMENT
		end
		# Reject (X)
		if reject.size > 0
			reject.each { |event| pbExclaim(event, REJECT_ID) }
			self.announcement(nil, nil, reject) if ANNOUNCEMENT
		end
		# Announcement
		if ANNOUNCEMENT
			self.announcement if single.size == 0 && double.size == 0 && reject.size == 0
		end
		# Reset steps
		$PokemonGlobal.vs_seeker_steps = 0
		return true
	end

	def self.using_from_bag
		if VSSeeker::NOT_MAP.include?($game_map.map_id)
			pbMessage(_INTL("The {1} can't be used here..", GameData::Item.get(item).name))
			return false
		elsif !VSSeeker::IN_CAVE && $PokemonEncounters.has_cave_encounters?
			pbMessage(_INTL("The {1} can't be used in a cave..", GameData::Item.get(item).name))
			return false
		elsif !VSSeeker::INDOORS && !$game_map.metadata&.outdoor_map
			pbMessage(_INTL("The {1} can't be used indoors..", GameData::Item.get(item).name))
			return false
		end
		if $PokemonGlobal.vs_seeker_steps < STEPS
			pbMessage(_INTL("The battery isn't charged enough"))
			pbMessage(_INTL("No. of steps required to fully charge the battery are #{STEPS - $PokemonGlobal.vs_seeker_steps}"))
			return false
		else
			return true
		end
	end

	def self.announcement(single = nil, double = nil, reject = nil)
		b = "It looks like "
		e = []
		if !single.nil?
			s = single.size > 1 ? "there are a trainer" : "there is some trainers"
			e << s + " you haven't battled yet"
		end
		if !double.nil?
			d = double.size > 1 ? "some trainers are" : "a trainer is"
			e << d + " ready for a rematch"
		end
		if !reject.nil?
			r = reject.size > 1 ? "none of these trainers are" : "this trainer isn't"
			e << r + " ready for a rematch"
		end
		f = ""
		if single.nil? && double.nil? && reject.nil?
			f = "There aren't any trainers around here to rematch."
		else
			f += b
			e.each { |w| f += w }
			f += "."
		end
		pbMessage(_INTL(f))
	end
	
	def self.set_character
		id = $player&.character_ID || 1
		graphic = ANIMATION[id - 1] if ANIMATION.is_a?(Array) && ANIMATION.size > 0
		exist = pbResolveBitmap("Graphics/Characters/#{graphic}") if graphic
		character = nil
		character = pbGetPlayerCharset(graphic) if exist
		return character
	end

	def self.animation
		$game_player.turn_down
		name = self.set_character
		$game_player.character_name = name if name
		return unless name
		pbWait(4)
		$game_player.turn_left
		pbWait(4)
		$game_player.turn_right
		pbWait(4)
		$game_player.turn_up
		pbWait(8)
	end
end