# ################################################################################
# #VS Seeker script: by mej71, encounter modifier by JV
# #This script is fairly easy to use, but I suggest watching this video for a 
# #clear explanation
# #Credit required
# ################################################################################


# NOVSSEEKERMAPS = [] #Include any specific maps where the VS Seeker cannot be used
# USEVSSEEKERINCAVES = false #If the VS Seeker can be used in caves
# USEVSSEEKERINDOORS = true #If the VS Seeker can be used indoors
# VSSEEKERSTEPS = 100 #The number of steps required to charge the VS Seeker
# #This is a switch number that will trigger the encounter modifier
# VSSEEKERMODIFIERALL = 99 #Will modify level AND update movesets after releveling
# VSSEEKERMODIFIERONLYLEVEL = 100 #Will only modify level, keep same moveset

# #These numbers correspond to the animation ids
# VS_SEEKER_ACCEPT_ID = 8
# VS_SEEKER_REJECT_ID = 9


# #Determine an event's current page
# class Game_Event < Game_Character
  
#   def currentPageNum
#     if !@page || !@event
#       return 0
#     else
#       count = 0
#       for page in @event.pages
#         if page==@page
#           return count
#         end
#         count+=1
#       end
#     end
#   end
  
#   #overwrite this method so that VS Trainer events will walk towards you
#   def pbCheckEventTriggerAfterTurning
#     if $game_system.map_interpreter.running? || @starting
#       return
#     end
#     if @event.name[/^Trainer\((\d+)\)/]
#       distance=$~[1].to_i
#       if @trigger == 2 and pbEventCanReachPlayer?(self,$game_player,distance)
#          if not jumping? and not over_trigger?
#            start
#          end
#       end
#     end
#   end
  
# end

# class Game_Player < Game_Character
  
#   #overwrite this method so that VS Trainer events will walk towards you
#   def pbTriggeredTrainerEvents(triggers,checkIfRunning=true)
#     result = []
#     # If event is running
#     if checkIfRunning && $game_system.map_interpreter.running?
#       return result
#     end
#     # All event loops
#     for event in $game_map.events.values
#       next if !event.name[/^Trainer\((\d+)\)/]
#       distance=$~[1].to_i
#       # If event coordinates and triggers are consistent
#       if pbEventCanReachPlayer?(event,self,distance) and triggers.include?(event.trigger)
#           # If starting determinant is front event (other than jumping)
#         if not event.jumping? and not event.over_trigger?
#           result.push(event)
#         end
#       end
#     end
#     return result
#   end
  
#   #overwrite this method so that VS Trainer events will walk towards you
#   def check_event_trigger_touch(x, y)
#     result = false
#     # If event is running
#     if $game_system.map_interpreter.running?
#       return result
#     end
#     # All event loops
#     for event in $game_map.events.values
#       if event.name[/^Trainer\((\d+)\)/]
#         distance=$~[1].to_i
#         next if !pbEventCanReachPlayer?(event,self,distance)
#       end
#       if event.name[/^Counter\((\d+)\)$/]
#         distance=$~[1].to_i
#         next if !pbEventFacesPlayer?(event,self,distance)
#       end
#       # If event coordinates and triggers are consistent
#       if event.x == x and event.y == y and [1,2].include?(event.trigger)
#         # If starting determinant is front event (other than jumping)
#         if not event.jumping? and not event.over_trigger?
#           event.start
#           result = true
#         end
#       end
#     end
#     return result
#   end
  
# end

# #Add VS Seeker steps to the player
# class PokeBattle_Trainer
  
#   def vsSteps
#     @vsSteps = 0 if !@vsSteps
#     return @vsSteps
#   end
  
#   def vsSteps=(value)
#     @vsSteps = 0 if !@vsSteps
#     @vsSteps = value
#   end
  
#   alias seeker_initialize initialize
#   def initialize(name,trainertype)
#     seeker_initialize(name,trainertype)
#     @vsSteps = 0
#   end
  
# end


# #Increase vs steps on each step
# Events.onStepTaken+=proc{
#   if $PokemonBag.pbQuantity(:VSSEEKER)>0
#     $Trainer.vsSteps+=1
#   end
# }
  
# #Turn of vsseeker self switch when entering a map
# Events.onMapChange+=proc {|sender,e|
#   oldmapid=e[0]
#   newmapid = $game_map.map_id
#   return if oldmapid==newmapid
#   return if oldmapid==0
#   for event in $game_map.events.values
#      if event.name.match(/^Trainer[(][0-9][)]VS/)
#         # Make a self switch key
#         key = [$game_map.map_id, event.id, "vsseeker"]
#         # Change self switches
#         $game_self_switches[key] = false
#      end
#   end
# }


# #VS Seeker item handlers

# ItemHandlers::UseFromBag.add(:VSSEEKER,proc{|item|
#    #vsSteps must be greater than 100
#    if !($DEBUG && Input.trigger?(Input::CTRL))
#      if $Trainer.vsSteps<VSSEEKERSTEPS
#        Kernel.pbMessage(_INTL("The battery isn't charged enough"))
#        Kernel.pbMessage(_INTL("No. of steps required to fully charge the battery: {1}",
#                                (VSSEEKERSTEPS-$Trainer.vsSteps)))
#        return 1
#      end
#    end
#    #Can't use in specific maps, check if usable in cave, usable indoors
#    if NOVSSEEKERMAPS.include?($game_map.map_id)
#      Kernel.pbMessage(_INTL("The {1} can't be used here..",PBItems.getName(item)))
#      return 1
#    elsif !USEVSSEEKERINCAVES && $PokemonEncounters && $PokemonEncounters.isCave?
#      Kernel.pbMessage(_INTL("The {1} can't be used in a cave..",PBItems.getName(item)))
#      return 1
#    elsif !USEVSSEEKERINDOORS && !pbGetMetadata($game_map.map_id,MetadataOutdoor)
#      Kernel.pbMessage(_INTL("The {1} can't be used indoors..",PBItems.getName(item)))
#      return 1
#    end
#    return 2
# })

# ItemHandlers::UseInField.add(:VSSEEKER,proc{|item|
#    #vsSteps must be greater than 100
#    if !($DEBUG && Input.trigger?(Input::CTRL))
#      if $Trainer.vsSteps<VSSEEKERSTEPS
#        Kernel.pbMessage(_INTL("The battery isn't charged enough"))
#        Kernel.pbMessage(_INTL("No. of steps required to fully charge the battery: {1}",
#                                (VSSEEKERSTEPS-$Trainer.vsSteps)))
#        return 1
#      end
#    end
#    #Can't use in specific maps, check if usable in cave, usable indoors
#    if NOVSSEEKERMAPS.include?($game_map.map_id)
#      Kernel.pbMessage(_INTL("The {1} can't be used here..",PBItems.getName(item)))
#      return 1
#    elsif !USEVSSEEKERINCAVES && $PokemonEncounters && $PokemonEncounters.isCave?
#      Kernel.pbMessage(_INTL("The {1} can't be used in a cave..",PBItems.getName(item)))
#      return 1
#    elsif false#!USEVSSEEKERINDOORS && !pbGetMetadata($game_map.map_id,MetadataOutdoor)
#      Kernel.pbMessage(_INTL("The {1} can't be used indoors..",PBItems.getName(item)))
#      return 1
#    end
#    pbSEPlay("VS_Seeker")
#    #make some calculations to determine the range (accounting for maps with snap edges)
#    if pbGetMetadata($game_map.map_id,MetadataSnapEdges) && 
#        ($game_player.x<((Graphics.width)/64)+1 ||
#        $game_player.x+((Graphics.width)/64)>=$game_map.width)
#      base_x = ($game_player.x<((Graphics.width)/64)+1)? -1 : $game_map.width
#      range_x = (Graphics.width)/32+1
#    else
#      base_x = $game_player.x
#      range_x = (Graphics.width)/64
#    end
#    if pbGetMetadata($game_map.map_id,MetadataSnapEdges) && 
#        ($game_player.y<((Graphics.height)/64)+1 || 
#        $game_player.y+((Graphics.height)/64)>=$game_map.height)
#      base_y = ($game_player.y<((Graphics.height)/64)+1)? -1 : $game_map.height+1
#      range_y = (Graphics.height)/32+1
#    else
#      base_y = $game_player.y
#      range_y = ((Graphics.height)/64)
#    end
#    single_exclaim = []
#    rematch_accepted = []
#    rematch_declined = []
#    numTrainers = 0
#    #check through each event
#    for event in $game_map.events.values
#      if event.name.match(/^Trainer[(][0-9][)]VS/)
#        if ((base_x-event.x).abs<range_x) && ((base_y-event.y).abs<range_y)
#          numTrainers+=1
#          #if not page 0, assume trainer hasn't been battled yet
#          if event.currentPageNum==0
#            #show single exclamation
#            single_exclaim.push(event)
#            next
#          end
#          #50/50 chance for now
#          if rand(100)<50
#            rematch_accepted.push(event)
#            # Make a self switch key
#            key = [$game_map.map_id, event.id, "vsseeker"]
#            # Change self switches
#            next if $game_self_switches[key]
#            $game_self_switches[key] = true
#            $game_map.refresh
#            #show other animation
#          else
#            rematch_declined.push(event)
#          end
#        end
#      end
#    end
#    pbExclaim(single_exclaim) if single_exclaim.length>0
#    pbExclaim(rematch_accepted,VS_SEEKER_ACCEPT_ID) if rematch_accepted.length>0
#    pbExclaim(rematch_declined,VS_SEEKER_REJECT_ID) if rematch_declined.length>0
#    #reset vsSteps
#    $Trainer.vsSteps=0 if (single_exclaim.length + rematch_accepted.length + rematch_declined.length)>0
#    if rematch_accepted.length>1
#      Kernel.pbMessage(_INTL("It looks like some trainers are ready for a rematch."))
#    elsif rematch_accepted.length>0
#      Kernel.pbMessage(_INTL("It looks a trainer is ready for a rematch."))
#    elsif single_exclaim.length>1
#      Kernel.pbMessage(_INTL("It looks like there are some trainers you haven't battled yet."))
#    elsif single_exclaim.length>0
#      Kernel.pbMessage(_INTL("It looks like there is a trainers you haven't battled yet."))
#    elsif numTrainers>1
#      Kernel.pbMessage(_INTL("It looks like none of these trainers are ready to rematch."))
#    elsif numTrainers>0
#      Kernel.pbMessage(_INTL("It looks like this trainer isn't ready for a rematch."))
#    else
#      Kernel.pbMessage(_INTL("There aren't any trainers around here to rematch."))
#    end   
#    return 1
# })

# #Encounter modifier for rematches

# def getNextEvolution(pokemon)
#     for form in pbGetEvolvedFormData(pokemon.species)
#       pokemon.species=form[2]
#       pokemon.name=PBSpecies.getName(form[2])
#     end
# end

# Events.onTrainerPartyLoad+=proc {|sender,e|
#    if $game_switches[VSSEEKERMODIFIERALL]
#      if e[0] # Trainer data should exist to be loaded, but may not exist somehow
#        trainer=e[0][0] # A PokeBattle_Trainer object of the loaded trainer
#        items=e[0][1]   # An array of the trainer's items they can use
#        party=e[0][2]   # An array of the trainer's Pokémon
#        for i in 0...party.length
#          adjusted = (pbBalancedLevel($Trainer.party)-rand(5)+rand(3))
#          adjusted = MAXIMUMLEVEL if adjusted > MAXIMUMLEVEL
#          adjusted = 1   if adjusted < 1
#          party[i].level=adjusted
#          if party[i].level>=15+rand(20)
#            getNextEvolution(party[i])
#            if party[i].level>=35+rand(20)
#              getNextEvolution(party[i])
#            end
#          end
#          tempPoke=PokeBattle_Pokemon.new(party[i].species,party[i].level)
#          party[i].moves[0]=tempPoke.moves[0]
#          party[i].moves[1]=tempPoke.moves[1]
#          party[i].moves[2]=tempPoke.moves[2]
#          party[i].moves[3]=tempPoke.moves[3]
#          party[i].calcStats
#        end
#      end
#    elsif $game_switches[VSSEEKERMODIFIERONLYLEVEL]
#      if e[0] # Trainer data should exist to be loaded, but may not exist somehow
#        trainer=e[0][0] # A PokeBattle_Trainer object of the loaded trainer
#        items=e[0][1]   # An array of the trainer's items they can use
#        party=e[0][2]   # An array of the trainer's Pokémon
#        for i in 0...party.length
#          adjusted = (pbBalancedLevel($Trainer.party)-rand(5)+rand(3))
#          adjusted = MAXIMUMLEVEL if adjusted > MAXIMUMLEVEL
#          adjusted = 1   if adjusted < 1
#          party[i].level=adjusted
#          if party[i].level>=15+rand(20)
#            getNextEvolution(party[i])
#            if party[i].level>=35+rand(20)
#              getNextEvolution(party[i])
#            end
#          end
#          party[i].calcStats
#        end
#      end     
#    end
# }