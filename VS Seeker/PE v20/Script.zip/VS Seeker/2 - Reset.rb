# -----------------------------------------------------#
# 
# VS Seeker script: by mej71, encounter modifier by JV
# Signal by Kiedisticelixer
# 
# Update: bo4p5687
# 
# -----------------------------------------------------#
#-------------------------------#
# Don't touch these lines below #
#-------------------------------#
module VSSeeker
	def self.reset
		arr = @@maps
		return unless arr.is_a? Array
		$PokemonGlobal.vs_seeker_map.each { |map_id, event|
			has = arr.include? map_id
			next if has
			# Reset event when it isn't in range
			self.reset_map_event(map_id)
			$PokemonGlobal.vs_seeker_map.delete(map_id)
		}
	end

	# Use in self.reset
	def self.reset_map_event(map_id)
		events = {}
		$map_factory.maps.each { |map|
			next if map.map_id != map_id
			events = map.events
		}
		events.each_value { |event| self.reset_element(event) }
	end

	def self.reset_element(event)
		event.vs_seeker = []
		event.page = event.old_page
		event.old_page = nil
		event.need_refresh
	end

	def self.delete_element_vs_map(id, map_id = nil)
		map_id = map_id.nil? ? $game_map.map_id : map_id
		map = $PokemonGlobal.vs_seeker_map[map_id]
		index = map.find_index { |i| i.id == id }
		return if !index
		$PokemonGlobal.vs_seeker_map[map_id].delete_at(index)
	end

	# After battling, set `VSSeeker.reset_event` for resetting
	def self.reset_event
		self.set_store_facing(nil)
		# map_id = $game_map.map_id
		event = pbMapInterpreter.get_self
		map_id = @@cur_map.nil? ? nil : @@cur_map
		event_id = event.id
		self.reset_element(event)
		self.delete_element_vs_map(event_id, map_id)
		event.vs_event_force = true
		event.refresh
		if !@@cur_map.nil?
			$map_factory.maps.each { |map|
				next if map.map_id != map_id
				map.events.each { |id, event|
					next if id != event_id
					self.reset_element(event)
					event.vs_event_force = true
					event.refresh
					map.refresh
					break
				}
				break
			}
		end
		@@cur_map = nil
	end
end