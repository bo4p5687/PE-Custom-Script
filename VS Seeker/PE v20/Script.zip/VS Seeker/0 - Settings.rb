# -----------------------------------------------------#
# 
# VS Seeker script: by mej71, encounter modifier by JV
# Signal by Kiedisticelixer
# 
# Update: bo4p5687
# 
# -----------------------------------------------------#
module VSSeeker
	# Put map id in [].
	# When this map id is in [], player can't use VS SEEKER in this map
	NOT_MAP = []

	# When `IN_CAVE = true`, player can use VS SEEKER in maps which is caves
	IN_CAVE = true
	# When `INDOORS = true`, player can use VS SEEKER in maps which is indoor
	INDOORS = true

	# After walking `STEPS` steps, player can use VS SEEKER
	STEPS = 100

	# Animation id, set in `Database` -> `Animation`
	ACCEPT_ID = 8
	REJECT_ID = 9

	# When `EVOLVE = true`, player re-match
	# And he can have new specie if old specie reaches level to evolve
	EVOLVE = true

	# When `ANNOUNCEMENT = true`, announcement will appear after using
	ANNOUNCEMENT = true

	# Set animation when using VS SEEKER
	# It doesn't show animation when don't set
	# Put name of picture in `Graphics/Characters` in "" below in order
	# Example:
	#   There is "boy_vsseeker" in `Graphics/Characters`
	#   And change animation when using VS Seeker with first character. It means "Red" when starting.
	#   Put it in ANIMATION like this
	# 
	# ANIMATION = [
	# 	"boy_vsseeker", # Player A
	ANIMATION = [
		"", # Player A
		"", # Player B
		"", # Player C
		"", # Player D
		"", # etc
		"",
		"",
		""
	]

	# When `DIFFICULT = true`,
	#  + And when `INCREASE = true`, player has more pokemon (+1, +2, +3, +5). It depends AI of trainer.
	#  + Level of pokemon will be higher than level of pokemon, except reaching maximum level. It depends AI of trainer. (+10, +15, +20, +30)
	DIFFICULT = false
	# When `INCREASE = true`, trainer has more pokemon (+1)
	# Condition: base trainer has less than 6 (MAX_PARTY_SIZE = 6).
	# When `MAX_PARTY_SIZE` is higher than 6, party of opposite can higher.
	INCREASE = true
	# When party size increases, new pokemon is rotom who has multiple form and you want to set random his form.
	# Set `CHANGE_FORM = true`
	CHANGE_FORM = true
	# Add pokemon in `BAN`, when you doesn't want to add these pokemon in opposite trainer
	# Example: when you want to ban Arceus, set like this `BAN = [:ARCEUS]`
	BAN = []

	# When you want to store party of opposite trainer in next time, set `STORE = true`.
	STORE = true
end