
# -----------------------------------------------------#
# 
# VS Seeker script: by mej71, encounter modifier by JV
# Signal by Kiedisticelixer
# 
# Update: bo4p5687
# 
# -----------------------------------------------------#
#-------------------------------#
# Don't touch these lines below #
#-------------------------------#
# Add item
ItemHandlers::UseFromBag.add(:VSSEEKER, proc { |item|
	next VSSeeker.using_from_bag ? 2 : 0
})

ItemHandlers::UseInField.add(:VSSEEKER, proc { |item|
	next VSSeeker.using_from_bag ? VSSeeker.using : false
})

# Set values
class PokemonGlobalMetadata
  attr_accessor :vs_seeker_steps
	attr_accessor :vs_seeker_map # Store map + id event
	attr_accessor :vs_seeker_store_party

  alias vs_seeker_init initialize
  def initialize
    vs_seeker_init
    @vs_seeker_steps = 0
		@vs_seeker_map = {}
		@vs_seeker_store_party = {}
  end
end

# Reset steps
EventHandlers.add(:on_player_step_taken, :vs_seeker,
  proc {
		next unless $bag.has?(:VSSEEKER)
    $PokemonGlobal.vs_seeker_steps += 1
		$PokemonGlobal.vs_seeker_steps  = VSSeeker::STEPS if $PokemonGlobal.vs_seeker_steps > VSSeeker::STEPS
  }
)

#---------------------------------#
# Add trigger in class Game_Event #
#---------------------------------#
class Game_Event
	attr_accessor :vs_seeker
	attr_accessor :old_page
	attr_accessor :page
	attr_accessor :vs_event_force

	alias vs_seeker_init initialize
	def initialize(map_id, event, map = nil)
		@vs_seeker = [] # [true/false, old page]
		@old_page = nil
		@vs_event_force = false
		vs_seeker_init(map_id, event, map)
	end

	def pages = @event.pages

	def refresh
		new_page = nil
    unless @erased
      @event.pages.reverse.each do |page|
        c = page.condition
        next if c.switch1_valid && !switchIsOn?(c.switch1_id)
        next if c.switch2_valid && !switchIsOn?(c.switch2_id)
        next if c.variable_valid && $game_variables[c.variable_id] < c.variable_value
        if c.self_switch_valid
          key = [@map_id, @event.id, c.self_switch_ch]
          next if $game_self_switches[key] != true
        end
        new_page = page
        break
      end

			# Transfer to VS Seeker's page
			if @vs_seeker.size == 2
				if @vs_seeker[0] && @vs_seeker[1].is_a?(Numeric) && @vs_seeker[1] > 0
					@event.pages.each_with_index { |page, index|
						next if index + 1 != @vs_seeker[1]
						new_page = page
						break
					}
					@old_page = @page
				end
			end

    end

		# Force to refresh event
    return if new_page == @page && !@vs_event_force
		@vs_event_force = false

    @page = new_page
    clear_starting
    if @page.nil?
      @tile_id        = 0
      @character_name = ""
      @character_hue  = 0
      @move_type      = 0
      @through        = true
      @trigger        = nil
      @list           = nil
      @interpreter    = nil
      return
    end
    @tile_id              = @page.graphic.tile_id
    @character_name       = @page.graphic.character_name
    @character_hue        = @page.graphic.character_hue
    if @original_direction != @page.graphic.direction
      @direction          = @page.graphic.direction
      @original_direction = @direction
      @prelock_direction  = 0
    end
    if @original_pattern != @page.graphic.pattern
      @pattern            = @page.graphic.pattern
      @original_pattern   = @pattern
    end
    @opacity              = @page.graphic.opacity
    @blend_type           = @page.graphic.blend_type
    @move_type            = @page.move_type
    self.move_speed       = @page.move_speed
    self.move_frequency   = @page.move_frequency
    @move_route           = (@route_erased) ? RPG::MoveRoute.new : @page.move_route

		# Set `Autonomous Movement` for vs seeker
		if @vs_seeker[0]
			@move_type = 3
			self.move_speed = 3
    	self.move_frequency = 4
			@move_route = RPG::MoveRoute.new
			@move_route.repeat = true
			@move_route.skippable = false
			@move_route.list.clear
			@move_route.list << RPG::MoveCommand.new(PBMoveRoute::Jump, [0, 0])
			@move_route.list << RPG::MoveCommand.new(0)
		end

    @move_route_index     = 0
    @move_route_forcing   = false
    @walk_anime           = @page.walk_anime
    @step_anime           = @page.step_anime
    @direction_fix        = @page.direction_fix
    @through              = @page.through
    @always_on_top        = @page.always_on_top
    calculate_bush_depth
    @trigger              = @page.trigger
    @list                 = @page.list
    @interpreter          = nil
    if @trigger == 4   # Parallel Process
      @interpreter        = Interpreter.new
    end
    check_event_trigger_auto
	end
end

#-----------------------------------------------#
# Check maps in snap edge to reset/update event #
#-----------------------------------------------#
class PokemonMapFactory
	def setMapsInRange
		@fixup = true
    id = $game_map.map_id

		# Store maps in range for resetting events
		map_in_range = []

    MapFactoryHelper.eachConnectionForMap(id) { |conn|
      if conn[0] == id
        mapA = getMap(conn[0])

				# VS seeker: Array stores map id
				map_in_range << mapA.map_id

        newdispx = ((conn[4] - conn[1]) * Game_Map::REAL_RES_X) + mapA.display_x
        newdispy = ((conn[5] - conn[2]) * Game_Map::REAL_RES_Y) + mapA.display_y
        if hasMap?(conn[3]) || MapFactoryHelper.mapInRangeById?(conn[3], newdispx, newdispy)
          mapB = getMap(conn[3])

					# VS seeker: Array stores map id
					map_in_range << mapB.map_id

          mapB.display_x = newdispx if mapB.display_x != newdispx
          mapB.display_y = newdispy if mapB.display_y != newdispy
        end
      else
        mapA = getMap(conn[3])

				# VS seeker: Array stores map id
				map_in_range << mapA.map_id

        newdispx = ((conn[1] - conn[4]) * Game_Map::REAL_RES_X) + mapA.display_x
        newdispy = ((conn[2] - conn[5]) * Game_Map::REAL_RES_Y) + mapA.display_y
        if hasMap?(conn[0]) || MapFactoryHelper.mapInRangeById?(conn[0], newdispx, newdispy)
          mapB = getMap(conn[0])

					# VS seeker: Array stores map id
					map_in_range << mapB.map_id

          mapB.display_x = newdispx if mapB.display_x != newdispx
          mapB.display_y = newdispy if mapB.display_y != newdispy
        end
      end
    }

		# VS seeker: store map which is in edge
		map_in_range = map_in_range.uniq
		VSSeeker.set_maps(map_in_range)

    @fixup = false
	end

	def get_map_in_range
		return nil if VSSeeker.get_maps.size == 0
		id = $game_map.map_id
		width = Settings::SCREEN_WIDTH
		height = Settings::SCREEN_HEIGHT
		x1 = $game_player.x
		y1 = $game_player.y
		x2 = x1
		y2 = y1
		x2 = -1 if x1 < width / 64 + 1
		x2 = $game_map.width if x1 + width / 64 >= $game_map.width
		y2 = -1 if y1 < height / 64 + 1
		y2 = $game_map.height if y1 + height /64 >= $game_map.height
		# Store maps id
		arr = []
		# conn is array: Map ID 1, ..., ..., Map ID 2, ..., ...
		# Look at `def self.getMapConnections` in `module MapFactoryHelper`, `getMapEdge` , `guide map_connection on wiki`
		#   -> Know meaning of ...
		# 	First ... -> x; Second ... -> y
		# N = 0, S = height of map, W = 0, E = width of map
    MapFactoryHelper.eachConnectionForMap(id) { |conn|
      mapidB = nil
      newx = 0
      newy = 0
      if conn[0] == id
        mapidB = conn[3]
        mapB = MapFactoryHelper.getMapDims(conn[3])
        newx = conn[4] - conn[1] + x2
        newy = conn[5] - conn[2] + y2
      else
        mapidB = conn[0]
        mapB = MapFactoryHelper.getMapDims(conn[0])
        newx = conn[1] - conn[4] + x2
        newy = conn[2] - conn[5] + y2
      end
			arr << getMapNoAdd(mapidB).map_id if newx >= 0 && newx < mapB[0] && newy >= 0 && newy < mapB[1]
    }
		return arr.size > 0 ? arr : nil
  end
end

#---------------------------------------------#
# Check event triggers when player is on edge #
#---------------------------------------------#
EventHandlers.add(:on_player_interact, :vs_seeker,
  proc {
    facing_tile = $map_factory.getFacingTile
		events = {}
		$map_factory.maps.each { |map|
			next if map.map_id != facing_tile[0]
			events = map.events
		}
		VSSeeker.set_not_using(true)
		has = nil
		events.each { |id, event|
			next if event.vs_seeker.size == 0 # Check event vs seeker
			next unless event.x == facing_tile[1] && event.y == facing_tile[2]
			has = [id, event]
			VSSeeker.set_not_using(false)
			break
		}
		next unless has
		# Method: store
		$PokemonGlobal.vs_seeker_store_party[facing_tile[0]] = {} if !$PokemonGlobal.vs_seeker_store_party[facing_tile[0]]
		$PokemonGlobal.vs_seeker_store_party[facing_tile[0]][has[0]] = { page: [], trainer: []} if !$PokemonGlobal.vs_seeker_store_party[facing_tile[0]][has[0]]
		arr = $PokemonGlobal.vs_seeker_store_party[facing_tile[0]][has[0]][:page]
		stored = [nil, facing_tile[0], has[0]]
		if arr.size > 0
			arr.each_with_index { |event, index|
				next if event.page != has[1].page
				stored[0] = index
			}
			if stored[0]
				VSSeeker.set_store_facing(stored)
			else
				VSSeeker.set_store_facing(stored)
				$PokemonGlobal.vs_seeker_store_party[facing_tile[0]][has[0]][:page] << has[1]
			end
		else
			VSSeeker.set_store_facing(stored)
			$PokemonGlobal.vs_seeker_store_party[facing_tile[0]][has[0]][:page] << has[1]
		end
		# Event is on edge or other map
		next unless $game_player.x == 0 || $game_player.x == $game_map.width || $game_player.y == 0 || $game_player.y == $game_map.height

		VSSeeker.set_cur_map(facing_tile[0])

		pbMapInterpreter.setup(has[1].list, has[0], facing_tile[0])
  }
)

#----------------------------#
# Set level of foe's pokemon #
#----------------------------#
class TrainerBattle
	class << self
		alias vs_seeker_generate_foes generate_foes
	end

	def self.generate_foes(*args)
		ret = vs_seeker_generate_foes(*args)
		
		# Return if event isn't VS Seeker event
		not_use = VSSeeker.get_not_using
		return ret if not_use
		# Set event
		stored = VSSeeker.get_store_facing
		if VSSeeker::STORE && stored
			if stored[0]
				new_pokemon = $PokemonGlobal.vs_seeker_store_party[stored[1]][stored[2]][:trainer][stored[0]]
			else
				new_pokemon = self.vs_seeker_battle(ret[0], ret[2])
				$PokemonGlobal.vs_seeker_store_party[stored[1]][stored[2]][:trainer] << new_pokemon
			end
		else
			new_pokemon = self.vs_seeker_battle(ret[0], ret[2])
		end

		ret[2] = new_pokemon
		return ret
	end

	def self.vs_seeker_battle(skill, pokemon)
		skill = skill.first.skill_level || 0
		arr = pokemon.each { |pkmn|
										level = self.vs_seeker_level(skill)
										pkmn.level = level
										if VSSeeker::EVOLVE
											new_species = pkmn.check_evolution_on_level_up
											pkmn.species = new_species if !new_species.nil?
										end
										pkmn.calc_stats
										pkmn.reset_moves
									}
		max_party = Settings::MAX_PARTY_SIZE
		if VSSeeker::INCREASE && pokemon.size < max_party
			if VSSeeker::DIFFICULT
				rest = if skill == 0 || skill.between?(PBTrainerAI.minimumSkill, PBTrainerAI.mediumSkill)
								1
							elsif skill.between?(PBTrainerAI.mediumSkill, PBTrainerAI.highSkill)
								2
							elsif skill.between?(PBTrainerAI.highSkill, PBTrainerAI.bestSkill)
								3
							else
								5
							end
				rest = max_party - pokemon.size if rest + pokemon.size > max_party
				arr = arr + self.vs_seeker_increase_party(skill, rest)
			else
				arr = arr + self.vs_seeker_increase_party(skill)
			end
		end
		return arr
	end

	def self.vs_seeker_level(skill)
		max_level = Settings::MAXIMUM_LEVEL
		level = pbBalancedLevel($player.party)
		if VSSeeker::DIFFICULT
			level += if skill == 0 || skill.between?(PBTrainerAI.minimumSkill, PBTrainerAI.mediumSkill)
								10
							elsif skill.between?(PBTrainerAI.mediumSkill, PBTrainerAI.highSkill)
								15
							elsif skill.between?(PBTrainerAI.highSkill, PBTrainerAI.bestSkill)
								20
							else
								30
							end
		else
			level += - rand(5) + rand(3)
		end
		level = max_level if level > max_level
		level = 1 if level < 1
		return level
	end

	def self.vs_seeker_increase_party(skill, rest = 1)
		all_pkmn = GameData::Species.keys
		arr = []
		rest.times { |i|
			level = self.vs_seeker_level(skill)
			specie = all_pkmn.sample
			if VSSeeker::BAN.size != 0
				loop do
					break if !VSSeeker::BAN.include? pkmn
					specie = all_pkmn.sample
				end
			end
			pkmn = Pokemon.new(specie, level)
			if VSSeeker::CHANGE_FORM
				form = GameData::Species.get_all_forms(specie).sample
				pkmn.form = form.nil? ? 0 : form
			end
			pkmn.calc_stats
			pkmn.reset_moves
			arr << pkmn
		}
		return arr
	end
end

module GameData
  class Species
		def self.get_all_forms(species)
			ret = []
			DATA.each_value { |s| ret << s.form if s.species == species }
			return ret
		end
	end
end