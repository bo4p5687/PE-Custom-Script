module NamePoffin
  
  module_function
  
  Name = ["Spicy","Dry","Sweet","Bitter","Sour"]
  
  def single
    n = []
    (0...Name.size).each {|i| n << Name[i]+" Poffin" }
    return n
  end
  
  def double
    n  = []
    (0...Name.length).each {|i| n[i]=[]; 4.times { n[i] << Name[i]+" " } }
    (0...n.length).each { |i|
      n2 = []
      (0...5).each { |j| n2 << Name[j] if j!=i }
      (0...n[i].length).each { |j| n[i][j] += n2[j] + " Poffin" }
    }
    return n
  end

end