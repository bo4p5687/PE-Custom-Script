module FeaturesPoffin
  
  module_function
#-------------------------------------------------------------------------------
# Mode: Play
#-------------------------------------------------------------------------------
  def play
    # Check Berry
    has = false
		item = []
		GameData::Item.each { |i| item << i.id }
		item.each { |i| has = true if $PokemonBag.pbQuantity(i) > 0 && GameData::Item.get(i).is_berry? }
    if !has
      pbMessage(_INTL("You don't have any berry!"))
      return
    end
    again = true
    # Play
    loop do
      if again
        p = Poffin.new
        p.startScene
        p.endScene
        again = false
      else
        if pbConfirmMessage(_INTL("Do you want to continue?"))
          again=true
        else
          # Reset rules
          $rulesPoffin.clearRules
          return
        end
      end
    end
  end
#-------------------------------------------------------------------------------
# Mode: Eat poffin
#-------------------------------------------------------------------------------
  def eat
    pbFadeOutIn { 
      p = PoffinCase.new
      loop do
        case p.page
        when 1; p.pageOne
        when 2; p.pageTwo
        else; break
        end
      end
      p.endScene
    }
  end
  
end
