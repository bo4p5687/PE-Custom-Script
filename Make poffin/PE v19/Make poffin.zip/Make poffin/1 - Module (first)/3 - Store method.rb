module FlavorPoffin
#-------------------------------------------------------------------------------
# Used when player cooks with AI
# Mode: Multiple player
#-------------------------------------------------------------------------------
Flavor_Multiple_Mode = [
# spicy | dry | sweet | bitter | sour
[10,0,0,0,0],     # Cheri Berry Flavor
[0,10,0,0,0],     # Chesto Berry Flavor
[0,0,10,0,0],     # Pecha Berry Flavor
[0,0,0,10,0],     # Rawst Berry Flavor
[0,0,0,0,10],     # Aspear Berry Flavor
[10,0,10,10,10],  # Leppa Berry Flavor
[10,10,0,10,10],  # Oran Berry Flavor
[10,10,10,0,10],  # Persim Berry Flavor
[10,10,10,10,0],  # Lum Berry Flavor
[0,10,10,10,10],  # Sitrus Berry Flavor
[15,0,0,0,0],     # Figy Berry Flavor
[0,15,0,0,0],     # Wiki Berry Flavor
[0,0,15,0,0],     # Mago Berry Flavor
[0,0,0,15,0],     # Aguav Berry Flavor
[0,0,0,0,15],     # Iapapa Berry Flavor
[10,10,0,0,0],    # Razz Berry Flavor
[0,10,10,0,0],    # Bluk Berry Flavor
[0,0,10,10,0],    # Nanab Berry Flavor
[0,0,0,10,10],    # Wepear Berry Flavor
[10,0,0,0,10],    # Pinap Berry Flavor
[10,0,10,10,0],   # Pomeg Berry Flavor
[0,10,0,10,10],   # Kelpsy Berry Flavor
[10,0,10,0,10],   # Qualot Berry Flavor
[10,10,0,10,0],   # Hondew Berry Flavor
[0,10,10,0,10],   # Grepa Berry Flavor
[20,10,0,0,0],    # Tamato Berry Flavor
[0,20,10,0,0],    # Cornn Berry Flavor
[0,0,20,10,0],    # Magost Berry Flavor
[0,0,0,20,10],    # Rabuta Berry Flavor
[10,0,0,0,20],    # Nomel Berry Flavor
[30,10,0,0,0],    # Spelon Berry Flavor
[0,30,10,0,0],    # Pamtre Berry Flavor
[0,0,30,10,0],    # Watmel Berry Flavor
[0,0,0,30,10],    # Durin Berry Flavor
[10,0,0,0,30],    # Belue Berry Flavor
[15,0,10,0,0],    # Occa Berry Flavor     # Generation IV
[0,15,0,10,0],    # Passho Berry Flavor   # Generation IV
[0,0,15,0,10],    # Wacan Berry Flavor    # Generation IV
[10,0,0,15,0],    # Rindo Berry Flavor    # Generation IV
[0,10,0,0,15],    # Yache Berry Flavor    # Generation IV
[15,0,0,10,0],    # Chople Berry Flavor   # Generation IV
[0,15,0,0,10],    # Kebia Berry Flavor    # Generation IV
[10,0,15,0,0],    # Shuca Berry Flavor    # Generation IV
[0,10,0,15,0],    # Coba Berry Flavor     # Generation IV
[0,0,10,0,15],    # Payapa Berry Flavor   # Generation IV
[20,0,0,0,10],    # Tanga Berry Flavor    # Generation IV
[10,20,0,0,0],    # Charti Berry Flavor   # Generation IV
[0,10,20,0,0],    # Kasib Berry Flavor    # Generation IV
[0,0,10,20,0],    # Haban Berry Flavor    # Generation IV
[0,0,0,10,20],    # Colbur Berry Flavor   # Generation IV
[25,10,0,0,0],    # Babiri Berry Flavor   # Generation IV
[0,25,10,0,0],    # Chilan Berry Flavor   # Generation IV
[30,10,30,0,0],   # Liechi Berry Flavor
[0,30,10,30,0],   # Ganlon Berry Flavor
[0,0,30,10,30],   # Salac Berry Flavor
[30,0,0,30,10],   # Petaya Berry Flavor
[10,30,0,0,30],   # Apicot Berry Flavor
[30,10,30,10,30], # Lansat Berry Flavor
[30,10,30,10,30], # Starf Berry Flavor
[40,10,0,0,0],    # Enigma Berry Flavor
[0,40,10,0,0],    # Micle Berry Flavor    # Generation IV
[0,0,40,10,0],    # Custap Berry Flavor   # Generation IV
[0,0,0,40,10],    # Jaboca Berry Flavor   # Generation IV
[10,0,0,0,40],    # Rowap Berry Flavor    # Generation IV
[10,0,0,0,0],     # Roseli Berry Flavor
[0,0,10,0,0],     # Kee Berry Flavor
[0,0,0,0,10]      # Maranga Berry Flavor
]
#-------------------------------------------------------------------------------
# Used when cooking alone
# Mode: Single
#-------------------------------------------------------------------------------
Flavor_Alone_Mode = [
# spicy | dry | sweet | bitter | sour
[9,0,0,0,0],   # Cheri Berry Flavor
[0,9,0,0,0],   # Chesto Berry Flavor
[0,0,9,0,0],   # Pecha Berry Flavor
[0,0,0,9,0],   # Rawst Berry Flavor
[0,0,0,0,9],   # Aspear Berry Flavor
[9,0,0,0,0],   # Leppa Berry Flavor
[0,9,0,0,0],   # Oran Berry Flavor
[0,0,9,0,0],   # Persim Berry Flavor
[0,0,0,9,0],   # Lum Berry Flavor
[0,0,0,0,9],   # Sitrus Berry Flavor
[14,0,0,0,0],  # Figy Berry Flavor
[0,14,0,0,0],  # Wiki Berry Flavor
[0,0,14,0,0],  # Mago Berry Flavor
[0,0,0,14,0],  # Aguav Berry Flavor
[0,0,0,0,14],  # Iapapa Berry Flavor
[0,9,0,0,0],   # Razz Berry Flavor
[0,0,9,0,0],   # Bluk Berry Flavor
[0,0,0,9,0],   # Nanab Berry Flavor
[0,0,0,0,9],   # Wepear Berry Flavor
[9,0,0,0,0],   # Pinap Berry Flavor
[8,0,0,8,0],   # Pomeg Berry Flavor
[0,8,0,0,8],   # Kelpsy Berry Flavor
[8,0,8,0,0],   # Qualot Berry Flavor
[0,8,0,8,0],   # Hondew Berry Flavor
[0,0,8,0,8],   # Grepa Berry Flavor
[9,9,0,0,0],   # Tamato Berry Flavor
[0,9,9,0,0],   # Cornn Berry Flavor
[0,0,9,9,0],   # Magost Berry Flavor
[0,0,0,9,9],   # Rabuta Berry Flavor
[9,0,0,0,9],   # Nomel Berry Flavor
[19,9,0,0,0],  # Spelon Berry Flavor
[0,19,9,0,0],  # Pamtre Berry Flavor
[0,0,19,9,0],  # Watmel Berry Flavor
[0,0,0,19,9],  # Durin Berry Flavor
[9,0,0,0,19],  # Belue Berry Flavor
[13,0,8,0,0],  # Occa Berry Flavor     # Generation IV
[0,13,0,8,0],  # Passho Berry Flavor   # Generation IV
[0,0,13,0,8],  # Wacan Berry Flavor    # Generation IV
[8,0,0,13,0],  # Rindo Berry Flavor    # Generation IV
[0,8,0,0,13],  # Yache Berry Flavor    # Generation IV
[13,0,0,8,0],  # Chople Berry Flavor   # Generation IV
[0,13,0,0,8],  # Kebia Berry Flavor    # Generation IV
[8,0,13,0,0],  # Shuca Berry Flavor    # Generation IV
[0,8,0,13,0],  # Coba Berry Flavor     # Generation IV
[0,0,8,0,13],  # Payapa Berry Flavor   # Generation IV
[18,0,0,0,0],  # Tanga Berry Flavor    # Generation IV
[0,18,0,0,0],  # Charti Berry Flavor   # Generation IV
[0,0,18,0,0],  # Kasib Berry Flavor    # Generation IV
[0,0,0,18,0],  # Haban Berry Flavor    # Generation IV
[0,0,0,0,18],  # Colbur Berry Flavor   # Generation IV
[14,9,0,0,0],  # Babiri Berry Flavor   # Generation IV
[0,14,9,0,0],  # Chilan Berry Flavor   # Generation IV
[18,0,28,0,0], # Liechi Berry Flavor
[0,18,0,28,0], # Ganlon Berry Flavor
[0,0,18,0,28], # Salac Berry Flavor
[28,0,0,18,0], # Petaya Berry Flavor
[0,28,0,0,18], # Apicot Berry Flavor
[18,0,18,0,0], # Lansat Berry Flavor
[18,0,18,0,0], # Starf Berry Flavor
[29,9,0,0,0],  # Enigma Berry Flavor
[0,29,9,0,0],  # Micle Berry Flavor    # Generation IV
[0,0,29,9,0],  # Custap Berry Flavor   # Generation IV
[0,0,0,29,9],  # Jaboca Berry Flavor   # Generation IV
[9,0,0,0,29],  # Rowap Berry Flavor    # Generation IV
[9,0,0,0,0],   # Roseli Berry Flavor
[0,0,9,0,0],   # Kee Berry Flavor
[0,0,0,0,9]    # Maranga Berry Flavor
]
#-------------------------------------------------------------------------------
# Smoothness (calculate for increasing sheen)
# Add new like this form:
# Smoothness = [ [[Name of berry], number] , [ [Name of berry], number] ]
#-------------------------------------------------------------------------------
Smoothness = [
# Smooth: 25
[["Cheri Berry","Chesto Berry","Pecha Berry","Rawst Berry","Aspear Berry",
"Figy Berry","Wiki Berry","Mago Berry","Aguav Berry","Iapapa Berry"], 25],
# Smooth: 20
[["Leppa Berry","Oran Berry","Persim Berry","Lum Berry","Sitrus Berry",
"Razz Berry","Bluk Berry","Nanab Berry","Wepear Berry","Pinap Berry",
"Pomeg Berry","Kelpsy Berry","Qualot Berry","Hondew Berry","Grepa Berry"], 20],
# Smooth: 30
[["Tamato Berry","Cornn Berry","Magost Berry","Rabuta Berry","Nomel Berry",
"Occa Berry","Passho Berry","Wacan Berry","Rindo Berry","Yache Berry",
"Chople Berry","Kebia Berry","Shuca Berry","Coba Berry","Payapa Berry"], 30],
# Smooth: 35
[["Spelon Berry","Pamtre Berry","Watmel Berry","Durin Berry","Belue Berry",
"Tanga Berry","Charti Berry","Kasib Berry","Haban Berry","Colbur Berry",
"Babiri Berry","Chilan Berry"], 35],
# Smooth: 40
[["Liechi Berry","Ganlon Berry","Salac Berry","Petaya Berry","Apicot Berry"], 40],
# Smooth: 50
[["Lansat Berry","Starf Berry"], 50],
# Smooth: 60
[["Enigma Berry","Micle Berry","Custap Berry","Jaboca Berry","Rowap Berry",
"Roseli Berry","Kee Berry","Maranga Berry"], 60]
]
#-------------------------------------------------------------------------------
# Function
#-------------------------------------------------------------------------------
  module_function
  
  # Calculate for choosing flavor
  def calc(id,berry)
    (0...id.length).each { |i| return i if id[i] == berry }
    return 0
  end
  
  # Return flavor
  # Alone
  def alone(id,berry); return Flavor_Alone_Mode[calc(id,berry)]; end
  # Multiple
  def multiple(id,berry); return Flavor_Multiple_Mode[calc(id,berry)]; end
  
  # id (store id of berry), berry (berry chose)
  # time (time taken), m (burn + overload)
  def resultAlone(id,berry,time,m)
    flavor = self.alone(id,berry)
    max=0; count=0; pos = []
    (0...flavor.length).each { |i|
      flavor[i] = flavor[i] * 60 / time - m
      flavor[i] = 0 if flavor[i]<0
      max = flavor[i] if flavor[i]>max
      if flavor[i]>0
        count+=1
        pos<<i
      end
    }
    # Set level
    level = max
    level = 0 if level<=0
    # Set name
    count=5 if level>=50
    p = pos.size!=0 ? pos.sort.reverse : pos
    name = setName(count,flavor,p)
    # Return [level, name, id of graphics, color for setting graphics (position), flavor]
    return [level,name[0],name[1],name[2],flavor]
  end
  
  # same (check: when player used same berry, it will be foul poffin)
  # flavor (sum flavor),reverse (sum weakness of flavor)
  # time (time taken), m (burn + overload)
  def resultMultiple(same,flavor,reverse,time,m)
    result = []
    (0...5).each { |i| result<<(flavor[i]-reverse[i]) }
    # Count for subtracting
    count = 0
    result.each {|i| count+=1 if i<0}
    # Set value
    max=0; count2=0; pos = []
    (0...result.size).each { |i|
      # Calculate poffin
      result[i] -= count
      result[i] = result[i] * 60 / time - m
      result[i].round
      result[i] = 0 if result[i] < 0
      # Set
      max = result[i] if result[i]>max
      if result[i]>0
        count2+=1
        pos<<i
      end
    }
    # Set name
    count2=5 if max>=50
    p = pos.size!=0 ? pos.sort.reverse : pos
    name = setName(count2,result,p,same)
    # Return [level, name, id of graphics, color for setting graphics (position), flavor]
    return [max,name[0],name[1],name[2],result]
  end
  
  # Set name of poffin
  def setName(count,flavor=nil,pos=nil,same=false)
    return ["Foul Poffin",0,nil] if same
    # Count flavor>0
    begin
      # Color: 0: spicy; 1: dry; 2: sweet; 3: bitter; 4: sour
      color=nil
      case count
      when 0; name = "Foul Poffin"
      when 1
        name = ""
        arr = ["Spicy","Dry","Sweet","Bitter","Sour"]
        pos.each { |i|
          (0...5).each { |j| 
            (name = arr[j]; color = j; break) if flavor[i]==flavor[j]
          }
        }
        name += " Poffin"
      when 2
        color = []
        f = flavor.reject{ |i| i<=0 }.uniq!
        name = ""; added = false
        arr = ["Spicy","Dry","Sweet","Bitter","Sour"]
        if f.nil?
          pos.each { |i|
            (0...5).each { |j| 
              (name += arr[j]; color << j; break) if flavor[i]==flavor[j]
            }
            (name += " "; added = true) if name!="" && !added
          }
        else
          (0...flavor.length).each { |i|
            (name+=arr[i]; color<<i) if flavor[i]!=0
            (name+= " "; added = true) if name!="" && !added
          }
        end
        name += " Poffin"
      when 3; name = "Rich Poffin"
      when 4; name = "Overripe Poffin"
      when 5; name = "Mild Poffin"
      end
      return [name,count,color]
    rescue
      p "Error: Check 'setName' of Poffin"
      return
    end
  end
  
  # Calculate smooth of berry (it depends quantity of player)
  def smooth(berry,alone=false)
    if alone
      Smoothness.each { |s| return s[1] if s[0].include?(GameData::Item.get(berry).name) }
    end
    if !berry.is_a?(Array)
      p "You need to set Array for 'berry'"
      return
    end
    sum = 0
    berry.each{ |i| 
      Smoothness.each { |s| sum+=s[1] if s[0].include?(GameData::Item.get(i).name) } 
    }
    average = sum/berry.size - berry.size
    average = 99 if average>=99
    return average
  end
end