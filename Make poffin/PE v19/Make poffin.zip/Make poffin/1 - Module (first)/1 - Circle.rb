module CirclePoffin
  # Set origin of the coordinates axis
  OXp = Settings::SCREEN_WIDTH/2
  OYp = Settings::SCREEN_HEIGHT/2
  
  module_function
  
  # Check quadrant
  def checkQuadrant(x,y)
    if x>OXp && y<=OYp
      return 1
    elsif x<=OXp && y<OYp
      return 2
    elsif x<OXp && y>=OYp
      return 3
    elsif x>=OXp && y>OYp
      return 4
    end
    return 0
  end
  
  # Check position of (x,y)
  def inCircle?(x,y,r)
    distance = returnDistance(x,y)
    return true if distance<=r
    return false
  end
  
  # Return value 'distance of (x,y)'
  def returnDistance(x,y)
    distance = Math.sqrt((OXp-x)**2+(OYp-y)**2)
    return distance
  end
  
  # Return value 'cos of (x,y)'
  def returnCos(x,y)
    case checkQuadrant(x,y)
    when 1,3; adjacentside = Math.sqrt((OXp-x)**2)
    when 2,4; adjacentside = Math.sqrt((OYp-y)**2)
    else; adjacentside = 0
    end
    hypotenuse = returnDistance(x,y) 
    ret = (adjacentside/hypotenuse)
    return ret
  end
  
  # Return angle
  def returnAngle(x,y)
    ret = Math.acos(returnCos(x,y)) # Radian
    return (ret*180/Math::PI)
  end
  
  # Check move 'clockwise'
  def clockwise?(x1,y1,x2,y2)
    if checkQuadrant(x1,y1)==checkQuadrant(x2,y2)
      return true if returnCos(x1,y1)<returnCos(x2,y2)
    elsif checkQuadrant(x2,y2)-checkQuadrant(x1,y1)==1 ||
        (checkQuadrant(x2,y2)==1 && checkQuadrant(x1,y1)==4)
      return true
    end
    return false
  end
  
  def counterClockwise?(x1,y1,x2,y2)
    if checkQuadrant(x1,y1)==checkQuadrant(x2,y2)
      return true if returnCos(x1,y1)>returnCos(x2,y2)
    elsif checkQuadrant(x1,y1)-checkQuadrant(x2,y2)==1 ||
        (checkQuadrant(x2,y2)==4 && checkQuadrant(x1,y1)==1)
      return true
    end
    return false
  end
  
end
