module BerryPoffin
  # Store berry for expert
  BerryExpert = [
    "Liechi Berry","Ganlon Berry","Salac Berry","Petaya Berry",
    "Apicot Berry","Lansat Berry","Starf Berry","Enigma Berry",
    "Micle Berry","Custap Berry","Jaboca Berry","Rowap Berry",
    "Roseli Berry","Kee Berry","Maranga Berry"
  ]
  
  module_function
  
  # Return ID of berry
  def playerID
    scene  = PokemonBag_Scene.new
    screen = PokemonBagScreen.new(scene,$PokemonBag)
		berry  = screen.pbChooseItemScreen( Proc.new{ |item| GameData::Item.get(item).is_berry? } ) 
    return berry if berry
		return nil
  end
  
  def playerChoosed
    ret  = false
		item = self.playerID
		return 0 if item.nil?
    berry = GameData::Item.get(item).id_number
    $PokemonBag.pbDeleteItem(berry,1) if berry>0
    return berry
  end
  
  def listBerry
    list = []
		item = []
		GameData::Item.each { |i| item << i.id }
		item.each { |i| list << i if GameData::Item.get(i).is_berry? }
    return list
  end
  
  def random; listBerry[rand(listBerry.length)]; end
  
  def randomExpert
    return nil if BerryExpert.length<=0
    berry = nil
    random = BerryExpert[rand(BerryExpert.length)]
		item = []
		GameData::Item.each { |i| item << i.id }
		item.each { |i| berry = i if GameData::Item.get(i).name == random && GameData::Item.get(i).is_berry? }
    return berry
  end
  
end