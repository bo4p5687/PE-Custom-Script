class PokemonGlobalMetadata
  attr_accessor :poffin
  
  alias poffin_ini initialize
  def initialize
    # Old
    poffin_ini
    # New
    @poffin = {}
    # Foul Poffin
    @poffin[:foul] = []
    # One flavor
    # @poffin[:one]["Spicy Poffin"], @poffin[:one]["Dry Poffin"], etc
    @poffin[:one] = {}
    n = NamePoffin.single
    n.each { |i| @poffin[:one][i]=[] }
    # Two flavors
    # @poffin[:two]["Spicy Dry Poffin"], @poffin[:two]["Spicy Sweet Poffin"], etc
    @poffin[:two] = {}
    n  = NamePoffin.double
    n.each { |i|
      i.each { |j| 
        @poffin[:two][j] = []
      }
    }
    # Three flavors
    @poffin[:rich] = []
    # Four flavors
    @poffin[:overripe] = []
    # Poffin has level 50
    @poffin[:mild] = []
  end
end