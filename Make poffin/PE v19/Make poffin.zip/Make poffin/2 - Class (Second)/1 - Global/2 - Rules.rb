class RulesPoffin
  
  def rules
    @rules={} if !@rules
    return @rules
  end
  
  def clearRules; self.rules.clear; end
  
  def recordRules(rule,value=nil)
    rules = self.rules
    case rule.to_s.downcase
    when "notsame";  rules["notSame"]  = true
    when "quantity"; rules["quantity"] = value
    # Set for AI
    # Value: 100% (all players)
    # Quantity
    # 1. 100%
    # 2. 50% or 100%
    # 3. 30%(1 player) 60%(2 players) 90%~100%(3 player)
    when "newbie"; rules["newbie"] = value.nil? ? 100 : value
    when "oldbie"; rules["oldbie"] = value.nil? ? 100 : value
    when "expert"; rules["expert"] = value.nil? ? 100 : value
    end
  end
  
end
#-------------------------------------------------------------------------------
# Store value
#-------------------------------------------------------------------------------
$rulesPoffin = RulesPoffin.new
#-------------------------------------------------------------------------------
# Set rule for making Poffin
#-------------------------------------------------------------------------------
def setRulesPoffin(rule,value=nil)
  begin
    $rulesPoffin.recordRules(rule,value)
  rescue
    p "You have an error (Rules Poffin)"
  end
end
