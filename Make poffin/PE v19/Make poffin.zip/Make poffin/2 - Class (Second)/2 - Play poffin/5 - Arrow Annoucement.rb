class Poffin
  
  def createArrow
    if !@sprites["arrow"]
      create_sprite("arrow","Arrow",@viewport)
      w = @sprites["arrow"].bitmap.width/2
      h = @sprites["arrow"].bitmap.height
      set_src_wh_sprite("arrow",w,h)
      set_src_xy_sprite("arrow",0,0)
      set_oxoy_sprite("arrow",w/2,h/2)
    end
    set_visible_sprite("arrow",true) if !@sprites["arrow"].visible
    mirror = rand(2)==0 ? true : false
    w = @sprites["arrow"].bitmap.width/2
    @sprites["arrow"].mirror = mirror
    set_xy_sprite("arrow",Graphics.width/2+(mirror ? w : -w),Graphics.height/2)
    @guide = mirror ? 0 : 1
  end
  
  def displayArrow
    return if !@sprites["arrow"]
    set_visible_sprite("arrow") if @timeGuide%20==0
  end
#-------------------------------------------------------------------------------
  # Set change level when time=1/3*TimeMax or when player scroll right
  def nextLevel
    if @anim>=TimeMax/3*@level || @countGuide>=RightGuide
			if @level==3
        @finish=true
        return
      end
      @countGuide=0
      @level+=1
    end
  end
#-------------------------------------------------------------------------------
  def drawTextAnnouncement(type=0,size=60)
    case type
    when 0; string = "It'll burn! Stir it!"
    when 1; string = "Too fast! Overflow!"
    end
    create_sprite_2("text",@viewport) if !@sprites["text"]
    clearTxt("text")
    textpos = []
    textpos<<[string,Graphics.width/2,Graphics.height/2,0,BaseColor,ShadowColor]
    drawTxt("text",textpos,nil,size,1,false,1)
  end

end
