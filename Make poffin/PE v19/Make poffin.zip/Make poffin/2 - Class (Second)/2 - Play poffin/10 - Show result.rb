class Poffin
  
  def showResult(result,level,nameofresult)
    # Create table 'result'
    if !@sprites["table"]
      create_sprite("table","Result",@viewport)
      w = @sprites["table"].bitmap.width
      h = @sprites["table"].bitmap.height
      set_oxoy_sprite("table",w/2,h/2)
      x = Graphics.width/2
      y = Graphics.height/2
      set_xy_sprite("table",x,y)
    end
    # Draw text
    create_sprite_2("text2",@viewport) if !@sprites["text2"]
    clearTxt("text2")
    bitmap = @sprites["text2"].bitmap
    # Color
    base   = Color.new(150,248,247)
    shadow = Color.new(13,71,220)
    # Text
    txtpos = []
    string = "RESULTS"
    xyscreen = [Graphics.width, Graphics.height]
    x = xyscreen[0]/2 - bitmap.text_size(string).width/2
    y = xyscreen[1]/2 - @sprites["table"].bitmap.height/2 + 10
    txtpos<<[string,x,y,0,base,shadow]
    string  = ["Time","Overflowed","Burned"]
    string2 = ["#{@anim/40}","#{@countOverload} times","#{@countBurn} times"]
    i = 0
    3.times { 
      x = (xyscreen[0] - @sprites["table"].bitmap.width)/2 + 10
      y  += 10 + bitmap.text_size(string[i]).height
      txtpos<<[string[i],x,y,0,base,shadow]
      x  = xyscreen[0] - (xyscreen[0] - @sprites["table"].bitmap.width)/2
      x -= bitmap.text_size(string2[i]).width + 10
      txtpos<<[string2[i],x,y,0,base,shadow]
      i+=1
    }
    string3 = ["Level: ","#{level}"]
    x = (xyscreen[0] - @sprites["table"].bitmap.width)/2 + 10
    y = (xyscreen[1] + @sprites["table"].bitmap.height)/2 - 70
    txtpos<<[string3[0],x,y,0,base,shadow]
    x += bitmap.text_size(string3[0]).width + 10
    txtpos<<[string3[1],x,y,0,base,shadow]
    # Draw bitmap 'Poffin'
    if !@sprites["poffin"]
      xdrw = x+bitmap.text_size(string3[1]).width+30; ydrw = y+22
      drawPoffin(xdrw,ydrw,result)
    end
    string4 = ["Name: ","#{nameofresult}"]
    x = (xyscreen[0] - @sprites["table"].bitmap.width)/2 + 10
    y = (xyscreen[1] + @sprites["table"].bitmap.height)/2 - 40
    txtpos<<[string4[0],x,y,0,base,shadow]
    x += bitmap.text_size(string4[0]).width + 10
    txtpos<<[string4[1],x,y,0,base,shadow]
    # Draw text
    drawTxt("text2",txtpos,"Arial")
    return true if checkInput(Input::USE)
    return false
  end
  
end