class Poffin
  
  # Create scene
  def createScene
    # Background
    create_sprite("bg","Background",@viewport)
    # Fire
    create_sprite("fire","Fire",@viewport)
    w = @sprites["fire"].bitmap.width/3
    h = @sprites["fire"].bitmap.height
    set_src_wh_sprite("fire",w,h)
    set_src_xy_sprite("fire",0,0)
    set_oxoy_sprite("fire",w/2,h/2)
    set_xy_sprite("fire",Graphics.width/2,Graphics.height/2)
    set_visible_sprite("fire")
    # Bowl
    create_sprite("bowl","Bowl",@viewport)
    ox = @sprites["bowl"].bitmap.width/2
    oy = @sprites["bowl"].bitmap.height/2
    set_oxoy_sprite("bowl",ox,oy)
    set_xy_sprite("bowl",Graphics.width/2,Graphics.height/2)
    # Poffin
    create_sprite("core","Core",@viewport)
    w = @sprites["core"].bitmap.width/3
    h = @sprites["core"].bitmap.height
    set_src_wh_sprite("core",w,h)
    set_src_xy_sprite("core",0,0)
    set_oxoy_sprite("core",w/2,h/2)
    set_xy_sprite("core",Graphics.width/2,Graphics.height/2)
    # Depart
    create_sprite("depart","Depart",@viewport)
    w = @sprites["depart"].bitmap.width/3
    h = @sprites["depart"].bitmap.height
    set_src_wh_sprite("depart",w,h)
    set_src_xy_sprite("depart",0,0)
    set_oxoy_sprite("depart",w/2,h/2)
    set_zoom("depart",2,2)
    set_xy_sprite("depart",Graphics.width/2,Graphics.height/2)
    set_visible_sprite("depart")
  end
  
  def announceStart
    set_visible_sprite("depart",true)
    pbSEPlay("Battle ball drop")
    pbWait(20)
    (1..2).each { |i|
      x = @sprites["depart"].bitmap.width/3*i
      set_src_xy_sprite("depart",x,0)
      pbSEPlay("Battle ball drop")
      pbWait(20)
    }
    dispose("depart")
    # Start
    if !@sprites["start"]
      create_sprite("start","Start",@viewport)
      ox = @sprites["start"].bitmap.width/2
      oy = @sprites["start"].bitmap.height/2
      set_oxoy_sprite("start",ox,oy)
      set_zoom("start",2,2)
      set_xy_sprite("start",Graphics.width/2,Graphics.height/2)
    end
    pbSEPlay("Battle ball drop")
    pbWait(20)
    dispose("start")
  end
  
  def announceFinish
    if !@sprites["end"]
      create_sprite("end","Done",@viewport)
      ox = @sprites["end"].bitmap.width/2
      oy = @sprites["end"].bitmap.height/2
      set_oxoy_sprite("end",ox,oy)
      set_zoom("end",2,2)
      set_xy_sprite("end",Graphics.width/2,Graphics.height/2)
    end
    pbSEPlay("Battle ball drop")
    pbWait(20)
    dispose("end")
  end
  
  def startScene
    # Player choose berry
    @berryplayer=BerryPoffin.playerChoosed
    return if @berryplayer<=0
    # Create scene
    self.createScene
    # Fade
    pbFadeInAndShow(@sprites) { update }
    # Define quantity
    self.defineQuantity
    # Choose berry
    self.setAI
    return if !self.setBerry
    # Check after set AI. Quantity (maximum) = 3
    if @quantity!=@ai.size || @quantity>3
      p "You need to check 'set rule of Poffin'"
      return
    end
    # Check x,y of AI
    return if !self.setXYAI
=begin
		# Store result
		@anim = 1000
		result = self.returnResult
		self.storeInGlobal(result)
		return
=end
    # Set animation
    animationBerry(@berryplayer)
    if @quantity>0
      animationBerry(@berry[0],1)
      animationBerry(@berry[1],2) if @quantity>1
      animationBerry(@berry[2],3) if @quantity>2
    end
    # Announce (start)
    self.announceStart
    # Create point
    if @quantity>0
      createAIpoint
      createAIpoint(1) if @quantity>1
      createAIpoint(2) if @quantity>2
    end
    # Value
    time = 0; timeout = false
    loop do
      update_ingame
      @anim+=1
      if !timeout
        # Play
        self.play
        # Time out
        timeout = true if @anim>=TimeMax || @finish
      else
        break
      end
    end
    # Finish
    self.announceFinish
    # Store result
    result = self.returnResult
    self.storeInGlobal(result)
    # Show 'result'
    loop do
      # Update
      self.update_ingame
      break if self.showResult(result,result[0],result[1])
    end
    # Fade
    pbFadeOutAndHide(@sprites) { update }
  end
  
end