class Poffin
  
  # Burn
  def createBurn
    i = 0
    loop do
      if !@sprites["burn #{i}"]
        create_sprite("burn #{i}","Burn",@viewport)
        w = @sprites["burn #{i}"].bitmap.width/3
        h = @sprites["burn #{i}"].bitmap.height
        set_src_wh_sprite("burn #{i}",w,h)
        set_oxoy_sprite("burn #{i}",w/2,h/2)
        break
      end
      if !@sprites["burn #{i}"].visible
        @sprites["burn #{i}"].visible = true
        break
      end
      i+=1
    end
    set_src_xy_sprite("burn #{i}",0,0)
    x = Graphics.width/2 + (rand(2)==0 ? rand(RadiusCore) : -rand(RadiusCore))
    y = Graphics.height/2 + (rand(2)==0 ? rand(RadiusCore) : -rand(RadiusCore))
    set_xy_sprite("burn #{i}",x,y)
    # Draw text
    drawTextAnnouncement
  end
  
  def burn
    i=0
    loop do
      break if !@sprites["burn #{i}"]
      if @sprites["burn #{i}"].visible
        x = @sprites["burn #{i}"].bitmap.width/3
        @sprites["burn #{i}"].src_rect.x += x
        if @sprites["burn #{i}"].src_rect.x>=3*x
          @sprites["burn #{i}"].visible = false
          # Clear
          clearTxt("text")if @sprites["text"]
        end
      end
      i+=1
    end
  end
  
  def canBurn?
    if @burn>=40
      # Count
      @countBurn+=1
      # Reset
      @burn=0
      return true 
    end
    return false
  end
#-------------------------------------------------------------------------------
  # Overload
  def createOverload
    i = 0
    loop do
      if !@sprites["overload #{i}"]
        create_sprite("overload #{i}","Overload",@viewport)
        w = @sprites["overload #{i}"].bitmap.width/3
        h = @sprites["overload #{i}"].bitmap.height
        set_src_wh_sprite("overload #{i}",w,h)
        set_oxoy_sprite("overload #{i}",w/2,h/2)
        break
      end
      if !@sprites["overload #{i}"].visible
        @sprites["overload #{i}"].visible = true
        break
      end
      i+=1
    end
    set_src_xy_sprite("overload #{i}",0,0)
    x = Graphics.width/2 + (rand(2)==0 ? rand(RadiusCore) : -rand(RadiusCore))
    y = Graphics.height/2 + (rand(2)==0 ? rand(RadiusCore) : -rand(RadiusCore))
    @newmouse=[0,0] if !@newmouse
    case CirclePoffin.checkQuadrant(@newmouse[0],@newmouse[1])
    when 3; mirror=false; angle=90
    when 4; mirror=true; angle=270
    when 1; mirror=true; angle=0
    else; mirror=false; angle=0
    end
    @sprites["overload #{i}"].mirror=mirror
    set_angle_sprite("overload #{i}",angle)
    set_xy_sprite("overload #{i}",x,y)
    # Draw text
    drawTextAnnouncement(1)
  end
  
  def overload
    i=0
    loop do
      break if !@sprites["overload #{i}"]
      if @sprites["overload #{i}"].visible
        x = @sprites["overload #{i}"].bitmap.width/3
        @sprites["overload #{i}"].src_rect.x += x
        if @sprites["overload #{i}"].src_rect.x>=3*x
          @sprites["overload #{i}"].visible = false
          # Clear
          clearTxt("text")if @sprites["text"]
        end
      end
      i+=1
    end
  end
  
  def canOverload?
    if @overload>=40 && @level<3
      # Count
      @countOverload+=1
      # Reset
      @overload = 0
      return true
    end
    return false
  end
  
end
