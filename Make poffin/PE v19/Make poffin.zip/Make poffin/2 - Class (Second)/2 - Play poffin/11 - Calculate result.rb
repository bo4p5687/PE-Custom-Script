class Poffin
  
  # Single mode
  def resultAlone
    # Calculate
    time = @anim/40; m = @countOverload+@countBurn
    ret = FlavorPoffin.resultAlone(@idberry,@berryplayer,time,m)
    # Store flavor
    @storeflavor = ret[4]
    return ret
  end
  
  # Multiple mode
  def resultMultiple
    name = [@berryplayer]
    id = []; flavor = []; reverse = []
    5.times { flavor<<0; reverse<<0 }
    @berry.each { |i| name<<i }
    name.each { |i| id<<FlavorPoffin.multiple(@idberry,i) }
    # Store id of berry
    @flavormulti = name
    # Check 'rule Same' for making Foul Poffin
    checksame = name.uniq!
    same = !@rules["notSame"].nil? || checksame.nil? ? false : true
    # Set flavor
    id.each { |i| (0...i.length).each { |j| flavor[j]+=i[j] } }
    # Set reverse of flavor
    (0...flavor.length).each { |i| 
      reverse[i] = (i+1)==flavor.length ? flavor[0] : flavor[i+1]
    }
    # Set time, set sum of 'overload' and 'burn'
    time = @anim/40; m = @countOverload+@countBurn
    ret = FlavorPoffin.resultMultiple(same,flavor,reverse,time,m)
    # Store flavor
    @storeflavor = ret[4]
    return ret
  end
  
  def returnResult
    ret = @quantity==0 ? self.resultAlone : self.resultMultiple
    return ret
  end
  
  def returnSheen
    ret = @quantity==0 ? FlavorPoffin.smooth(@berryplayer,true) : FlavorPoffin.smooth(@flavormulti)
    return ret
  end
  
end