class Poffin
  
  def play
    # Fire (animation)
    fire(@level,@anim)
    # Arrow for guiding
    createArrow if @timeGuide==0
    @timeGuide<TimeAppearArrow ? @timeGuide+=1 : @timeGuide=0
    displayArrow
    # Burn cake (animation)
    burn if @anim%5==0
    # Overload cake (animation)
    overload if @anim%5==0
    # Set AI
    # Create
    if @quantity>0
      featureAI
      featureAI(1) if @quantity>1
      featureAI(2) if @quantity>2
    end
    # Save position of mouse
    mouse = posMouse
    @newMouse=[0,0] if @newMouse.nil?
    @newMouse = posMouse
    # Next level
    nextLevel
    # Click / Hold for play
    if (clickedMouse? || holdMouse?) && CirclePoffin.inCircle?(mouse[0],mouse[1],RadiusCore)      
      x1=@oldMouse[0]; y1=@oldMouse[1]
      x2=@newMouse[0]; y2=@newMouse[1]
      if @oldMouse!=@newMouse
        angle = CirclePoffin.returnAngle(x2,y2)
        case CirclePoffin.checkQuadrant(x2,y2)
        when 2; set_angle_sprite("core",angle)
        when 3; set_angle_sprite("core",angle+90)
        when 4; set_angle_sprite("core",angle+180)
        when 1; set_angle_sprite("core",angle+270)
        end
        # Clockwise
        if CirclePoffin.clockwise?(x1,y1,x2,y2)
          @clockwise = true
          if @counter
            @countMove = 0
            @counter = false
          end
          case @guide
          when 0; @countGuide+=5
          when 1; @countGuide-=1
          end
          countMoveForZoom # Count for zooming
        # Counter-Clockwise
        elsif CirclePoffin.counterClockwise?(x1,y1,x2,y2)
          @counter = true
          if @clockwise
            @countMove = 0
            @clockwise = false
          end
          case @guide
          when 0; @countGuide-=1
          when 1; @countGuide+=5
          end
          countMoveForZoom # Count for zooming
        end
        # Set old = new
        @oldMouse=@newMouse
        @countGuide=0 if @countGuide<0
      end
    end
    zoomOutCore # Zoom out (core)
  end
#-------------------------------------------------------------------------------
  def zoomOutCore
    # Decrease 'count move' / Inscrease 'count no move'
    case @level
    when 1; @countMove-=5; @countNoMove+=5 
    when 2; @countMove-=3; @countNoMove+=7
    when 3; @countMove-=3; @countNoMove+= @quantity==0 ? 8 : 9
    end
    if @countNoMove>=50
      # Reset when player doesn't click/move mouse
      @clockwise = false; @counter = false
      # Zoom out
      if (@sprites["core"].zoom_x>1 || @sprites["core"].zoom_y>1)
        zoomx = @sprites["core"].zoom_x 
        zoomy = @sprites["core"].zoom_y 
        zoomx<=1 ? zoomx=1 : zoomx-=0.1
        zoomy<=1 ? zoomy=1 : zoomy-=0.1
        set_zoom("core",zoomx,zoomy)
        # Reset overload
        @overload>0 ? @overload-=1 : @overload=0
      end
      @countMove=0 if @countMove<=0
      @countNoMove=0
      # Count burn
      @burn+= @level==1 ? 5 : @level==2 ? 7 : 10
      createBurn if canBurn?
    end
    # Reset 'overload' if cake isn't biggest
    if @sprites["core"].zoom_x<LimitScale && @sprites["core"].zoom_y<LimitScale
      @overload=0
    else; set_zoom("core",LimitScale,LimitScale)
    end
  end
  
  def countMoveForZoom
    case @level
    when 1; @countMove+=28
    when 2; @countMove+=24
    when 3; @countMove+=20
    end
    @countNoMove-=25
    @countNoMove=0 if @countNoMove<=0
    # Zoom in 'Core'
    if @countMove>=50
      zoomx = @sprites["core"].zoom_x 
      zoomy = @sprites["core"].zoom_y 
      zoomx>=LimitScale ? zoomx=LimitScale :  zoomx+=0.1
      zoomy>=LimitScale ? zoomy=LimitScale :  zoomy+=0.1
      set_zoom("core",zoomx,zoomy)
      # Reset burn
      @burn=0
      @countMove=0
    end
    # Overload cake - Create overload
    if @sprites["core"].zoom_x>=LimitScale || @sprites["core"].zoom_y>=LimitScale
      set_zoom("core",LimitScale,LimitScale)
      @overload+= @level==1 ? 5 : @level==2 ? 3 : 0
      createOverload if canOverload?
    end
  end
#-------------------------------------------------------------------------------
  # Level: 1:weak; 2:strong; 3:strongest
  def fire(level,anim)
    set_visible_sprite("fire",true)
    x1 = @sprites["fire"].bitmap.width/3*(level-1)
    set_src_xy_sprite("fire",x1,0)
    x2 = @sprites["core"].bitmap.width/3*(level-1)
    set_src_xy_sprite("core",x2,0)
    # Weak, Strong, Strongest
    if (anim%15==0 && level==1) || (anim%5==0 && level==2) || (anim%2==0 && level==3)
      zoom = (@sprites["fire"].zoom_x>1.5||@sprites["fire"].zoom_y>1)? 1 : 1.1
      set_zoom("fire",zoom,zoom)
    end
  end
  
end