class Poffin
  # This is radius of the poffin when it's max. 
  # It's limit of mouse when you play. It depends your graphics
  RadiusCore = 125
  # Limit = Graphic (bowl -> limit of cake = RadiusCore*2) / Graphics (core)
  LimitScale = 2.5
  
  # Set: after 'TimeMax' frames, it stop (It's limit)
  TimeMax = 2400 # Frames
  # Time when arrow appears (arrow 'guide')
  TimeAppearArrow = 3*40
  # When player rolls cake with guide, it decreases time for next level
  RightGuide = 600 # ~2250
  
  def initialize
    @sprites = {}
    # Set viewport
    @viewport = Viewport.new(0,0,Graphics.width,Graphics.height)
    @viewport.z = 99999
    # Set pos of mouse (begin)
    @oldMouse = [Settings::SCREEN_WIDTH/2,Settings::SCREEN_HEIGHT/2-RadiusCore]
    # Count for zooming
    @countMove = 0 
    # Count for showing burn cake
    @countNoMove = 0
    # Check clockwise and counter
    @clockwise = false
    @counter = false
    # Set true when it finishes (time out)
    @finish = false
    # Set animation
    @anim = 0
    # Set level of fire/cake - 1, 2, 3
    @level = 1
    # Set burn/overload when condition is compatible
    @burn = 0
    @overload = 0
    @countBurn = 0
    @countOverload = 0
    # Set guide: 0 -> clockwise; 1 -> counter-clockwise
    @guide = -1
    @timeGuide = 0
    @countGuide = 0
    # Set rules
    @rules = $rulesPoffin.rules
    # Quantity of players
    @quantity = 0
    # Set AI, berry of AI
    @ai    = []
    @berry = []
    # Set for turning circle of AI
    @turn   = [false,false,false]
    @storeT = [0,0,0]
    @wrong  = [false,false,false]
    # Store berry (multiple mode)
    @flavormulti = []
    # Store flavor
    @storeflavor = []
    # Store poffin
    @store = {}
    # Store id berry 
    @idberry = []
		item = []
		GameData::Item.each { |i| item << i.id }
    (1..item.size).each { |i| @idberry.push(i) if GameData::Item.get(i).is_berry? }
    # SE mouse
    @semouse=0
  end
#-------------------------------------------------------------------------------
  def dispose(id=nil)
    (id.nil?)? pbDisposeSpriteHash(@sprites) : pbDisposeSprite(@sprites,id)
  end
  
  def update
    pbUpdateSpriteHash(@sprites)
  end
  
  def update_ingame
    Graphics.update
    Input.update
    pbUpdateSpriteHash(@sprites)
  end
  
  def endScene
    # Dipose sprites
    dispose
    # Dispose viewport
    @viewport.dispose
  end

end