class Poffin
  
  # Set Max poffin you can have
  # If you set MaxPoffin = [false,1] -> I will add many many Poffin
  # If you set MaxPoffin = [true,1]  -> You can store 1 poffin each case
  MaxPoffin = [true,999]
  
  # Store
  def storeInGlobal(result)
    if !MaxPoffin.is_a?(Array)
      p "Check again 'MaxPoffin', it must be array"
      return
    end
    # Set level
    @store[:level] = result[0]
    # Set name
    @store[:name] = result[1]
    # Set quantity of flavor
    @store[:flavor] = @storeflavor
    # Set color when quantity is 1 or 2
    @store[:color] = result[3]
    # Set sheen for poffin
    @store[:sheen] = self.returnSheen
    first = [:foul,:one,:two,:rich,:overripe,:mild]
    if result[2]==1 || result[2]==2
      if MaxPoffin[0] && $PokemonGlobal.poffin[first[result[2]]][result[1]].size==MaxPoffin[1]
        pbMessage(_INTL("Your poffin case is full at this part #{result[1]}"))
        return
      end
      $PokemonGlobal.poffin[first[result[2]]][result[1]]<<@store
    else
      if MaxPoffin[0] && $PokemonGlobal.poffin[first[result[2]]].size==MaxPoffin[1]
        pbMessage(_INTL("Your poffin case is full at this part #{result[1]}"))
        return
      end
      $PokemonGlobal.poffin[first[result[2]]]<<@store
    end
  end
  
end