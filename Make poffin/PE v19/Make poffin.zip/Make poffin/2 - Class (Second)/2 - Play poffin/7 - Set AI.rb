class Poffin
  
  # Set quantity
  def defineQuantity
    @quantity = @rules["quantity"].nil? ? 0 : @rules["quantity"]
  end
  
  # Set AI with rules
  def setAI
    return if @quantity<=0
    case @quantity
    # 1 AI
    when 1
      return @ai<<:newbie if !@rules["newbie"].nil?
      return @ai<<:oldbie if !@rules["oldbie"].nil?
      return @ai<<:expert if !@rules["expert"].nil?
    # 2 AI
    when 2
      if !@rules["newbie"].nil?
        fois = @rules["newbie"]<50 ? 1 : 2
        fois.times { @ai<<:newbie }
      end
      if !@rules["oldbie"].nil?
        fois = @rules["oldbie"]<50 ? 1 : 2
        fois.times { @ai<<:oldbie }
      end
      if !@rules["expert"].nil?
        fois = @rules["expert"]<50 ? 1 : 2
        fois.times { @ai<<:expert }
      end
    # 3 AI
    when 3
      if !@rules["newbie"].nil?
        fois = @rules["newbie"]<=30 ? 1 : (@rules["newbie"]>30 && @rules["newbie"]<=60)? 2 : 3
        fois.times { @ai<<:newbie }
      end
      if !@rules["oldbie"].nil?
        fois = @rules["oldbie"]<=30 ? 1 : (@rules["oldbie"]>30 && @rules["oldbie"]<=60)? 2 : 3
        fois.times { @ai<<:oldbie }
      end
      if !@rules["expert"].nil?
        fois = @rules["expert"]<=30 ? 1 : (@rules["expert"]>30 && @rules["expert"]<=60)? 2 : 3
        fois.times { @ai<<:expert }
      end
    end
    # Add newbie if you dont rule for AI
    if @rules["newbie"].nil? && @rules["oldbie"].nil? && @rules["expert"].nil?
      @quantity.times { @ai<<:newbie }
    end
  end
  
  # Re-random if it's same ID (set rule 'Not same')
  def setBerry
    ret = true
    return ret if @quantity<=0 
    if BerryPoffin.randomExpert.nil?
      p "You need to add berry in BerryExpert of module BerryPoffin"
      ret = false
      return ret
    end
    @ai.each { |ai| 
      case ai
      when :newbie; @berry<<BerryPoffin.random
      when :oldbie; @berry<<BerryPoffin.random
      when :expert; @berry<<BerryPoffin.randomExpert
      end
    }
    return ret if @ai.length<=1
    if !@rules["notSame"].nil?
      if BerryPoffin::BerryExpert.size<=1
        p "You have just only one berry in BerryExpert. You need to add for using this feature"
        return ret=false
      end
      loop do
        b = @berry.uniq!
        break if b.nil?
        # Check berry 1 and 2
        if @berry[0]==@berry[1]
          if reRandom(@berry[0],@ai[0]).nil?
            ret = false
            break 
          end
        # Check berry 1 and 3
        elsif @berry[0]==@berry[2]
          if reRandom(@berry[0],@ai[0]).nil?
            ret = false
            break 
          end
        # Check berry 2 and 3
        elsif @berry[1]==@berry[2]
          if reRandom(@berry[1],@ai[1]).nil?
            ret = false
            break 
          end
        end
      end
    end
    return ret
  end
  
  def reRandom(value1,value2)
    return value1 = BerryPoffin.random if value2==:newbie || value2==:oldbie
    return value1 = BerryPoffin.randomExpert if value2==:expert
    p "You have an error (random berry)"
    return nil
  end
  
end
