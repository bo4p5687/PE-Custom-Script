class Poffin
  
  def drawPoffin(x,y,result)
    bitmap = result[2]!=1 && result[2]!=2 ? "Poffin general" : "Poffin details"
    create_sprite("poffin",bitmap,@viewport)
    w = @sprites["poffin"].bitmap.width/(result[2]==1 || result[2]==2 ? 5 : 4)
    h = @sprites["poffin"].bitmap.height/(result[2]==1 || result[2]==2 ? 5 : 1)
    case result[2]
    when 1; srcx = w*result[3]; srcy = h*result[3]
    when 2; srcx = w*result[3][1]; srcy = h*result[3][0]
    else; srcx = w*(result[2]-2<=0 ? 0 : result[2]-2); srcy = 0
    end
    set_src_wh_sprite("poffin",w,h)
    set_src_xy_sprite("poffin",srcx,srcy)
    set_oxoy_sprite("poffin",w/2,h/2)
    set_xy_sprite("poffin",x,y)
  end
  
end