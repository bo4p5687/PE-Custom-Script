class Poffin
  
  # Start
  # If true, it will random start of AI
  RandomPosAI = false 
  # If RandomPosAI = false, coordinate need to set in PosAI
  # Remember, it must be in 'Core'
  PosAI = [
    # x,y, random number
    # random number -> it will +/- (x,y) if you set it
    # AI 1
    [140,300,100],
    # AI 2
    [350,250],
    # AI 3
    [250,120]
  ]
  
  def setXYAI
    @xyAI = []
    @quantity.times {
      x = Graphics.width/2+(rand(2)==0 ? rand(RadiusCore) : -rand(RadiusCore))
      y = Graphics.height/2+(rand(2)==0 ? rand(RadiusCore) : -rand(RadiusCore))
      loop do
        break if x!=0 || y!=0
        x = Graphics.width/2+(rand(2)==0 ? rand(RadiusCore) : -rand(RadiusCore))
        y = Graphics.height/2+(rand(2)==0 ? rand(RadiusCore) : -rand(RadiusCore))
      end
      @xyAI<<[x,y]
    }
    return if RandomPosAI
    if PosAI.size<3
      p "You need to set PosAI"
      return false
    end
    PosAI.each { |pos|
      if pos[0]==0 && pos[1]==0
        p "Don't set (0,0) in PosAI"
        return false
      end
    }
    @xyAI = []
    begin
      PosAI.each { |pos|
        x = pos[0] + (pos.size>=3 ? (rand(2)==0 ? pos[2] : -pos[2]) : 0)
        y = pos[1] + (pos.size>=3 ? (rand(2)==0 ? pos[2] : -pos[2]) : 0)
        # Set limit
        x = Graphics.width/2+RadiusCore if x>(Graphics.width/2+RadiusCore)
        x = Graphics.width/2-RadiusCore if x<(Graphics.width/2-RadiusCore)
        y = Graphics.height/2+RadiusCore if y>(Graphics.height/2+RadiusCore)
        y = Graphics.height/2-RadiusCore if y<(Graphics.height/2-RadiusCore)
        @xyAI<<[x,y]
      }
    rescue
      p "You need to check PosAI"
      return false
    end
  end
  
  # Pos: 0: AI-1; 1: AI-2; 2: AI-3
  # Create 'AI point'
  def createAIpoint(pos=0)
    if !@sprites["AI #{pos}"]
      create_sprite("AI #{pos}","AI",@viewport)
      w = @sprites["AI #{pos}"].bitmap.width/3
      h = @sprites["AI #{pos}"].bitmap.height
      set_src_wh_sprite("AI #{pos}",w,h)
      set_src_xy_sprite("AI #{pos}",w*pos,0)
      set_oxoy_sprite("AI #{pos}",w/2,h/2)
      set_xy_sprite("AI #{pos}",@xyAI[pos][0],@xyAI[pos][1])
    end
  end
  
  # Check when AI finishes circle
  def turnedCircle?(pos=0,counter=false)
    return if @quantity<=0 || !@sprites["AI #{pos}"]
    if @turn[pos]
      t = returnT(pos)
      # Set t/turn around
      case @guide
      when 0; (counter)? @storeT[pos]+=1 : @storeT[pos]-=1
      when 1; (counter)? @storeT[pos]-=1 : @storeT[pos]+=1
      end
      if @storeT[pos]>t || @storeT[pos]<-t
        @storeT[pos]=0
        return true
      end
      # Set x, y
      self.turnPoffin(pos)
      # Set zoom
      zoomx = @sprites["core"].zoom_x
      zoomy = @sprites["core"].zoom_y
      if zoomx<LimitScale
        zoomx += (@ai[pos]==:expert)? 0.004 : (@ai[pos]==:oldbie)? 0.003 : 0.001
      end
      if zoomy<LimitScale
        zoomy += (@ai[pos]==:expert)? 0.004 : (@ai[pos]==:oldbie)? 0.003 : 0.001
      end
      if zoomx>=LimitScale || zoomy>=LimitScale
        zoomx = LimitScale; zoomy = LimitScale
        # Set overload
        @overload += @level==1 ? 0.06 : @level==2 ? 0.04 : 0
        if @level!=3
          case @ai[pos]
          when :oldbie; zoomx-=0.05; zoomy-=0.05
          when :expert; zoomx-=0.1; zoomy-=0.1
          end
        end
      end
      set_zoom("core",zoomx,zoomy)
      # Next level
      @countGuide += 0.08 if !counter
      # Decrease burn
      @burn -= (@ai[pos]==:expert)? 0.5 : (@ai[pos]==:oldbie)? 0.4 : 0.1
      return false
    end
  end
  
  # Set times when AI turns around
  def returnT(pos=0)
    return (@ai[pos]==:expert)? 10 : (@ai[pos]==:oldbie)? 20 : 30
  end
  
  # Turn poffin
  def turnPoffin(pos=0)
    t = self.returnT(pos)
    x0 = @xyAI[pos][0]; y0 = @xyAI[pos][1]
    r  = Math.sqrt( (Graphics.width/2-x0)**2 + (Graphics.height/2-y0)**2 )      
    r  = rand(RadiusCore-50) + 50 if r>RadiusCore
    center = [Graphics.width/2,Graphics.height/2]
    x  = r*Math.sin(2*Math::PI/t*@storeT[pos]) + center[0]
    y  = r*Math.cos(2*Math::PI/t*@storeT[pos]) + center[1]
    set_xy_sprite("AI #{pos}",x,y)
  end
  
  # Some features of AI: turn around -> Fault: wrong turn, no turn
  def featureAI(pos=0)
    # Reset turn
    @turn[pos]=false if turnedCircle?(pos,@wrong[pos])
    # Set for turning
    if !@turn[pos]
      t = self.returnT(pos)
      random = rand(100)
      case @ai[pos]
      when :newbie
        if random>50 && @anim%4==0
          @turn[pos]  = true 
          @wrong[pos] = (rand(2)==0)? true : false
        else; @burn += @level==1 ? 0.05 : @level==2 ? 0.03 : 0.01
        end
      when :oldbie
        if random<=70 && @anim%3==0
          @turn[pos]  = true 
          @wrong[pos] = (rand(10)<=2)? true : false
          # Set when cake is overload
          if @sprites["core"].zoom_x>=LimitScale || @sprites["core"].zoom_y>=LimitScale
            @turn[pos] = (rand(10)<=1)? false : true
            # Set zoom
            zoomx = @sprites["core"].zoom_x
            zoomy = @sprites["core"].zoom_y
            zoomx = LimitScale; zoomy = LimitScale
            if !@turn[pos]
              zoomx -= 0.01*rand(10) - 0.1
              zoomy -= 0.01*rand(10) - 0.1
            end
            set_zoom("core",zoomx,zoomy)
          end
          @wrong[pos] ? @burn+=0.5 : @burn-=0.5
          @countGuide += 0.08 if !@wrong[pos]
        end
        # Turn (level 3)
        if !@turn[pos] && @level==3
          case @guide
          when 0; (@wrong[pos])? @storeT[pos]+=1 : @storeT[pos]-=1
          when 1; (@wrong[pos])? @storeT[pos]-=1 : @storeT[pos]+=1
          end
          @storeT[pos]=0 if @storeT[pos]>t || @storeT[pos]<-t
          self.turnPoffin(pos)
          @countGuide += 0.08 if !@wrong[pos]
        end
      when :expert
        if random<=90 && @anim%3==0
          @turn[pos] = true 
          # Set when cake is overload
          if @sprites["core"].zoom_x>=LimitScale || @sprites["core"].zoom_y>=LimitScale
            @turn[pos] = (rand(10)!=1)? false : true
            # Set zoom
            zoomx = @sprites["core"].zoom_x
            zoomy = @sprites["core"].zoom_y
            zoomx -= 0.001*rand(10) - 0.05
            zoomy -= 0.001*rand(10) - 0.05
            set_zoom("core",zoomx,zoomy)
          end
          @overload   -= 0.2
          @burn       -= 1
          @countGuide += 0.08 if !@turn[pos]
        end
        # Turn (level 3)
        if @level==3
          @turn[pos] = false
          @guide==0 ? @storeT[pos]-=1 : @storeT[pos]+=1
          @storeT[pos]=0 if @storeT[pos]>t || @storeT[pos]<-t
          self.turnPoffin(pos)
          if @sprites["core"].zoom_x>=LimitScale || @sprites["core"].zoom_y>=LimitScale
            set_zoom("core",LimitScale,LimitScale)
          end
          @countGuide += 0.08
        end
      end
    end
  end
  
end