class PoffinCase
  
#-------------------------------------------------------------------------------
# Quit
#-------------------------------------------------------------------------------
  def clickQuit
    ret = false
    if areaMouse?(PosQuit) && clickedMouse?
      set_visible_sprite("quit",true)
      pbWait(5)
      set_visible_sprite("quit")
      pbWait(5)
      # Quit
      ret = true
    end
    return ret
  end
  
#-------------------------------------------------------------------------------
# Eat
#-------------------------------------------------------------------------------
  def clickEat
    ret = false
    if areaMouse?(PosEat) && clickedMouse?
      # Check egg
      egg = false
      # Position pokemon when he isn't egg
      p = 0
      # Set
      set_visible_sprite("eat",true)
      self.txtNoPoffin if @listdisplay.size<=0
      if self.partySize<=0
        self.txtNoPkmn
      else
        (0...self.partySize).each { |i|
          if !pkmnEx(i).egg?
            egg = true; p = i; break
          end
        }
        self.txtNoPkmn if !egg
      end
      pbWait(10)
      set_visible_sprite("eat")
      # Next (eat)
      if @listdisplay.size!=0 && self.partySize>0 && egg
        # Set select pokemon
        @selpkmn = p
        # Set new page
        ret = true
      else
        @notiNoPoffin = [true,0]
      end
    end
    return ret
  end
  
end