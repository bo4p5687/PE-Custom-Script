class PoffinCase
  
  def pageOne
    # Create
    self.createPgone
    # Fade
    pbFadeInAndShow(@sprites) { update }
    # Position of Type
    postype = self.containTypePos
    # Position of Flavor (Column/Row)
    posflacol = self.containFlaPos(true)
    posflarow = self.containFlaPos
    # Draw text (bitmap - notification)
    self.drawNotifi
    # Draw text (bitmap - Information)
    self.drawInfor
    loop do
      # Update
      self.update_ingame
      # Show
      # Icon 'Type'
      self.showType(postype)
      # Icon 'Flavor' - column and row
      self.showFlavor(posflacol,posflarow)
      # Icon 'Quit' / 'Eat'
      @page = self.clickQuit ? 0 : self.clickEat ? 2 : 1
      # Delete notification
      self.deleteNotiNoPoffin
      # Show list
      self.setListDisplay
      # Move list up/down
      self.moveUp
      self.moveDown
      # Break
      if @page!=1
        # Set for draw information of pokemon
        @reinfor = true
        break
      end
    end
    # Dispose
    self.dispose
  end
  
  # Create
  def createPgone
    return if @sprites["page 1"]
    # Scene
    create_sprite("page 1","Page 1",@viewport)
    # Icon 'Quit'
    create_sprite("quit","Quit",@viewport)
    x = PosQuit[0]; y = PosQuit[1]
    set_xy_sprite("quit",x,y)
    set_visible_sprite("quit")
    # Icon 'Up/Down'
    # Up
    create_sprite("up","Up Down",@viewport)
    w = PosUp[2]; h = PosUp[3]
    set_src_wh_sprite("up",w,h)
    x = PosUp[0]; y = PosUp[1]
    set_xy_sprite("up",x,y)
    set_visible_sprite("up")
    # Down
    create_sprite("down","Up Down",@viewport)
    w = PosDown[2]; h = PosDown[3]
    set_src_wh_sprite("down",w,h)
    set_src_xy_sprite("down",w,0)
    x = PosDown[0]; y = PosDown[1]
    set_xy_sprite("down",x,y)
    set_visible_sprite("down")
    # Icon 'Eat'
    create_sprite("eat","Eat",@viewport)
    x = PosEat[0]; y = PosEat[1]
    set_xy_sprite("eat",x,y)
    set_visible_sprite("eat")
    # Icon 'Type'
    (0...6).each { |i|
      create_sprite("type #{i}","Type",@viewport)
      pos = self.positionType(i)
      w = pos[2]; h = pos[3]
      set_src_wh_sprite("type #{i}",w,h)
      set_src_xy_sprite("type #{i}",w*i,0)
      x = pos[0]; y = pos[1]
      set_xy_sprite("type #{i}",x,y)
      set_visible_sprite("type #{i}")
    }
    # Icon 'Flavor'
    # Column
    # Orgin
    create_sprite("fla col","Flavor column",@viewport)
    pos = self.positionFlavorCol(0)
    w = pos[2]; h = pos[3]
    set_src_wh_sprite("fla col",w,h*5)
    x = pos[0]; y = pos[1]
    set_xy_sprite("fla col",x,y)
    set_visible_sprite("fla col")
    # Choose
    (0...5).each { |i|
      create_sprite("fla col choose #{i}","Flavor column",@viewport)
      pos = self.positionFlavorCol(i)
      w = pos[2]; h = pos[3]
      set_src_wh_sprite("fla col choose #{i}",w,h)
      set_src_xy_sprite("fla col choose #{i}",w,h*i)
      x = pos[0]; y = pos[1]
      set_xy_sprite("fla col choose #{i}",x,y)
      set_visible_sprite("fla col choose #{i}")
    }
    # Row
    # Orgin
    create_sprite("fla row","Flavor row",@viewport)
    pos = self.positionFlavorRow(0)
    w = pos[2]; h = pos[3]
    set_src_wh_sprite("fla row",w*5,h)
    x = pos[0]; y = pos[1]
    set_xy_sprite("fla row",x,y)
    set_visible_sprite("fla row")
    # Choose
    (0...5).each { |i|
      create_sprite("fla row choose #{i}","Flavor row",@viewport)
      pos = self.positionFlavorRow(i)
      w = pos[2]; h = pos[3]
      set_src_wh_sprite("fla row choose #{i}",w,h)
      set_src_xy_sprite("fla row choose #{i}",w*i,h)
      x = pos[0]; y = pos[1]
      set_xy_sprite("fla row choose #{i}",x,y)
      set_visible_sprite("fla row choose #{i}")
    }
    # Choose bar
    create_sprite("choose bar","Choose Bar",@viewport)
    x = PosChooseBar[0]; y = PosChooseBar[1]
    set_xy_sprite("choose bar",x,y)
    set_visible_sprite("choose bar")
  end
  
end