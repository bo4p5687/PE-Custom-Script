class PoffinCase
  
  # Number for determining array -> return name when choosing (one/two flavor)
  def numberPoffin(pos)
    case pos
    when 1; return NamePoffin.single[@flacol]
    when 2
      number = []
      (0...5).each { |i| 
        number[i] = []
        (0...5).each { |j| number[i] << [i,j] if j!=i }
      }
      fla = [@flacol,@flarow]; value = [0,1]
      (0...number.size).each { |i|
        (0...number[i].size).each { |j|
          if number[i][j]==fla
            value = [i,j]
            break
          end
        }
      }
      return NamePoffin.double[value[0]][value[1]]
    end
  end

end