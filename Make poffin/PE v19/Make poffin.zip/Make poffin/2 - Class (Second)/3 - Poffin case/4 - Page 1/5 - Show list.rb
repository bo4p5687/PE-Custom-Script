class PoffinCase
  
  def drawInfor
    create_sprite_2("txt infor",@viewport) if !@sprites["txt infor"]
    clearTxt("txt infor")
  end
  
  def setListDisplay
    return if !@redraw
    # Reset
    @listdisplay = []
    clearTxt("txt infor")
    set_visible_sprite("choose bar")
    set_visible_sprite("poffin") if @sprites["poffin"]
    # Set
    symbol = [:foul,:one,:two,:rich,:overripe,:mild]
    case @type
    when 1, 2
      return if @list[symbol[@type]][self.numberPoffin(@type)].size <= 0
      @listdisplay = @list[symbol[@type]][self.numberPoffin(@type)]
    else
      return if @list[symbol[@type]].size <= 0
      @listdisplay = @list[symbol[@type]]
    end
    # Can visible bar
    set_visible_sprite("choose bar",true)
    # Set some value
    base   = Color.new(255,255,255)
    shadow = Color.new(0,0,0)
    max    = @listdisplay.size
    # Move bar
    (max<4)? self.posChooseBar(@select) : (@select>=max-4)? self.posChooseBar(@select-max+4) : self.posChooseBar(0)
    # Text
    text   = []
    pos    = (max>0 && max<4)? 0 : (@select>=max-4)? max-4 : @select
    endnum = (max>0 && max<4)? max : 4 
    (0...endnum).each { |i|
      a      = @listdisplay[pos+i]
      string = "#{a[:name]} No.(#{pos+i+1})"
      x      = 75
      y      = 106 - 11 + (30 + 1)*i
      text << [string,x,y,0,base,shadow]
    }
    # Information in table
    a = @listdisplay[@select]
    # Level
    string = sprintf("%3d",a[:level])
    x      = 120
    y      = 330 - 11
    text << [string,x,y,0,base,shadow]
    # Flavor
    f = a[:flavor]
    (0...f.size).each { |i|
      string = sprintf("%3d",f[i])
      x      = i%2==0 ? 260 : 363
      case i
      when 0, 1; y = 276
      when 2, 3; y = 307
      else;      y = 340
      end
			y -= 11
      text << [string,x,y,0,base,shadow]
    }
    # Sheen
    s      = a[:sheen]
    string = sprintf("%3d",a[:sheen])
    x      = 363
    y      = 340 - 11
    text << [string,x,y,0,base,shadow]
    drawTxt("txt infor",text,"Arial")
    # Draw bitmap (poffin)
    bitmap = @type!=1 && @type!=2 ? "Poffin general" : "Poffin details"
    create_sprite("poffin",bitmap,@viewport,"Pictures/Poffin")
    w = @sprites["poffin"].bitmap.width/(@type==1 || @type==2 ? 5 : 4)
    h = @sprites["poffin"].bitmap.height/(@type==1 || @type==2 ? 5 : 1)
    case @type
    when 1; srcx = w*a[:color]; srcy = h*a[:color]
    when 2; srcx = w*a[:color][1]; srcy = h*a[:color][0]
    else; srcx = w*(@type-2<=0 ? 0 : @type-2); srcy = 0
    end
    set_src_wh_sprite("poffin",w,h)
    set_src_xy_sprite("poffin",srcx,srcy)
    set_xy_sprite("poffin",28,307)
    # Reset
    redraw = false
  end
  
end