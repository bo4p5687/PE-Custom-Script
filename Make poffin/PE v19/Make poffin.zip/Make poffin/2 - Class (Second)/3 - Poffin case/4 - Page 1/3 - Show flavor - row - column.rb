class PoffinCase
  
#-------------------------------------------------------------------------------
# Flavor
#-------------------------------------------------------------------------------
  def showFlavor(pos1,pos2)
    if @type!=1 && @type!=2
      # Reset
      @flacol = 0; @flarow = 1
      set_visible_sprite("fla col")
      set_visible_sprite("fla row")
      (0...5).each { |i| 
        set_visible_sprite("fla col choose #{i}")
        set_visible_sprite("fla row choose #{i}")
      }
      return
    end
    # Column
    set_visible_sprite("fla col",true)
    flaI = self.mouseFlaCol(pos1)
    if !flaI.nil? && clickedMouse? && ( (@type==2 && flaI!=@flarow) || @type!=2 )
      @flacol = flaI
      @select = 0
      @redraw = true
    end
    set_visible_sprite("fla col choose #{@flacol}",true)
    (0...5).each { |i| set_visible_sprite("fla col choose #{i}") if i!=@flacol }
    if @type!=2
      # Reset
      @flarow = 1
      set_visible_sprite("fla row")
      (0...5).each { |i| set_visible_sprite("fla row choose #{i}") }
      return
    end
    # Row
    set_visible_sprite("fla row",true)
    flaII = self.mouseFlaCol(pos2)
    if !flaII.nil? && clickedMouse? && flaII!=@flacol
      @flarow = flaII
      @select = 0
      @redraw = true
    end
    set_visible_sprite("fla row choose #{@flarow}",true)
    (0...5).each { |i| set_visible_sprite("fla row choose #{i}") if i!=@flarow }
  end
  
  def containFlaPos(col=false)
    pos = []
    if col
      (0...6).each { |i| pos << self.positionFlavorCol(i) }
    else
      (0...6).each { |i| pos << self.positionFlavorRow(i) }
    end
    return pos
  end
  
  def mouseFlaCol(pos)
    if areaMouse?(pos[0])
      flavor = 0
    elsif areaMouse?(pos[1])
      flavor = 1
    elsif areaMouse?(pos[2])
      flavor = 2
    elsif areaMouse?(pos[3])
      flavor = 3
    elsif areaMouse?(pos[4])
      flavor = 4
    else
      flavor = nil
    end
    return flavor
  end
  
end