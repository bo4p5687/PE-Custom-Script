class PoffinCase
  
#-------------------------------------------------------------------------------
# Type
#-------------------------------------------------------------------------------
  def showType(pos)
    set_visible_sprite("type #{@type}",true)
    (0...6).each { |i| set_visible_sprite("type #{i}") if i!=@type }
    has = self.mouseType(pos)
    if !has.nil? && clickedMouse?
      @type = has
      # Reset
      @select = 0
      @flacol = 0
      @flarow = 1
      @redraw = true
    end
  end
  
  def containTypePos
    pos = []
    (0...6).each { |i| pos << self.positionType(i) }
    return pos
  end
  
  def mouseType(pos)
    if areaMouse?(pos[0])
      type = 0
    elsif areaMouse?(pos[1])
      type = 1
    elsif areaMouse?(pos[2])
      type = 2
    elsif areaMouse?(pos[3])
      type = 3
    elsif areaMouse?(pos[4])
      type = 4
    elsif areaMouse?(pos[5])
      type = 5
    else
      type = nil
    end
    return type
  end
  
end