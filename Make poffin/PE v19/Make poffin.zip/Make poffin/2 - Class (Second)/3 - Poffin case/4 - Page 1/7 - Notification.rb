class PoffinCase
  
  def drawNotifi
    create_sprite_2("txt notifi",@viewport) if !@sprites["txt notifi"]
    clearTxt("txt notifi")
  end
  
  def txtNoPoffin
    base   = Color.new(255,255,255)
    shadow = Color.new(0,0,0)
    text = []
    string = "You don't have any Poffins"
    text<<[string,210,10,0,base,shadow]
    drawTxt("txt notifi",text,"Arial",nil,0,false,1)
  end
  
  def deleteNotiNoPoffin
    if @notiNoPoffin[0]
      @notiNoPoffin[1]+=1
      if @notiNoPoffin[1]>5
        @notiNoPoffin[0] = false
        clearTxt("txt notifi")
      end
    end
  end
  
  def txtNoPkmn
    base   = Color.new(255,255,255)
    shadow = Color.new(0,0,0)
    text = []
    string = "You don't have any Pokemons"
    text<<[string,205,10,0,base,shadow]
    drawTxt("txt notifi",text,"Arial",nil,0,false,1)
  end
  
end