class PoffinCase
  
  def moveUp
    return if @listdisplay.size<=0
    if areaMouse?(PosUp) && clickedMouse?
      @select -= 1
      @select  = @listdisplay.size - 1 if @select < 0
      set_visible_sprite("up",true)
      pbWait(5)
      set_visible_sprite("up")
      # Redraw
      @redraw = true
    end
  end
  
  def moveDown
    return if @listdisplay.size<=0
    if areaMouse?(PosDown) && clickedMouse?
      @select += 1
      @select  = 0 if @select >= @listdisplay.size
      set_visible_sprite("down",true)
      pbWait(5)
      set_visible_sprite("down")
      # Redraw
      @redraw = true
    end
  end
  
  def posChooseBar(range)
    x = PosChooseBar[0]
    y = PosChooseBar[1] + PosChooseBar[2]*range
    set_xy_sprite("choose bar",x,y)
  end
  
end