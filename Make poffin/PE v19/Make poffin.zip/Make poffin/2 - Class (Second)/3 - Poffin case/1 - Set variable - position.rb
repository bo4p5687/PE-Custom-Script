#-------------------------------------------------------------------------------
# If you want to use poffin case like item, delete =begin and =end
# After that, remember add new item in PBS which calls  POFFINCASE
#-------------------------------------------------------------------------------
=begin
ItemHandlers::UseFromBag.add(:POFFINCASE,proc { |item|
  FeaturesPoffin.eat
  next 1
})
=end
#-------------------------------------------------------------------------------
class PoffinCase
  
  # Set position when 'click' mouse
  
  # x: coordinate x of graphic
  # y: coordinate y of graphic
  # w: width of graphic
  # h: height of graphic
  
  # Quit - [x,y,w,h]
  PosQuit = [468,0,44,44]
  
  # Up/Down - [x,y,w,h]
  PosUp   = [446, 64,36,80]
  PosDown = [446,164,36,80]
  
  # Eat - [x,y,w,h]
  PosEat = [422,304,70,50]
  
  # Type - [x,y,w,h]
  # Pos -> 0, 1, 2, 3, 4, 5
  def positionType(pos)
    x = 66 + 60*pos
    y = 76
    w = 60; h = 30
    return [x,y,w,h]
  end
  
  # Flavor (column) - [x,y,w,h]
  # Pos -> 0, 1, 2, 3, 4
  # 0 - All / First flavor
  def positionFlavorCol(pos)
    x = 26
    y = 106 + 24*pos
    w = 40; h = 24
    return [x,y,w,h]
  end
  
  # Flavor (row) - [x,y,w,h]
  # Pos -> 0, 1, 2, 3, 4
  # 0 - All / First flavor
  def positionFlavorRow(pos)
    x = 118 + 40*pos
    y = 229
    w = 40; h = 24
    return [x,y,w,h]
  end
  
  # Choose Bar - [x,y,d]
  # d: distance between two bars
  # It just uses for determining position
  PosChooseBar = [67,105,31]
  
  # Done - [x,y,w,h]
  PosDone = [195,204,34,20]
  
  # Icon pkmn - [x,y,w,h]
  # Pos -> 0, 1, 2, 3, 4, 5
  def positionIconPkmn(pos)
    x = 240 + 40*pos
    y = 57
    w = 20; h = 20
    return [x,y,w,h]
  end
  
end