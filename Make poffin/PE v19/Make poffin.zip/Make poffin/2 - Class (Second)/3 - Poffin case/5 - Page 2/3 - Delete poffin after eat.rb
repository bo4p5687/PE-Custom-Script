class PoffinCase
  
#-------------------------------------------------------------------------------
# Delete poffin
#-------------------------------------------------------------------------------
  def deletePoffin
    symbol = [:foul,:one,:two,:rich,:overripe,:mild]
    case @type
    when 1, 2
      $PokemonGlobal.poffin[symbol[@type]][self.numberPoffin(@type)].delete_at(@select)
      @list[symbol[@type]][self.numberPoffin(@type)] = []
      $PokemonGlobal.poffin[symbol[@type]][self.numberPoffin(@type)].each { |poffin|
        @list[symbol[@type]][self.numberPoffin(@type)] << poffin
      }
    else
      $PokemonGlobal.poffin[symbol[@type]].delete_at(@select)
      @list[symbol[@type]] = []
      $PokemonGlobal.poffin[symbol[@type]].each  { |poffin|
        @list[symbol[@type]] << poffin
      }
    end
  end
  
end