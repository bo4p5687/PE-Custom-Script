class PoffinCase

  def rectCondition
    value = [pkmnRecent.cool,pkmnRecent.beauty,pkmnRecent.cute,
              pkmnRecent.smart,pkmnRecent.tough,pkmnRecent.sheen]
    color = [Color.new(226,97,41), Color.new(51,236,230), Color.new(236,143,191),
            Color.new(143,236,193), Color.new(242,205,33), Color.new(114,13,99)]
    dispose("overlay")
    @sprites["overlay"] = BitmapSprite.new(Graphics.width,Graphics.height,@viewport)
    bitmap = @sprites["overlay"].bitmap
    (0...color.size).each { |i|
      x = 242; y = 128 + 42*i; w = value[i]; h = 18
      bitmap.fill_rect(x,y,w,h,color[i])
    }
  end
  
  def setInforDisplay
    return if !@reinfor
    dispose("pokemon")
    text = []
    base   = Color.new(255,255,255)
    shadow = Color.new(0,0,0)
    # Pokemon
    pkmn = pkmnRecent
		bitmap = GameData::Species.front_sprite_filename( (pkmn.species), (pkmn.form rescue 0), (pkmn.gender), (pkmn.shiny?), (pkmn.shadowPokemon?) )
		GameData::Species.play_cry(pkmn)
    @sprites["pokemon"] = Sprite.new(@viewport)
    @sprites["pokemon"].bitmap = Bitmap.new(bitmap)
    set_xy_sprite("pokemon",30,64)
    # Name
    string = "#{pkmnRecent.name}"
    text << [string,20,246,0,base,shadow]
    # Level
    string = "#{pkmnRecent.level}"
    text << [string,20,290,0,base,shadow]
    # Nature
    string = "#{GameData::Nature.get(pkmnRecent.nature).id}"
    text << [string,20,334,0,base,shadow]
    value = [pkmnRecent.cool,pkmnRecent.beauty,pkmnRecent.cute,
              pkmnRecent.smart,pkmnRecent.tough,pkmnRecent.sheen]
    (0...value.size).each { |i|
      string = sprintf("%d",value[i])
      x      = 310
      y      = 105 + 42*i
      text << [string,x,y,0,base,shadow]
    }
    drawTxt("txt infor",text,"Arial",nil,0,false,1,false)
    # Draw condition
    self.rectCondition
    # Reset
    @reinfor = false
  end
  
end