class PoffinCase
  
  # Return size of party 'pokemon'
  def partySize; return $Trainer.party.size; end
  
  # Return condition 'Sheen' of pokemon
  def checkSheen
    return true if pkmnRecent.sheen >= 255
    return false
  end
  
  # Return pokemon (first)
  def pkmnRecent; return $Trainer.party[@selpkmn]; end
    
  # Return pokemon in exact position
  def pkmnEx(pos); return $Trainer.party[pos]; end
  
  # Check nature
  def multiplyNature(arr)
    case @type
    when 0
      i = 0; j = 0; k = 0
      loop do
         i = rand(5); j = rand(5); k = rand(5)
         break if i!=j && i!=k && j!=k
      end
      flavor = [0,0,0,0,0]
      flavor[i] = 2
      flavor[j] = 2
      flavor[k] = 2
    else
      flavor = MultiplyFactor.nature(pkmnRecent.nature,arr)
    end
    return flavor
  end
  
  def plusCondition
    a     = @listdisplay[@select]
    arr   = self.multiplyNature(a[:flavor])
    sheen = a[:sheen]
    pkmnRecent.cool   += arr[0]
    pkmnRecent.beauty += arr[1]
    pkmnRecent.cute   += arr[2]
    pkmnRecent.smart  += arr[3]
    pkmnRecent.tough  += arr[4]
    pkmnRecent.sheen  += sheen
    pkmnRecent.cool   = 255 if pkmnRecent.cool   >= 255
    pkmnRecent.beauty = 255 if pkmnRecent.beauty >= 255
    pkmnRecent.cute   = 255 if pkmnRecent.cute   >= 255
    pkmnRecent.smart  = 255 if pkmnRecent.smart  >= 255
    pkmnRecent.tough  = 255 if pkmnRecent.tough  >= 255
    pkmnRecent.sheen  = 255 if pkmnRecent.sheen  >= 255
  end
  
end