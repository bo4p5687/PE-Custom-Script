class PoffinCase
  
#-------------------------------------------------------------------------------
# Icon
#-------------------------------------------------------------------------------
  def showIconPkmn(pos)
    set_visible_sprite("pkmn choose #{@selpkmn}",true)
    (0...self.partySize).each { |i| set_visible_sprite("pkmn choose #{i}") if i!=@selpkmn }
    has = self.mouseIconPkmn(pos)
    if clickedMouse?
      if has=="egg"
        self.txtEgg
        pbWait(5)
        @notiNoPoffin = [true,0]
      else
        if !has.nil?
          @selpkmn = has 
          @reinfor = true
        end
      end
    end
  end
  
  def containIconPkmnPos
    pos = []
    (0...self.partySize).each { |i| pos << self.positionIconPkmn(i) }
    return pos
  end
  
  def mouseIconPkmn(pos)
    icon = 0 if areaMouse?(pos[0])
    ( icon = 1 if areaMouse?(pos[1]) ) if pos.size>=2
    ( icon = 2 if areaMouse?(pos[2]) ) if pos.size>=3
    ( icon = 3 if areaMouse?(pos[3]) ) if pos.size>=4
    ( icon = 4 if areaMouse?(pos[4]) ) if pos.size>=5
    ( icon = 5 if areaMouse?(pos[5]) ) if pos.size>=6
    icon = nil if !icon
    (return "egg" if pkmnEx(icon).egg?) if !icon.nil?
    return icon
  end
  
end