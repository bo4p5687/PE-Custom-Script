class PoffinCase
  
  def pageTwo
    # Create
    self.createPgtwo
    # Fade
    pbFadeInAndShow(@sprites) { update }
    # Position of icon 'pokemon'
    posicon = self.containIconPkmnPos
    # Draw text (bitmap - notification)
    self.drawNotifi
    # Draw text (bitmap - Information)
    self.drawInfor
    loop do
      # Update
      self.update_ingame
      # Show information
      self.setInforDisplay
      # Icon 'Pokemon'
      self.showIconPkmn(posicon)
      # Icon 'Return'
      @page = 1 if self.clickReturn
      # Icon 'Done'
      if self.clickDone
        # Delete poffin
        self.deletePoffin
        @page = 1
      end
      # Delete notification (same method)
      self.deleteNotiNoPoffin
      if @page!=2
        # Reset
        @select = 0
        break
      end
    end
    # Dispose
    self.dispose
  end
  
  def createPgtwo
    return if @sprites["page 2"]
    # Scene
    create_sprite("page 2","Page 2",@viewport)
    # Icon 'Return'
    create_sprite("return","Return",@viewport)
    x = PosQuit[0]; y = PosQuit[1]
    set_xy_sprite("return",x,y)
    set_visible_sprite("return")
    # Icon 'Done'
    create_sprite("done","Done",@viewport)
    x = PosDone[0]; y = PosDone[1]
    set_xy_sprite("done",x,y)
    # Icon pokemon / choosed
    (0...self.partySize).each { |i| 
      create_sprite("pkmn #{i}","Pokeball",@viewport)
      pos = self.positionIconPkmn(i)
      w = pos[2]; h = pos[3]
      set_src_wh_sprite("pkmn #{i}",w,h)
      x = pos[0]; y = pos[1]
      set_xy_sprite("pkmn #{i}",x,y)
      create_sprite("pkmn choose #{i}","Pokeball",@viewport)
      set_src_wh_sprite("pkmn choose #{i}",w,h)
      set_src_xy_sprite("pkmn choose #{i}",w,0)
      set_xy_sprite("pkmn choose #{i}",x,y)
      set_visible_sprite("pkmn choose #{i}")
    }
  end
  
end