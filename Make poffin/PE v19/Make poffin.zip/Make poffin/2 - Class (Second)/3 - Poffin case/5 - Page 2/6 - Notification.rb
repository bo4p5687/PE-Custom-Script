class PoffinCase
  
  def txtCantEat
    base   = Color.new(255,255,255)
    shadow = Color.new(0,0,0)
    text = []
    string = "Pokemon can't eat anymore"
    text<<[string,210,10,0,base,shadow]
    drawTxt("txt notifi",text,"Arial",nil,0,false,1)
  end
  
  def txtEgg
    base   = Color.new(255,255,255)
    shadow = Color.new(0,0,0)
    text = []
    string = "Pokemon can't eat!!!"
    text<<[string,210,10,0,base,shadow]
    drawTxt("txt notifi",text,"Arial",nil,0,false,1)
  end
  
end