class PoffinCase
  
#-------------------------------------------------------------------------------
# Return
#-------------------------------------------------------------------------------
  def clickReturn
    ret = false
    if areaMouse?(PosQuit) && clickedMouse?
      set_visible_sprite("return",true)
      pbWait(5)
      set_visible_sprite("return")
      pbWait(5)
      # Return
      ret = true
    end
    return ret
  end

#-------------------------------------------------------------------------------
# Done
#-------------------------------------------------------------------------------
  def clickDone
    ret = false
    if areaMouse?(PosDone) && clickedMouse?
      if self.checkSheen
        self.txtCantEat
        pbWait(10)
        @notiNoPoffin = [true,0]
      else
        pbWait(5)
        set_visible_sprite("done")
        # Increase condition
        self.plusCondition
        # Redraw condition
        @reinfor = true
        self.setInforDisplay
        pbWait(20)
        # Done
        ret = true
      end
    end
    return ret
  end
  
end