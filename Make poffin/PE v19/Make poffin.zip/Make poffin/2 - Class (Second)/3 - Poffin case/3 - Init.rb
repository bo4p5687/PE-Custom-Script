class PoffinCase
  
  attr_reader :page
  
  def initialize
    @sprites = {}
    # Set viewport
    @viewport = Viewport.new(0,0,Graphics.width,Graphics.height)
    @viewport.z = 99999
    # Check page -> 0: cancel, 1: page 1, 2: page 2
    @page = 1
    # Type
    @type = 0
    # Flavor (show flavor when poffin has one/two flavor)
    # Column: 'main' flavor
    @flacol = 0
    @flarow = 1
    # List poffin
    @list = {}
    # Foul Poffin
    @list[:foul] = []
    $PokemonGlobal.poffin[:foul].each{ |poffin| @list[:foul] << poffin }
    # One flavor
    # @list[:one]["Spicy Poffin"], @list[:one]["Dry Poffin"], etc
    @list[:one] = {}
    n = NamePoffin.single
    n.each { |i| 
      @list[:one][i]=[]
      $PokemonGlobal.poffin[:one][i].each{ |poffin| @list[:one][i] << poffin }
    }
    # Two flavors
    # @list[:two]["Spicy Dry Poffin"], @list[:two]["Spicy Sweet Poffin"], etc
    @list[:two] = {}
    n  = NamePoffin.double
    n.each { |i|
      i.each { |j| 
        @list[:two][j] = []
        $PokemonGlobal.poffin[:two][j].each{ |poffin| @list[:two][j] << poffin }
      }
    }
    # Three flavors
    @list[:rich] = []
    $PokemonGlobal.poffin[:rich].each{ |poffin| @list[:rich] << poffin }
    # Four flavors
    @list[:overripe] = []
    $PokemonGlobal.poffin[:overripe].each{ |poffin| @list[:overripe] << poffin }
    # Poffin has level 50
    @list[:mild] = []
    $PokemonGlobal.poffin[:mild].each{ |poffin| @list[:mild] << poffin }
    # List for displaying
    @listdisplay = []
    # Nofication 'No poffin'
    @notiNoPoffin = [false,0]
    # Select poffin - (choose bar)
    @select = 0
    # Check need to redraw
    @redraw  = true # page 1
    @reinfor = true # page 2
    # Select pokemon
    @selpkmn = 0
  end
#-------------------------------------------------------------------------------
  def dispose(id=nil)
    (id.nil?)? pbDisposeSpriteHash(@sprites) : pbDisposeSprite(@sprites,id)
  end
  
  def update
    pbUpdateSpriteHash(@sprites)
  end
  
  def update_ingame
    Graphics.update
    Input.update
    pbUpdateSpriteHash(@sprites)
  end
  
  def endScene
    # Dipose sprites
    dispose
    # Dispose viewport
    @viewport.dispose
  end

end