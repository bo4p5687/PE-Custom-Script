#===============================================================================
# ■ Fly Animation by KleinStudio
# http://pokemonfangames.com
#===============================================================================
#  Fly Poké Ball Animation by Ulithium_Dragon
#===============================================================================
# bo4p5687 (update)
#===============================================================================
module FlyPokeballAnimation
	# Each line is each player

	# Land
	START = [
		"boy_UsePokeball",  # Player A
    "girl_UsePokeball"  # Player B
	]

	FINISH = [
		"boy_UsePokeballEND",  # Player A
    "girl_UsePokeballEND"  # Player B
	]

	# Flying
	FLYING_FRONT = [
		"flybird_BoyFront", # Player A
		"flybird_GirlFront" # Player B
	]

	FLYING_BACK = [
		"flybird_BoyBack", # Player A
		"flybird_GirlBack" # Player B
	]

	# Don't touch these lines below
	@@using = false

	def self.set(value = false) = @@using = value
	def self.get = @@using
	
	def self.main_animation(flew = false)
		$game_player.turn_down if $game_player.direction != 8
		id = ($player&.character_ID || 1) - 1
		graphic = START
		$game_player.character_name = pbGetPlayerCharset(graphic[id])
		self.set(true)  if $PokemonGlobal.surfing || $PokemonGlobal.diving
		if flew
			pbWait(6)
			$game_player.turn_up
			pbWait(4)
			$game_player.turn_right
			pbWait(4)
			$game_player.turn_left
			pbWait(4)
			$game_player.turn_down
			pbWait(4)
			$game_player.refresh_charset
			pbWait(6)
		else
			pbWait(6)
			$game_player.turn_down
			pbWait(4)
			$game_player.turn_left
			pbWait(4)
			$game_player.turn_right
			pbWait(4)
			$game_player.turn_up
			pbWait(6)
			graphic = FINISH
			$game_player.character_name = pbGetPlayerCharset(graphic[id])
		end
	end
	
	def self.animation_poke_ball(is_start = true)
		$game_player.turn_down if $game_player.direction != 8
		id = ($player&.character_ID || 1) - 1
		graphic = FINISH
		$game_player.character_name = pbGetPlayerCharset(graphic[id])
		width  = Settings::SCREEN_WIDTH
		height = Settings::SCREEN_HEIGHT
		viewport = Viewport.new(0, 0, width, height)
		viewport.z = 999999
		sprite = {}
		sprite['flybird'] = Sprite.new(viewport)
		sprite['flybird'].bitmap = RPG::Cache.picture("flybird")
		sprite['flybird'].ox = sprite['flybird'].bitmap.width / 2
		sprite['flybird'].oy = sprite['flybird'].bitmap.height / 2
		sprite['flybird'].x  = width / 2 + 16
		sprite['flybird'].y  = is_start ? height / 2 : -sprite['flybird'].oy
		sprite['flybird'].angle = is_start ? 270 : 90
		if is_start
			sprite['flybird'].zoom_x = 0
			sprite['flybird'].zoom_y = 0
		end
		value = 5.to_f
		distance = (height / 2 + sprite['flybird'].oy).to_f
		zoom = value.to_f / distance
		loop do
			Graphics.update
			pbUpdateSpriteHash(sprite)
			if is_start
				sprite['flybird'].y -= value
				sprite['flybird'].zoom_x += zoom
				sprite['flybird'].zoom_y += zoom
				break if sprite['flybird'].y <= -sprite['flybird'].oy
			else
				sprite['flybird'].y += value
				sprite['flybird'].zoom_x -= zoom
				sprite['flybird'].zoom_y -= zoom
				if sprite['flybird'].y >= height / 2
					sprite['flybird'].zoom_x = 0
					sprite['flybird'].zoom_y = 0
					break
				end
			end
		end
		pbDisposeSpriteHash(sprite)
		viewport.dispose
		$game_player.refresh_charset
		$game_player.character_name = pbGetPlayerCharset(graphic[id])
	end

	def self.move_route(route)
		return if !route.is_a?(Array)
    pbMoveRoute($game_player, route, true)
	end
end

class Game_Character
	def set_opacity(value)
		@opacity = value
	end
end

class Sprite_SurfBase
	alias fly_pokeball_update update
	def update
		return if disposed?
		if FlyPokeballAnimation.get
			if @sprite && !@sprite.disposed?
				@sprite.src_rect.x = 0
				@sprite.src_rect.y = 0
			end
			return
		end
		fly_pokeball_update
	end
end

# Caution
echoln 'When you use script Fly Pokeball animation, you must delete script Fly animation' if defined? pbFlyAnimation

def pbFlyAnimation(landing = true)
	# Timing
	time = 14
	if landing
		$game_player.turn_left
		pbSEPlay("flybird")
	end
	width  = Settings::SCREEN_WIDTH
	height = Settings::SCREEN_HEIGHT
	# Viewport
	viewport = Viewport.new(0, 0, width, height)
	viewport.z = 999999
	# Bird
	flybird = Sprite.new(viewport)
	flybird.bitmap = RPG::Cache.picture("flybird")
	flybird.ox = flybird.bitmap.width / 2
	flybird.oy = flybird.bitmap.height / 2
	flybird.x  = width + flybird.bitmap.width
	flybird.y  = height / 4
	# Player
	player = Sprite.new(viewport)
	id = ($player&.character_ID || 1) - 1
	graphic = landing ? FlyPokeballAnimation::FLYING_BACK[id] : FlyPokeballAnimation::FLYING_FRONT[id]
	player.bitmap = RPG::Cache.picture(graphic)
	player.opacity = 0
	player.ox = player.bitmap.width / 2
	player.oy = player.bitmap.height / 2
	player.x = flybird.x
	player.y = flybird.y
	loop do
		pbUpdateSceneMap
		if flybird.x > (width / 2 + 10)
			flybird.x -= (width + flybird.bitmap.width - width / 2).div time
			flybird.y -= (height / 4 - height / 2).div time
			player.x = flybird.x
			player.y = flybird.y
			player.opacity = landing ? 0 : 255
			flybird.opacity = landing ? 255 : 0
		elsif flybird.x <= (width / 2 + 10) && flybird.x >= 0
			flybird.x -= (width + flybird.bitmap.width - width / 2).div time
			flybird.y += (height / 4 - height / 2).div time
			$game_player.set_opacity(landing ? 0 : 255)
			player.x = flybird.x
			player.y = flybird.y
			player.opacity = landing ? 255 : 0
			flybird.opacity = landing ? 0 : 255
		else
			break
		end
		Graphics.update
	end
	flybird.dispose
	player.dispose
	viewport.dispose
end

def pbFlyToNewLocation(pkmn = nil, move = :FLY)
  return false if $game_temp.fly_destination.nil?
  pkmn = $player.get_pokemon_with_move(move) if !pkmn
  if !$DEBUG && !pkmn
    $game_temp.fly_destination = nil
    yield if block_given?
    return false
  end
	FlyPokeballAnimation.main_animation
	pbWait(8)
	FlyPokeballAnimation.animation_poke_ball
	pbWait(4)
  if !pkmn || !pbHiddenMoveAnimation(pkmn)
    name = pkmn&.name || $player.name
    pbMessage(_INTL("{1} used {2}!", name, GameData::Move.get(move).name))
  end
	FlyPokeballAnimation.main_animation(true)
	FlyPokeballAnimation.set(false)
  $stats.fly_count += 1
	pbFlyAnimation
  pbFadeOutIn {
    pbSEPlay("Fly")
    $game_temp.player_new_map_id    = $game_temp.fly_destination[0]
    $game_temp.player_new_x         = $game_temp.fly_destination[1]
    $game_temp.player_new_y         = $game_temp.fly_destination[2]
    $game_temp.player_new_direction = 2
    $game_temp.fly_destination = nil
    $scene.transfer_player
    $game_map.autoplay
    $game_map.refresh
    yield if block_given?
    pbWait(Graphics.frame_rate / 4)
  }
	pbFlyAnimation(false)
	pbWait(8)
	FlyPokeballAnimation.main_animation
	pbWait(4)
	FlyPokeballAnimation.animation_poke_ball(false)
	FlyPokeballAnimation.main_animation(true)
	FlyPokeballAnimation.set(false)
  pbEraseEscapePoint
  return true
end