module ChooseLanguage
	# Set title, here
	TITLE = ["Language", "Ngôn ngữ"]

	class Show
		attr_reader :chose

		def initialize
			@sprites = {}
			# Viewport
      @viewport = Viewport.new(0,0,Graphics.width,Graphics.height)
      @viewport.z = 99999
			# Value
			# Name graphics
			@language = Settings::LANGUAGES.map { |i| i[0] }
			# Set title if language changed
			@title = TITLE
			@chose = 0
			# Set color (time)
			@speed  = [0, false] # times, check change
			@frames = 0
			@color  = [240, 255, 210]
			# Arrow
			@arrow = [0, false] # times, check change
			@exit  = false
		end

	end

	def self.show
		ret = 0
		pbFadeOutIn {
			f = Show.new
			f.show
			ret = f.chose
			f.endScene
		}
		return ret
	end

end

def pbChooseLanguage = ChooseLanguage.show

# Change language, here
# You can change it in Script editor or just delete =begin and =end then use it
module Settings
	LANGUAGES = [
   ["English", "english.dat"],
   ["Việt Nam", "vietnam.dat"]
  ]
end