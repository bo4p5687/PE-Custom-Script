module ChooseLanguage
	class Show

		def show
			create_scene
			loop do
				update_ingame
				break if @exit
				# Update
				update_main
				# Text
				draw_text
				# Input
				set_input
				@frames += 1
			end
		end

		def create_scene
			# Create background
			@sprites["bg"]   = ColoredPlane.new(Color.new(@color[0], @color[1], @color[2]), @viewport)
			@sprites["blue"] = AnimatedPlane.new(@viewport)
			@sprites["blue"].setBitmap("Graphics/Pictures/Choose Language/Blue")
			@sprites["ball"] = AnimatedPlane.new(@viewport)
			@sprites["ball"].setBitmap("Graphics/Pictures/Choose Language/Ball")
			# Language
			create_sprite("title bar", "Title Bar", @viewport)
			create_sprite("language", "#{@language[@chose]}", @viewport)
			ox = @sprites["language"].bitmap.width  / 2
			oy = @sprites["language"].bitmap.height / 2
			set_oxoy_sprite("language", ox, oy)
			x = Graphics.width  / 2
			y = Graphics.height / 2
			set_xy_sprite("language", x, y)
			2.times { |i|
				create_sprite("arrow #{i}", "Arrow", @viewport)
				w = @sprites["arrow #{i}"].bitmap.width / 2
				h = @sprites["arrow #{i}"].bitmap.height
				set_src_wh_sprite("arrow #{i}", w, h)
				set_src_xy_sprite("arrow #{i}", i * w, 0)
				x  = Graphics.width / 2 + (i==0 ? (-1) : 1) * (ox + 15)
				x -= w if i == 0
				y  = (Graphics.height - h) / 2
				set_xy_sprite("arrow #{i}", x, y)
			}
			# Text
			create_sprite_2("title", @viewport)
			create_sprite_2("name", @viewport)
		end

		#--------#
		# Update #
		#--------#
		def update_main
			update_bg
			update_arrow
		end

		def update_bg
			# Change color
			add   = 30.0
			times = 10.0
			if @frames % 8 == 0
				@speed[0] += 1
				if @speed[0] > times
					@speed[1] = !@speed[1]
					@speed[0] = 0
				end
				div = (add / times).to_f
				# Keep green (using color green)
				@color.map!.with_index { |color, i| i == 1 ? color : @speed[1] ? (@color[i] + div) : (@color[i] - div) }
				@sprites["bg"].set_plane_color(Color.new(@color[0], @color[1], @color[2]))
			end
			# Animation
			@sprites["ball"].ox -= 1
			@sprites["ball"].oy -= 1
			@sprites["blue"].ox += 1
			@sprites["blue"].oy += 1
		end

		def update_arrow
			return if @frames % 4 != 0
			distance   = 10
			times      = 10
			@arrow[0] += 1
			if @arrow[0] > times
				@arrow[1] = !@arrow[1]
				@arrow[0] = 0
			end
			div = (distance / times).to_f
			if @arrow[1]
				@sprites["arrow 0"].x += div
				@sprites["arrow 1"].x -= div
			else
				@sprites["arrow 0"].x -= div
				@sprites["arrow 1"].x += div
			end
		end

		def update_language = set_sprite("language", "#{@language[@chose]}")

		#------#
		# Text #
		#------#
		def draw_text
			draw_title
			draw_name
		end

		def draw_title
			text = []
			string = "#{@title[@chose]}"
			dist   = (@sprites["title bar"].bitmap.height - 20) / 2 - 10
			x = Graphics.width / 2
			y = @sprites["title bar"].y + dist - 5
			text << [string, x, y, 0, Color.new(0, 0, 0), Color.new(255, 255, 255)]
			drawTxt("title", text, "Arial", 30, 1)
		end

		def draw_name
			text = []
			string = "#{@language[@chose]}"
			x = Graphics.width  / 2
			y = Graphics.height / 2 + @sprites["language"].src_rect.height / 2 + 10
			text << [string, x, y, 0, Color.new(0, 0, 0), Color.new(255, 255, 255)]
			drawTxt("name", text, "Arial", 30, 1)
		end

		#-------#
		# Input #
		#-------#
		def set_input
			@exit = true if checkInput(Input::BACK) || checkInput(Input::USE)
			if checkInput(Input::LEFT)
				@chose -= 1
				@chose  = @language.size - 1 if @chose < 0
				update_language
			elsif checkInput(Input::RIGHT)
				@chose += 1
				@chose  = 0 if @chose >= @language.size
				update_language
			end
		end

	end
end